import sys
import os
import time
import math
import mxnet
import pandas as pd
import numpy as np
import sklearn
from sklearn import metrics
import random
import itertools
import copy
import gc
import warnings

from modeling import cdnn



class ModelTuner(object):
    """
    All possible hyperparameter configurations that can be generated from hyperParametersToTune in modelingChoicesDict
    is enumerated and cross validated here. If no tuning is required, keep only 
    This class does two options of hyper parameter tuning. One is to tune a model for each split separately and use ensemble 
    of those as final model. Another is to tune the hyperparameters using all cv splits.
    """
    def __init__(self, cvSplits, dataConfigDict, modelingChoicesDict, maxBatchSize, logger, phase = 1):
        self.logger = logger
        self.phase = phase
        self.dataConfigDict = dataConfigDict
        self.modelingChoicesDict = modelingChoicesDict
        self.allGridSearchConfigurationsDict = self.modelingChoicesDict['hyperParametersToTune']
        self.maxBatchSize = maxBatchSize
        self.ensemble = True if self.modelingChoicesDict['cvSetup']['ensemble'] > 0 else False
        # Different configuration settings are added as multiple dictionaries in config file.
        # Each element of each dictionary is a set of parameters with grid search defined in it.
        # This is designed like this to do selective tuning. For instance, with number of regression layers = 50, 
        # we may not want to try with dimension of regression layers as high as 1000. 
        # Therefore, for example, the first dictionary will have numLayers as 50 and dimension as 100 or so.
        # The second can have number of layers as 5 and dimension as 1000, etc.
        for key, oneGridSearchConfigurationDict in self.allGridSearchConfigurationsDict.items():
            if key.lower().startswith('parameters'):
                self.fixEmptyParameterLists(oneGridSearchConfigurationDict)
            else:
                self.allGridSearchConfigurationsDict.pop(key)                
                
        self.cvSplits = cvSplits
        self.cvSplits.bestModelPhase_1 = []
        self.cvSplits.bestModelPhase_2 = []     
        self.cvSplits.bestConfigPhase_1 = {}
        self.cvSplits.bestConfigPhase_2 = {}        
        # TODO: need to modify iterator to consider AUC or other classification error metric for classification problem type.
        # Currently best model is chosen using RMSE between the true and predicted.
        self.classificationProblem = True if len(self.dataConfigDict['targets']['binaryTargetNames']) > 0 else False
        self.cvSplits.metricTrain = np.inf
        self.cvSplits.bestMetricValid = np.inf
        for split in range(len(cvSplits.cvList)):
            self.cvSplits.cvList[split]['bestModelPhase_1'] = None
            self.cvSplits.cvList[split]['bestModelPhase_2'] = None       
            self.cvSplits.cvList[split]['bestConfigPhase_1'] = {}
            self.cvSplits.cvList[split]['bestConfigPhase_2'] = {}            
            self.cvSplits.cvList[split]['metricTrain'] = np.inf
            self.cvSplits.cvList[split]['bestMetricValid'] = np.inf

            
            
    def fixEmptyParameterLists(self, oneGridSearchConfigurationDict):
        """
        Filling in default values for parameters that are not entered in config file.
        """
        for layer in ['numFeatureOnlyLayers', 'numTreatmentOnlyLayers', 'numRegressionLayers', 'numConcatenationLayers']:
            if len(oneGridSearchConfigurationDict['numLayers'][layer]) <= 0:
                oneGridSearchConfigurationDict['numLayers'][layer] = [0]
        for layer in ['dimFeatureOnlyLayers', 'dimTreatmentOnlyLayers', 'dimRegressionLayers', 'dimConcatenationLayers']:
            if len(oneGridSearchConfigurationDict['dimLayers'][layer]) <= 0:
                oneGridSearchConfigurationDict['dimLayers'][layer] = [0]   
        if len(oneGridSearchConfigurationDict['weightInitializerToUse']['value']) <= 0:
            oneGridSearchConfigurationDict['weightInitializerToUse']['value'] = ['xavier']        
        for param in ['sigma', 'scale', 'constant', 'magnitude']:
            if len(oneGridSearchConfigurationDict['weightInitializerToUse'][param]) <= 0:
                oneGridSearchConfigurationDict['weightInitializerToUse'][param] = [0]                   
        if len(oneGridSearchConfigurationDict['activationFunction']['value']) <= 0:
            oneGridSearchConfigurationDict['activationFunction']['value'] = ['Swish']        
        for param in ['beta']:
            if len(oneGridSearchConfigurationDict['activationFunction'][param]) <= 0:
                oneGridSearchConfigurationDict['activationFunction'][param] = [0]  
        for phase in ['1', '2']:
            if len(oneGridSearchConfigurationDict['learningRate_phase_'+phase]['scheduleType']) <= 0:
                oneGridSearchConfigurationDict['learningRate_phase_'+phase]['scheduleType'] = ['none']        
            for param in ['value', 'min_lr', 'max_lr', 'cycle_length', 'inc_fraction']:
                if len(oneGridSearchConfigurationDict['learningRate_phase_'+phase][param]) <= 0:
                    oneGridSearchConfigurationDict['learningRate_phase_'+phase][param] = [0]  
            if len(oneGridSearchConfigurationDict['epochs']['phase_'+phase]) <= 0:
                oneGridSearchConfigurationDict['epochs']['phase_'+phase] = [1] 
            else:
                # sorting so that models for each epochs can be saved 
                # and large epochs just need to restart from the preceding epoch.
                oneGridSearchConfigurationDict['epochs']['phase_'+phase].sort()
                
            if len(oneGridSearchConfigurationDict['weightDecay']['phase_'+phase]) <= 0:
                oneGridSearchConfigurationDict['weightDecay']['phase_'+phase] = [0]                 
        for param in ['apply', 'momentum']:
            if len(oneGridSearchConfigurationDict['batchNormalization'][param]) <= 0:
                oneGridSearchConfigurationDict['batchNormalization'][param] = [0]            
        if len(oneGridSearchConfigurationDict['dropoutRateRegression']['value']) <= 0:
            oneGridSearchConfigurationDict['dropoutRateRegression']['value'] = [0]     
        if len(oneGridSearchConfigurationDict['loss']['value']) <= 0:
            oneGridSearchConfigurationDict['loss']['value'] = ['l2']                 
        if len(oneGridSearchConfigurationDict['dataBatch']['value']) <= 0:
            oneGridSearchConfigurationDict['dataBatch']['value'] = [128] 
        dataBatch = oneGridSearchConfigurationDict['dataBatch']['value']
        oneGridSearchConfigurationDict['dataBatch']['value'] = list(set([min(x, self.maxBatchSize) for x in dataBatch]))
        if len(oneGridSearchConfigurationDict['optimizer']['value']) <= 0:
            oneGridSearchConfigurationDict['optimizer']['value'] = ['Adam']  
        return oneGridSearchConfigurationDict
    
    
    def getMetricsOnPredictions(self, actual, prediction):
        metricsDict = {'negOfAUC' : 1000, 'RMSE' : -1000, 'MAE' : -1000, 'ME' : -1000, 'metricToMinimize' : 'RMSE'}
        if self.classificationProblem:
            metricsDict['negOfAUC'] = -1 * metrics.roc_auc_score(actual, prediction)
            # TODO: choose this from config file in future.
            metricsDict['metricToMinimize'] = 'negOfAUC'
        else:
            metricsDict['RMSE'] = math.sqrt(metrics.mean_squared_error(actual, prediction))
            metricsDict['MAE'] = metrics.mean_absolute_error(actual, prediction)
            metricsDict['ME'] = np.mean(actual) - np.mean(prediction)
        return metricsDict
        

    def tuneHyperParameters(self):
        self.configNum = 0
        if self.phase == 1:
            for key, oneGridSearchConfigurationDict in self.allGridSearchConfigurationsDict.items():
                self.doGridSearchPhase_1(oneGridSearchConfigurationDict)
                if self.modelingChoicesDict['cvSetup']['valid_fraction'] <= 0:
                    return
        elif self.phase == 2:
                # please note the configurations for each of splits and overall are stored in the data structure.
                # all the first phase values would be single element list and second phase values would be list of parameters
                self.doGridSearchPhase_2()
        
        
    def doGridSearchPhase_1(self, oneGridSearchConfigurationDict):
        # batch is sepeartely itereated to reuse data iterator, not implemented yet.
        for batchSize in oneGridSearchConfigurationDict['dataBatch']['value']:
            for numFeatureOnlyLayers, numTreatmentOnlyLayers, numRegressionLayers, \
                dimFeatureOnlyLayers, dimTreatmentOnlyLayers, dimRegressionLayers, \
                weightInitializerToUse, weightInitializerToUse_sigma, weightInitializerToUse_scale, \
                weightInitializerToUse_constant, weightInitializerToUse_magnitude, activationFunction, \
                activationFunction_beta, learningRate, learningRate_scheduler, learningRate_min_lr, \
                learningRate_max_lr, learningRate_cycle_length, learningRate_inc_fraction, weightDecay, \
                batchNormalization, batchNormalization_momentum, dropoutRateRegression, loss, optimizer \
                in \
                itertools.product(oneGridSearchConfigurationDict['numLayers']['numFeatureOnlyLayers'], \
                                  oneGridSearchConfigurationDict['numLayers']['numTreatmentOnlyLayers'], \
                                  oneGridSearchConfigurationDict['numLayers']['numRegressionLayers'], \
                                  oneGridSearchConfigurationDict['dimLayers']['dimFeatureOnlyLayers'], \
                                  oneGridSearchConfigurationDict['dimLayers']['dimTreatmentOnlyLayers'], \
                                  oneGridSearchConfigurationDict['dimLayers']['dimRegressionLayers'], \
                                  oneGridSearchConfigurationDict['weightInitializerToUse']['value'], \
                                  oneGridSearchConfigurationDict['weightInitializerToUse']['sigma'], \
                                  oneGridSearchConfigurationDict['weightInitializerToUse']['scale'], \
                                  oneGridSearchConfigurationDict['weightInitializerToUse']['constant'], \
                                  oneGridSearchConfigurationDict['weightInitializerToUse']['magnitude'], \
                                  oneGridSearchConfigurationDict['activationFunction']['value'], \
                                  oneGridSearchConfigurationDict['activationFunction']['beta'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['value'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['scheduleType'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['min_lr'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['max_lr'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['cycle_length'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['inc_fraction'], \
                                  oneGridSearchConfigurationDict['weightDecay']['phase_'+str(self.phase)], \
                                  oneGridSearchConfigurationDict['batchNormalization']['apply'], \
                                  oneGridSearchConfigurationDict['batchNormalization']['momentum'], \
                                  oneGridSearchConfigurationDict['dropoutRateRegression']['value'], \
                                  oneGridSearchConfigurationDict['loss']['value'], \
                                  oneGridSearchConfigurationDict['optimizer']['value']):
                self.logger.write('epochs '+str(oneGridSearchConfigurationDict['epochs']['phase_1']), 4)
                # number of epochs are explored in ascending order
                # each instance of epoch warmstarts from the previous epoch model saved on disk.
                # epochModelName is dictionary that saves the previous epoch model for each split.
                # Beware: this way of implementation may cause inconsistency with scheduler learning rates                
                epochModelName = {}
                # adding subdict for each split. The subdict saves previous epoch number as key and modelPath as value.
                # eg. epochModelName[1][10] will have model name /<modelArtifactsScratchDirectoryName>/model_1_10
                for split in range(len(self.cvSplits.cvList)):
                    epochModelName[split] = {}
                previousEpochs = 0
                for epochs in oneGridSearchConfigurationDict['epochs']['phase_'+str(self.phase)]:
                    self.configNum += 1
                    # making a copy of oneGridSearchConfigurationDict and assigning one value to each parameter   
                    oneConfigurationDict = copy.deepcopy(oneGridSearchConfigurationDict)
                    oneConfigurationDict['dataBatch']['value'] = [batchSize]
                    oneConfigurationDict['numLayers']['numFeatureOnlyLayers'] = [numFeatureOnlyLayers]
                    oneConfigurationDict['numLayers']['numTreatmentOnlyLayers'] = [numTreatmentOnlyLayers]
                    oneConfigurationDict['numLayers']['numRegressionLayers'] = [numRegressionLayers]
                    oneConfigurationDict['dimLayers']['dimFeatureOnlyLayers'] = [dimFeatureOnlyLayers]
                    oneConfigurationDict['dimLayers']['dimTreatmentOnlyLayers'] = [dimTreatmentOnlyLayers]
                    oneConfigurationDict['dimLayers']['dimRegressionLayers'] = [dimRegressionLayers]
                    oneConfigurationDict['weightInitializerToUse']['value'] = [weightInitializerToUse]
                    oneConfigurationDict['weightInitializerToUse']['sigma'] = [weightInitializerToUse_sigma]
                    oneConfigurationDict['weightInitializerToUse']['scale'] = [weightInitializerToUse_scale]
                    oneConfigurationDict['weightInitializerToUse']['constant'] = [weightInitializerToUse_constant]
                    oneConfigurationDict['weightInitializerToUse']['magnitude'] = [weightInitializerToUse_magnitude]
                    oneConfigurationDict['activationFunction']['value'] = [activationFunction]
                    oneConfigurationDict['activationFunction']['beta'] = [activationFunction_beta]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['value'] = [learningRate]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['scheduleType'] = [learningRate_scheduler]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['min_lr'] = [learningRate_min_lr]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['max_lr'] = [learningRate_max_lr]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['cycle_length'] = [learningRate_cycle_length]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['inc_fraction'] = [learningRate_inc_fraction]
                    oneConfigurationDict['weightDecay']['phase_'+str(self.phase)] = [weightDecay]
                    oneConfigurationDict['batchNormalization']['apply'] = [batchNormalization]
                    oneConfigurationDict['batchNormalization']['momentum'] = [batchNormalization_momentum]
                    oneConfigurationDict['dropoutRateRegression']['value'] = [dropoutRateRegression]
                    oneConfigurationDict['loss']['value'] = [loss]
                    oneConfigurationDict['optimizer']['value'] = [optimizer]
                    oneConfigurationDict['epochs']['phase_'+str(self.phase)] = [epochs]
                    gc.collect()
                    averageMetricOverAllSplitsValid = 0
                    averageMetricOverAllSplitsTrain = 0
                    splitModelList_forConfiguration = []
                    for split in range(len(self.cvSplits.cvList)):
                        configAndSplitStartTime = time.time()
                        self.logger.write('split '+str(split)+ ', previousepoch '+ str(previousEpochs), 4)
                        cdnnModel_forSplit_forConfiguration = cdnn.CausalDeepNeuralNetwork(\
                                                                 cvFold = self.cvSplits.cvList[split],\
                                                                 dataConfigDict = self.dataConfigDict,\
                                                                 modelingChoicesDict = self.modelingChoicesDict,\
                                                                 hyperparameterConfigurationDict =  oneConfigurationDict,\
                                                                 logger = self.logger, phase = self.phase)
                        # train data iterator
                        cdnnModel_forSplit_forConfiguration.create_data_iterator(\
                                                            self.cvSplits.cvList[split]['dfFeaturesTrain'], \
                                                            self.cvSplits.cvList[split]['dfInterventionsTrain'], \
                                                            self.cvSplits.cvList[split]['dfTargetsTrain'],\
                                                            self.cvSplits.cvList[split]['dfInstanceWeightsTrain'],\
                                                            isTrain = True, shuffle=True, last_batch = 'pad')
                        # validation data iterator
                        if len(self.cvSplits.cvList[split]['dfFeaturesValid']) > 0:
                            cdnnModel_forSplit_forConfiguration.create_data_iterator(\
                                                            self.cvSplits.cvList[split]['dfFeaturesValid'], \
                                                            self.cvSplits.cvList[split]['dfInterventionsValid'], \
                                                            self.cvSplits.cvList[split]['dfTargetsValid'],\
                                                            self.cvSplits.cvList[split]['dfInstanceWeightsValid'],\
                                                            isTrain = False, shuffle=True, last_batch = 'pad')  
                        if previousEpochs > 0:
                            self.logger.write('loading parameters from previous epoch model. additional epochs would be ' +\
                                              str(epochs - previousEpochs), 4)
                            # load parameters from disk
                            cdnnModel_forSplit_forConfiguration.net.load_parameters(epochModelName[split][previousEpochs],\
                                                                             ctx=cdnnModel_forSplit_forConfiguration.ctx)
                        # if we prefix the network name with 'nofreeze' in the cofig file, we don't freeze layers.
                        if not self.modelingChoicesDict['modelSpecs']['network'].lower().startswith('nofreeze'):
                            # only parameters are loaded from previous epoch; so weight freezing has to be done anyway
                            cdnnModel_forSplit_forConfiguration.phaseOneWeightFreeze()
                            
                        cdnnModel_forSplit_forConfiguration.trainModel(startEpochNumber = previousEpochs)
                        # saving models for lower epoch numbers so that training sofar can be reused.
                        epochModelName[split][epochs] = os.path.join(self.dataConfigDict['localPaths']\
                                                           ['modelArtifactsScratchDirectoryName'], \
                                                            'model_'+str(split)+'_'+str(epochs))
                        cdnnModel_forSplit_forConfiguration.net.save_parameters(epochModelName[split][epochs])
                        splitModelList_forConfiguration.append(cdnnModel_forSplit_forConfiguration)
                        # getting predictions
                        yf_train_prediction = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                                           self.cvSplits.cvList[split]['dfFeaturesTrain'], \
                                                           self.cvSplits.cvList[split]['dfInterventionsTrain'],\
                                                           self.cvSplits.cvList[split]['dfInstanceWeightsTrain'])
                        metricsDictTrain = self.getMetricsOnPredictions(self.cvSplits.cvList[split]\
                                                   ['dfTargetsTrain'].values, yf_train_prediction)
                        averageMetricOverAllSplitsTrain += metricsDictTrain[metricsDictTrain['metricToMinimize']]
                        
                        if len(self.cvSplits.cvList[split]['dfTargetsValid']) > 0:
                            yf_valid_prediction = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                   self.cvSplits.cvList[split]['dfFeaturesValid'], \
                                   self.cvSplits.cvList[split]['dfInterventionsValid'],\
                                   self.cvSplits.cvList[split]['dfInstanceWeightsValid'])
                            metricsDictValid = self.getMetricsOnPredictions(self.cvSplits.cvList[split]\
                                                   ['dfTargetsValid'].values, yf_valid_prediction)
                            # best average metrics is used when we need to select one config based on performance on all splits
                            averageMetricOverAllSplitsValid += metricsDictValid[metricsDictValid['metricToMinimize']]
                            # best metric for each split is saved for using in ensemble approach.
                            if metricsDictValid[metricsDictValid['metricToMinimize']] < \
                                                                            self.cvSplits.cvList[split]['bestMetricValid']:
                                self.cvSplits.cvList[split]['bestMetricValid'] = \
                                                                      metricsDictValid[metricsDictValid['metricToMinimize']]
                                self.cvSplits.cvList[split]['metricTrain'] = \
                                                                      metricsDictTrain[metricsDictTrain['metricToMinimize']]
                                self.cvSplits.cvList[split]['bestConfigPhase_'+str(self.phase)] = oneConfigurationDict
                                self.cvSplits.cvList[split]['bestModelPhase_'+str(self.phase)] = \
                                                                                      cdnnModel_forSplit_forConfiguration
                        else:
                            metricsDictValid = {'negOfAUC' : 1000, 'RMSE' : -1000, 'MAE' : -1000, 'ME' : -1000,\
                                                                                                   'metricToMinimize' : 'RMSE'}
                            metricsDictValid['metricToMinimize'] = metricsDictTrain['metricToMinimize']
                            self.cvSplits.cvList[split]['metricTrain'] = metricsDictTrain[metricsDictTrain['metricToMinimize']]
                            self.cvSplits.cvList[split]['bestConfigPhase_'+str(self.phase)] = oneConfigurationDict
                            self.cvSplits.cvList[split]['bestModelPhase_'+str(self.phase)] = \
                                                                                      cdnnModel_forSplit_forConfiguration
                                
                        configAndSplitEndTime = time.time()
                        totalTime = int(float(configAndSplitEndTime - configAndSplitStartTime)/60)
                        self.logger.write('configNum: '+str(self.configNum)+ ', cvSplitNum: '+str(split) +\
                                    ', TrainMetric: '+str(metricsDictTrain[metricsDictTrain['metricToMinimize']])+\
                                    ', ValidMetric: '+str(metricsDictValid[metricsDictValid['metricToMinimize']]) +\
                                    ', TimeTaken - previousEpochTime: '+str(totalTime) + ' minutes', 3)

                    averageMetricOverAllSplitsValid /= len(self.cvSplits.cvList)
                    averageMetricOverAllSplitsTrain /= len(self.cvSplits.cvList)
                    if averageMetricOverAllSplitsValid < self.cvSplits.bestMetricValid and \
                                                 self.modelingChoicesDict['cvSetup']['valid_fraction'] > 0:
                        self.cvSplits.bestMetricValid = averageMetricOverAllSplitsValid
                        self.cvSplits.metricTrain = averageMetricOverAllSplitsTrain
                        self.cvSplits.bestConfigPhase_1 = oneConfigurationDict
                        self.cvSplits.bestModelPhase_1 = splitModelList_forConfiguration
                    elif self.modelingChoicesDict['cvSetup']['valid_fraction'] <= 0:
                        self.cvSplits.metricTrain = averageMetricOverAllSplitsTrain
                        self.cvSplits.meanErrorTrain = absoluteOfMeanErrorTrain
                        self.cvSplits.bestConfigPhase_1 = oneConfigurationDict
                        self.cvSplits.bestModelPhase_1 = splitModelList_forConfiguration
                        # if valid_fraction is 0, there is no tuning possilbe.
                        # Return the current model that was trained using the first element of parameters' list.   
                        return

                    self.logger.write('configNum: '+str(self.configNum) + ', phase: ' + str(self.phase) +\
                              ", batchSize: " + str(batchSize) + \
                              ", numFeatureOnlyLayers: " + str(numFeatureOnlyLayers) + ", numTreatmentOnlyLayers: " + \
                              str(numTreatmentOnlyLayers) + ", numRegressionLayers: " + str(numRegressionLayers) + \
                              ", dimFeatureOnlyLayers: " + str(dimFeatureOnlyLayers) + ", dimTreatmentOnlyLayers: " + \
                              str(dimTreatmentOnlyLayers) + ", dimRegressionLayers: " + str(dimRegressionLayers) + \
                              ", batchSize: " + str(batchSize) + ", weightInitializerToUse: " + str(weightInitializerToUse) + \
                              ", weightInitializerToUse_sigma: " + str(weightInitializerToUse_sigma) + \
                              ", weightInitializerToUse_scale: " + str(weightInitializerToUse_scale) + \
                              ", weightInitializerToUse_constant: " + str(weightInitializerToUse_constant) + \
                              ", weightInitializerToUse_magnitude: " + str(weightInitializerToUse_magnitude) + \
                              ", activationFunction: " + str(activationFunction) + ", activationFunction_beta: " + \
                              str(activationFunction_beta) + ", learningRate" + str(learningRate) + \
                              ", learningRate_scheduler: " + str(learningRate_scheduler) + ", learningRate_min_lr: " + \
                              str(learningRate_min_lr) + ", learningRate_max_lr" + str(learningRate_max_lr) + \
                              ", learningRate_cycle_length: " + str(learningRate_cycle_length) + \
                              ", learningRate_inc_fraction: " + str(learningRate_inc_fraction) + ", weightDecay: " + \
                              str(weightDecay) + ", batchNormalization: " + str(batchNormalization) + \
                              ", batchNormalization_momentum: " + str(batchNormalization_momentum) + \
                              ", dropoutRateRegression: " + str(dropoutRateRegression) + ", loss: " + str(loss) + \
                              ", optimizer: " + str(optimizer) + ", epochs: " + str(epochs), 3)
                    self.logger.write('configNum: '+str(self.configNum)+ ', cvSplitNum: allSplits' +\
                                               ', TrainMetric: '+str(averageMetricOverAllSplitsTrain)+\
                                              ', ValidMetric: '+str(averageMetricOverAllSplitsValid), 2)
                    self.logger.write('------------------', 3)
                    previousEpochs = epochs    
                            
  
    def doGridSearchPhase_2(self):
        self.cvSplits.bestConfigPhase_2 = self.cvSplits.bestConfigPhase_1
        self.cvSplits.bestModelPhase_2 = self.cvSplits.bestModelPhase_1
        for split in range(len(self.cvSplits.cvList)):
            self.cvSplits.cvList[split]['bestConfigPhase_2'] = self.cvSplits.cvList[split]['bestConfigPhase_1']
            self.cvSplits.cvList[split]['bestModelPhase_2'] = self.cvSplits.cvList[split]['bestModelPhase_1']
            
        if self.ensemble:
            self.doGridSearchPhase_2_forEnsemble()
        else:
            self.doGridSearchPhase_2_forAllSplits()

                        
    def doGridSearchPhase_2_forAllSplits(self):
        # saving first phase model parameters sothat we can warmstart from it for all configurations
        firstModelNameList = []
        # there is some redundancy in saving model here - will address later.
        for split in range(len(self.cvSplits.cvList)):
            firstPhaseModelName = os.path.join(self.dataConfigDict['localPaths']\
                                                           ['modelArtifactsBaseDirectoryName'], \
                                                            'modelParameters_'+str(split)+'_phase_1')
            self.cvSplits.bestModelPhase_1[split].net.save_parameters(firstPhaseModelName)
            firstModelNameList.append(firstPhaseModelName)
            
        # iterate through splits after configurations since we are finding the best configuration for all splits.
        # iterate only for learning rate, epochs and weight decay
        for learningRate, learningRate_scheduler, learningRate_min_lr, \
            learningRate_max_lr, learningRate_cycle_length, learningRate_inc_fraction, weightDecay \
            in \
            itertools.product(self.cvSplits.bestConfigPhase_1['learningRate_phase_'+str(self.phase)]['value'], \
                              self.cvSplits.bestConfigPhase_1['learningRate_phase_'+str(self.phase)]['scheduleType'], \
                              self.cvSplits.bestConfigPhase_1['learningRate_phase_'+str(self.phase)]['min_lr'], \
                              self.cvSplits.bestConfigPhase_1['learningRate_phase_'+str(self.phase)]['max_lr'], \
                              self.cvSplits.bestConfigPhase_1['learningRate_phase_'+str(self.phase)]['cycle_length'], \
                              self.cvSplits.bestConfigPhase_1['learningRate_phase_'+str(self.phase)]['inc_fraction'], \
                              self.cvSplits.bestConfigPhase_1['weightDecay']['phase_'+str(self.phase)]):
            self.logger.write('epochs_'+str(self.cvSplits.bestConfigPhase_1['epochs']['phase_'+str(self.phase)]), 4)
            epochModelName = {}
            for split in range(len(self.cvSplits.cvList)):
                epochModelName[split] = {}
            previousEpochs = 0
            for epochs in self.cvSplits.bestConfigPhase_1['epochs']['phase_'+str(self.phase)]:    
                # since epochs is sorted in acending order by function fixEmptyParameterLists,
                # model for each epoch is further continued to learn after saving the results, model etc..
                # copy the results and config. clone the config and continue learning the model by updating epochs.
                # this way of implementation may cause inconsistency with scheduler learning rates
                # making a copy of oneGridSearchConfigurationDict
                self.configNum += 1
                oneConfigurationDict = copy.deepcopy(self.cvSplits.bestConfigPhase_1)
                oneConfigurationDict['learningRate_phase_'+str(self.phase)]['value'] = [learningRate]
                oneConfigurationDict['learningRate_phase_'+str(self.phase)]['scheduleType'] = \
                                                                                     [learningRate_scheduler]
                oneConfigurationDict['learningRate_phase_'+str(self.phase)]['min_lr'] = [learningRate_min_lr]
                oneConfigurationDict['learningRate_phase_'+str(self.phase)]['max_lr'] = [learningRate_max_lr]
                oneConfigurationDict['learningRate_phase_'+str(self.phase)]['cycle_length'] = \
                                                                                  [learningRate_cycle_length]
                oneConfigurationDict['learningRate_phase_'+str(self.phase)]['inc_fraction'] = \
                                                                                  [learningRate_inc_fraction]
                oneConfigurationDict['weightDecay']['phase_'+str(self.phase)] = [weightDecay]
                oneConfigurationDict['epochs']['phase_'+str(self.phase)] = [epochs]
                gc.collect()
                averageMetricOverAllSplitsValid = 0
                averageMetricOverAllSplitsTrain = 0
                splitModelList_forConfiguration = []
                for split in range(len(self.cvSplits.cvList)):
                    configAndSplitStartTime = time.time()
                    self.logger.write('split'+str(split)+ 'previousepoch'+ str(previousEpochs), 4)
                    self.logger.write(str(self.cvSplits.cvList[split]['dfTargetsTrain'].mean()), 4)
                    cdnnModel_forSplit_forConfiguration = cdnn.CausalDeepNeuralNetwork(\
                                                             cvFold = self.cvSplits.cvList[split],\
                                                             dataConfigDict = self.dataConfigDict,\
                                                             modelingChoicesDict = self.modelingChoicesDict,\
                                                             hyperparameterConfigurationDict =  oneConfigurationDict,\
                                                             logger = self.logger, phase = self.phase)
                    # train data iterator
                    cdnnModel_forSplit_forConfiguration.create_data_iterator(\
                                                        self.cvSplits.cvList[split]['dfFeaturesTrain'], \
                                                        self.cvSplits.cvList[split]['dfInterventionsTrain'], \
                                                        self.cvSplits.cvList[split]['dfTargetsTrain'],\
                                                        self.cvSplits.cvList[split]['dfInstanceWeightsTrain'],\
                                                        isTrain = True, shuffle=True, last_batch = 'pad')
                    # validation data iterator
                    if len(self.cvSplits.cvList[split]['dfFeaturesValid']) > 0:
                        cdnnModel_forSplit_forConfiguration.create_data_iterator(\
                                                        self.cvSplits.cvList[split]['dfFeaturesValid'], \
                                                        self.cvSplits.cvList[split]['dfInterventionsValid'], \
                                                        self.cvSplits.cvList[split]['dfTargetsValid'],\
                                                        self.cvSplits.cvList[split]['dfInstanceWeightsValid'],\
                                                        isTrain = False, shuffle=True, last_batch = 'pad')  

                    # if loading from previous epoch, we do not need to initialize the newly unfrozen layers.
                    initialize = True
                    if previousEpochs > 0:
                        self.logger.write('loading parameters from previous epoch model. additional epochs would be ' +\
                                          str(epochs - previousEpochs), 4)
                        # load parameters from disk
                        cdnnModel_forSplit_forConfiguration.net.load_parameters(epochModelName[split][previousEpochs],\
                                                                         ctx=cdnnModel_forSplit_forConfiguration.ctx)
                        initialize = False
                    else:
                        self.logger.write('loading parameters from first phase model for split '+str(split), 4)
                        # load parameters from disk
                        cdnnModel_forSplit_forConfiguration.net.load_parameters(firstModelNameList[split],\
                                                                         ctx=cdnnModel_forSplit_forConfiguration.ctx)
                        
                    cdnnModel_forSplit_forConfiguration.setLearningRateEpochsAndTrainer(phase = 2)
                    # if we prefix the network name with 'nofreeze' in the cofig file, we don't freeze layers.
                    if not self.modelingChoicesDict['modelSpecs']['network'].lower().startswith('nofreeze'):
                        if self.modelingChoicesDict['modelSpecs']['computeOutcomeResidualExplicitly']>0:
                            # only unfreeze need to be done; no freezing of any layer happens
                            cdnnModel_forSplit_forConfiguration.phaseTwoWeightUnfreezeOnly(initialize = initialize)
                        else:
                            # only parameters are loaded from previous epoch; so weight freezing has to be done anyway
                            # unfreeze treatment layers and freeze feature layers
                            cdnnModel_forSplit_forConfiguration.phaseTwoWeightFreezeAndUnfreeze(initialize = initialize)
                        
                    cdnnModel_forSplit_forConfiguration.trainModel(startEpochNumber = previousEpochs)
                    # saving models for lower epoch numbers so that training sofar can be reused.
                    epochModelName[split][epochs] = os.path.join(self.dataConfigDict['localPaths']\
                                                       ['modelArtifactsScratchDirectoryName'], \
                                                        'model_'+str(split)+'_'+str(epochs))
                    cdnnModel_forSplit_forConfiguration.net.save_parameters(epochModelName[split][epochs])
                    splitModelList_forConfiguration.append(cdnnModel_forSplit_forConfiguration)
                    # getting predictions
                    yf_train_prediction = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                                       self.cvSplits.cvList[split]['dfFeaturesTrain'], \
                                                       self.cvSplits.cvList[split]['dfInterventionsTrain'],\
                                                       self.cvSplits.cvList[split]['dfInstanceWeightsTrain'])
                    metricsDictTrain = self.getMetricsOnPredictions(self.cvSplits.cvList[split]\
                                               ['dfTargetsTrain'].values, yf_train_prediction)
                    averageMetricOverAllSplitsTrain += metricsDictTrain[metricsDictTrain['metricToMinimize']]
                    if len(self.cvSplits.cvList[split]['dfTargetsValid']) > 0:
                        yf_valid_prediction = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                                       self.cvSplits.cvList[split]['dfFeaturesValid'], \
                                                       self.cvSplits.cvList[split]['dfInterventionsValid'],\
                                                       self.cvSplits.cvList[split]['dfInstanceWeightsValid'])
                        metricsDictValid = self.getMetricsOnPredictions(self.cvSplits.cvList[split]\
                                               ['dfTargetsValid'].values, yf_valid_prediction)
                        averageMetricOverAllSplitsValid += metricsDictValid[metricsDictValid['metricToMinimize']]

                        if metricsDictValid[metricsDictValid['metricToMinimize']] < \
                                                                        self.cvSplits.cvList[split]['bestMetricValid']:
                            self.cvSplits.cvList[split]['bestMetricValid'] = \
                                                                metricsDictValid[metricsDictValid['metricToMinimize']] 
                            self.cvSplits.cvList[split]['metricTrain'] = metricsDictTrain[metricsDictTrain['metricToMinimize']]
                            self.cvSplits.cvList[split]['bestConfigPhase_'+str(self.phase)] = oneConfigurationDict
                            self.cvSplits.cvList[split]['bestModelPhase_'+str(self.phase)] = \
                                                                              cdnnModel_forSplit_forConfiguration
                    else:
                        metricsDictValid = {'negOfAUC' : 1000, 'RMSE' : -1000, 'MAE' : -1000, 'ME' : -1000,\
                                                                                                   'metricToMinimize' : 'RMSE'}
                        metricsDictValid['metricToMinimize'] = metricsDictTrain['metricToMinimize']
                        self.cvSplits.cvList[split]['metricTrain'] = metricsDictTrain[metricsDictTrain['metricToMinimize']]
                        self.cvSplits.cvList[split]['bestConfigPhase_'+str(self.phase)] = oneConfigurationDict
                        self.cvSplits.cvList[split]['bestModelPhase_'+str(self.phase)] = \
                                                                           cdnnModel_forSplit_forConfiguration
                    configAndSplitEndTime = time.time()
                    totalTime = int(float(configAndSplitEndTime - configAndSplitStartTime)/60)
                    self.logger.write('configNum: '+str(self.configNum)+ ', cvSplitNum: '+str(split) +\
                                    ', TrainMetric: '+str(metricsDictTrain[metricsDictTrain['metricToMinimize']])+\
                                    ', ValidMetric: '+str(metricsDictValid[metricsDictValid['metricToMinimize']]) +\
                                    ', TimeTaken - previousEpochTime: '+str(totalTime) + ' minutes', 3)

                averageMetricOverAllSplitsValid /= len(self.cvSplits.cvList)
                averageMetricOverAllSplitsTrain /= len(self.cvSplits.cvList)
                if averageMetricOverAllSplitsValid < self.cvSplits.bestMetricValid and \
                                                 self.modelingChoicesDict['cvSetup']['valid_fraction'] > 0:
                    self.cvSplits.bestMetricValid = averageMetricOverAllSplitsValid
                    self.cvSplits.metricTrain = averageMetricOverAllSplitsTrain
                    self.cvSplits.bestConfigPhase_2 = oneConfigurationDict
                    self.cvSplits.bestModelPhase_2 = splitModelList_forConfiguration
                elif self.modelingChoicesDict['cvSetup']['valid_fraction'] <= 0:
                    self.cvSplits.metricTrain = averageMetricOverAllSplitsTrain
                    self.cvSplits.bestConfigPhase_2 = oneConfigurationDict
                    self.cvSplits.bestModelPhase_2 = splitModelList_forConfiguration
                    # if valid_fraction is 0, there is no tuning possilbe.
                    # Return the current model that was trained using the first element of parameters' list.
                    return

                self.logger.write('configNum: '+str(self.configNum)+ ', cvSplitNum: allSplits' + ', phase: '+ str(self.phase)+\
                          ", learningRate: " + str(learningRate) + ", learningRate_scheduler: " + str(learningRate_scheduler) +\
                          ", learningRate_min_lr: " + str(learningRate_min_lr) + ", learningRate_max_lr: " + \
                          str(learningRate_max_lr) + ", learningRate_cycle_length: " + str(learningRate_cycle_length) +\
                          ", learningRate_inc_fraction: " + str(learningRate_inc_fraction) + ", weightDecay: " + \
                          str(weightDecay) + ", epochs: " + str(epochs), 3)
                self.logger.write('configNum: '+str(self.configNum)+ ', cvSplitNum: allSplits' +\
                                           ', TrainMetric: '+str(averageMetricOverAllSplitsTrain)+\
                                          ', ValidMetric: '+str(averageMetricOverAllSplitsValid), 2)
                self.logger.write('------------------', 3)                
                previousEpochs = epochs   
                
                    
            
    def doGridSearchPhase_2_forEnsemble(self):
        # iterate through the splits first, since we have already tuned our phase 1 model for each split
        # here, we warmstart from best phase 1 model for each split and finds the best hyperparameters for each split.
        for split in range(len(self.cvSplits.cvList)):
            oneGridSearchConfigurationDict = self.cvSplits.cvList[split]['bestConfigPhase_'+str(self.phase)]
            # saving models from first phase so that the model is not altered while doing grid search.
            firstPhaseModelName = os.path.join(self.dataConfigDict['localPaths']\
                                                           ['modelArtifactsBaseDirectoryName'], \
                                                            'modelParameters_'+str(split)+'_phase_1')
            self.cvSplits.cvList[split]['bestModelPhase_1'].net.save_parameters(firstPhaseModelName)
            # iterate only for learning rate, epochs and weight decay
            for learningRate, learningRate_scheduler, learningRate_min_lr, \
                learningRate_max_lr, learningRate_cycle_length, learningRate_inc_fraction, weightDecay \
                in \
                itertools.product(oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['value'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['scheduleType'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['min_lr'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['max_lr'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['cycle_length'], \
                                  oneGridSearchConfigurationDict['learningRate_phase_'+str(self.phase)]['inc_fraction'], \
                                  oneGridSearchConfigurationDict['weightDecay']['phase_'+str(self.phase)]):
                self.logger.write('epochs'+str(oneGridSearchConfigurationDict['epochs']['phase_2']), 4)
                epochModelName = {}
                previousEpochs = 0
                for epochs in oneGridSearchConfigurationDict['epochs']['phase_'+str(self.phase)]:    
                    # since epochs is sorted in acending order by function fixEmptyParameterLists,
                    # model for each epoch is further continued to learn after saving the results, model etc..
                    # copy the results and config. clone the config and continue learning the model by updating epochs.
                    # this way of implementation may cause inconsistency with scheduler learning rates
                    self.configNum += 1
                    configAndSplitStartTime = time.time()
                    # making a copy of oneGridSearchConfigurationDict                    
                    oneConfigurationDict = copy.deepcopy(oneGridSearchConfigurationDict)
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['value'] = [learningRate]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['scheduleType'] = \
                                                                                         [learningRate_scheduler]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['min_lr'] = [learningRate_min_lr]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['max_lr'] = [learningRate_max_lr]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['cycle_length'] = \
                                                                                      [learningRate_cycle_length]
                    oneConfigurationDict['learningRate_phase_'+str(self.phase)]['inc_fraction'] = \
                                                                                      [learningRate_inc_fraction]
                    oneConfigurationDict['weightDecay']['phase_'+str(self.phase)] = [weightDecay]
                    oneConfigurationDict['epochs']['phase_'+str(self.phase)] = [epochs]
                    gc.collect()
                    cdnnModel_forSplit_forConfiguration = cdnn.CausalDeepNeuralNetwork(\
                                                             cvFold = self.cvSplits.cvList[split],\
                                                             dataConfigDict = self.dataConfigDict,\
                                                             modelingChoicesDict = self.modelingChoicesDict,\
                                                             hyperparameterConfigurationDict =  oneConfigurationDict,\
                                                             logger = self.logger, phase = self.phase)
                    # train data iterator
                    cdnnModel_forSplit_forConfiguration.create_data_iterator(\
                                                        self.cvSplits.cvList[split]['dfFeaturesTrain'], \
                                                        self.cvSplits.cvList[split]['dfInterventionsTrain'], \
                                                        self.cvSplits.cvList[split]['dfTargetsTrain'],\
                                                        self.cvSplits.cvList[split]['dfInstanceWeightsTrain'],\
                                                        isTrain = True, shuffle=True, last_batch = 'pad')
                    # validation data iterator
                    if len(self.cvSplits.cvList[split]['dfFeaturesValid']) > 0:
                        cdnnModel_forSplit_forConfiguration.create_data_iterator(\
                                                        self.cvSplits.cvList[split]['dfFeaturesValid'], \
                                                        self.cvSplits.cvList[split]['dfInterventionsValid'], \
                                                        self.cvSplits.cvList[split]['dfTargetsValid'],\
                                                        self.cvSplits.cvList[split]['dfInstanceWeightsValid'],\
                                                        isTrain = False, shuffle=True, last_batch = 'pad')  
                    # if loading from previous epoch, we do not need to initialize the newly unfrozen layers.
                    initialize = True
                    if previousEpochs > 0:
                        self.logger.write('loading parameters from previous epoch model. additional epochs would be ' +\
                                          str(epochs - previousEpochs), 4)
                        # load parameters from disk
                        cdnnModel_forSplit_forConfiguration.net.load_parameters(epochModelName[previousEpochs],\
                                                                         ctx=cdnnModel_forSplit_forConfiguration.ctx)
                        initialize = False
                    else:
                        self.logger.write('loading parameters from first phase model for split '+str(split), 4)
                        # load parameters from disk
                        cdnnModel_forSplit_forConfiguration.net.load_parameters(firstPhaseModelName,\
                                                                         ctx=cdnnModel_forSplit_forConfiguration.ctx)
                    
                    cdnnModel_forSplit_forConfiguration.setLearningRateEpochsAndTrainer(phase = 2)
                    # if we prefix the network name with 'nofreeze' in the cofig file, we don't freeze layers.
                    if not self.modelingChoicesDict['modelSpecs']['network'].lower().startswith('nofreeze'):
                        if self.modelingChoicesDict['modelSpecs']['computeOutcomeResidualExplicitly']>0:
                            # only unfreeze need to be done; no freezing of any layer happens
                            cdnnModel_forSplit_forConfiguration.phaseTwoWeightUnfreezeOnly(initialize = initialize)
                        else:
                            # only parameters are loaded from previous epoch; so weight freezing has to be done anyway
                            # unfreeze treatment layers and freeze feature layers
                            cdnnModel_forSplit_forConfiguration.phaseTwoWeightFreezeAndUnfreeze(initialize = initialize)
                        
                    cdnnModel_forSplit_forConfiguration.trainModel(startEpochNumber = previousEpochs)
                    # saving models for lower epoch numbers so that training sofar can be reused.
                    epochModelName[epochs] = os.path.join(self.dataConfigDict['localPaths']\
                                                       ['modelArtifactsScratchDirectoryName'], \
                                                        'model_'+str(split)+'_'+str(epochs))
                    cdnnModel_forSplit_forConfiguration.net.save_parameters(epochModelName[epochs])
                    # getting predictions
                    yf_train_prediction = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                                       self.cvSplits.cvList[split]['dfFeaturesTrain'], \
                                                       self.cvSplits.cvList[split]['dfInterventionsTrain'],\
                                                       self.cvSplits.cvList[split]['dfInstanceWeightsTrain'])
                    metricsDictTrain = self.getMetricsOnPredictions(self.cvSplits.cvList[split]\
                                               ['dfTargetsTrain'].values, yf_train_prediction)
                    
                    if len(self.cvSplits.cvList[split]['dfTargetsValid']) > 0:
                        yf_valid_prediction = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                                       self.cvSplits.cvList[split]['dfFeaturesValid'], \
                                                       self.cvSplits.cvList[split]['dfInterventionsValid'],\
                                                       self.cvSplits.cvList[split]['dfInstanceWeightsValid'])
                        metricsDictValid = self.getMetricsOnPredictions(self.cvSplits.cvList[split]\
                                                   ['dfTargetsValid'].values, yf_valid_prediction)
                        if metricsDictValid[metricsDictValid['metricToMinimize']]  < \
                                                                    self.cvSplits.cvList[split]['bestMetricValid']:
                            self.cvSplits.cvList[split]['bestMetricValid'] = \
                                                                metricsDictValid[metricsDictValid['metricToMinimize']] 
                            self.cvSplits.cvList[split]['metricTrain'] = metricsDictTrain[metricsDictTrain['metricToMinimize']] 
                            self.cvSplits.cvList[split]['bestConfigPhase_'+str(self.phase)] = oneConfigurationDict
                            self.cvSplits.cvList[split]['bestModelPhase_'+str(self.phase)] = \
                                                                              cdnnModel_forSplit_forConfiguration
                    else:
                        metricsDictValid = {'negOfAUC' : 1000, 'RMSE' : -1000, 'MAE' : -1000, 'ME' : -1000,\
                                                                                              'metricToMinimize' : 'RMSE'}
                        metricsDictValid['metricToMinimize'] = metricsDictTrain['metricToMinimize']
                        self.cvSplits.cvList[split]['metricTrain'] = metricsDictTrain[metricsDictTrain['metricToMinimize']]
                        self.cvSplits.cvList[split]['bestConfigPhase_'+str(self.phase)] = oneConfigurationDict
                        self.cvSplits.cvList[split]['bestModelPhase_'+str(self.phase)] = \
                                                                           cdnnModel_forSplit_forConfiguration                        
                    configAndSplitEndTime = time.time()
                    totalTime = int(float(configAndSplitEndTime - configAndSplitStartTime)/60)
                    self.logger.write('configNum: ' + str(self.configNum) + ', cvSplitNum: ' + str(split) +\
                              ", phase: " + str(self.phase) + ", learningRate: " + str(learningRate) + \
                              ", learningRate_scheduler: " + str(learningRate_scheduler) +\
                              ", learningRate_min_lr: " + str(learningRate_min_lr) + ", learningRate_max_lr: " + \
                              str(learningRate_max_lr) + ", learningRate_cycle_length: " + str(learningRate_cycle_length) +\
                              ", learningRate_inc_fraction: " + str(learningRate_inc_fraction) + ", weightDecay: " + \
                              str(weightDecay) + ", epochs: " + str(epochs), 3)
                    self.logger.write('configNum: '+str(self.configNum)+ ', cvSplitNum: '+str(split) +\
                                      ', TrainMetric: '+str(metricsDictTrain[metricsDictTrain['metricToMinimize']])+\
                                      ', ValidMetric: '+str(metricsDictValid[metricsDictValid['metricToMinimize']]) +\
                                      ', TimeTaken - previousEpochTime: '+str(totalTime), 2)
                    self.logger.write('------------------', 3)
                    previousEpochs = epochs   
                    # if valid_fraction is 0, there is no tuning possilbe.
                    # Return the current model that was trained using the first element of parameters' list.
                    if self.modelingChoicesDict['cvSetup']['valid_fraction'] <= 0:
                        return

                
            
    def getBestConfig(self, phase = 2):
        bestConfigList = []
        if self.phase < phase:
            phase = self.phase
            self.logger.write('Phase asked is not trained yet, saving the latest trained phase '+str(phase), 2)
            
        if self.ensemble:
            bestConfigList = [self.cvSplits.cvList[split]['bestConfigPhase_'+str(phase)] for split in \
                                                                      range(len(self.cvSplits.cvList))]
        else:
            bestConfigList = [self.cvSplits.bestConfigPhase_2] if phase == 2 else \
                                                                     [self.cvSplits.bestConfigPhase_1]
        return bestConfigList
            
    def getChosenParameters(self, phase = 1, split = -1):
        verboseLevel = 3
        if self.phase < phase:
            phase = self.phase
            self.logger.write('Phase asked is not trained yet, saving the latest trained phase '+str(phase), 2)
        if phase > 1:
            if split > 0:
                configDictList = [self.cvSplits.cvList[split]['bestConfigPhase_2']]
            elif self.ensemble:
                configDictList = []
                for split in range(len(self.cvSplits.cvList)):
                    # need to change hardcoding here (assuming it is only 2 phase), later.
                    configDictList.append(self.cvSplits.cvList[split]['bestConfigPhase_2'])
            else:
                configDictList = [self.cvSplits.bestConfigPhase_2]
        else:
            if split > 0:
                configDictList = [self.cvSplits.cvList[split]['bestConfigPhase_1']]
            elif self.ensemble:
                configDictList = []
                for split in range(len(self.cvSplits.cvList)):
                    # need to change hardcoding here (assuming it is only 2 phase), later.
                    configDictList.append(self.cvSplits.cvList[split]['bestConfigPhase_1'])
            else:
                configDictList = [self.cvSplits.bestConfigPhase_1]
               
        for split in range(len(configDictList)):
            configDict = configDictList[split]
            self.logger.write('phase '+str(phase)+'; split '+str(split), verboseLevel)
            self.logger.write('batchSize '+str(configDict['dataBatch']['value']), verboseLevel)
            self.logger.write('numFeatureOnlyLayers '+str(configDict['numLayers']['numFeatureOnlyLayers']), verboseLevel)
            self.logger.write('numTreatmentOnlyLayers '+str(configDict['numLayers']['numTreatmentOnlyLayers']), verboseLevel)
            self.logger.write('numRegressionLayers '+str(configDict['numLayers']['numRegressionLayers']), verboseLevel)
            self.logger.write('dimFeatureOnlyLayers '+str(configDict['dimLayers']['dimFeatureOnlyLayers']), verboseLevel)
            self.logger.write('dimTreatmentOnlyLayers '+str(configDict['dimLayers']['dimTreatmentOnlyLayers']), verboseLevel)
            self.logger.write('dimRegressionLayers '+str(configDict['dimLayers']['dimRegressionLayers']), verboseLevel)
            self.logger.write('weightInitializerToUse '+str(configDict['weightInitializerToUse']['value']), verboseLevel)
            self.logger.write('weightInitializerToUse_sigma '+str(configDict['weightInitializerToUse']['sigma']), verboseLevel)
            self.logger.write('weightInitializerToUse_scale '+str(configDict['weightInitializerToUse']['scale']), verboseLevel)
            self.logger.write('weightInitializerToUse_constant '+str(configDict['weightInitializerToUse']['constant']), verboseLevel)
            self.logger.write('weightInitializerToUse_magnitude '+str(configDict['weightInitializerToUse']['magnitude']), verboseLevel)
            self.logger.write('activationFunction '+str(configDict['activationFunction']['value']), verboseLevel)
            self.logger.write('activationFunction_beta '+str(configDict['activationFunction']['beta']), verboseLevel)
            self.logger.write('batchNormalization'+str(configDict['batchNormalization']['apply']), verboseLevel)
            self.logger.write('batchNormalization_momentum '+str(configDict['batchNormalization']['momentum']), verboseLevel)
            self.logger.write('dropoutRateRegression '+str(configDict['dropoutRateRegression']['value']), verboseLevel)
            self.logger.write('loss '+str(configDict['loss']['value']), verboseLevel)
            self.logger.write('optimizer'+str(configDict['optimizer']['value']), verboseLevel)        
            for p in range(1, phase+1):
                self.logger.write('learningRate_phase_'+str(p)+' '+str(configDict['learningRate_phase_'+str(p)]['value']), \
                                                                                                         verboseLevel)
                self.logger.write('learningRate_scheduleType_phase_'+str(p)+' '+str(configDict['learningRate_phase_'+str(p)]\
                                                                                    ['scheduleType']), verboseLevel)
                self.logger.write('learningRate_min_lr_phase_'+str(p)+' '+str(configDict['learningRate_phase_'+str(p)]['min_lr']), \
                                                                                                         verboseLevel)
                self.logger.write('learningRate_max_lr_phase_'+str(p)+' '+str(configDict['learningRate_phase_'+str(p)]['max_lr']), \
                                                                                                         verboseLevel)
                self.logger.write('learningRate_cycle_length_phase_'+str(p)+' '+str(configDict['learningRate_phase_'+str(p)]\
                                                                                   ['cycle_length']), verboseLevel)
                self.logger.write('learningRate_inc_fraction_phase_'+str(p)+' '+str(configDict['learningRate_phase_'+str(p)]\
                                                                                   ['inc_fraction']), verboseLevel)
                self.logger.write('weightDecay_phase_'+str(p)+' '+str(configDict['weightDecay']['phase_'+str(p)]), verboseLevel)
                self.logger.write('epochs_phase_'+str(p)+' '+str(configDict['epochs']['phase_'+str(p)]), verboseLevel)


    def getPredictionsUsingSelectedModel(self, phase, dfFeatures, dfInterventions, instanceWeight = mxnet.nd.array([])):
        if self.phase < phase:
            phase = self.phase
            self.logger.write('Phase asked is not trained yet, using the latest trained phase '+str(phase), 2)
            
        if self.ensemble:
            modelList = [self.cvSplits.cvList[split]['bestModelPhase_'+str(phase)] for split in \
                                                                                      range(len(self.cvSplits.cvList))]
        else:
            # self.cvSplits.bestModelPhase_1 and self.cvSplits.bestModelPhase_2 are both lists.
            # here the predictions are using models trained using same configuration but different train-valid splits.
            modelList = self.cvSplits.bestModelPhase_1 if phase == 1 else self.cvSplits.bestModelPhase_2
        
        #  here we get predictions with each model and then average the predictions.
        predictionsAverage = modelList[0].getPredictions(dfFeatures, dfInterventions, instanceWeight)
        for split in range(1,len(modelList)):
            predictionsAverage = np.add(predictionsAverage, modelList[split].getPredictions(dfFeatures, dfInterventions, \
                                                                                            instanceWeight))
        return predictionsAverage/len(modelList)  
    
    def saveSelectedModel(self, phase):
        if self.phase < phase:
            phase = self.phase
            self.logger.write('Phase asked is not trained yet, saving the latest trained phase '+str(phase), 2)
            
        if self.ensemble:
            modelList = [self.cvSplits.cvList[split]['bestModelPhase_'+str(phase)] for split in \
                                                                                      range(len(self.cvSplits.cvList))]
            prefix = 'bestModelEnsemble_subModelNum_'
        else:
            modelList = self.cvSplits.bestModelPhase_1 if phase == 1 else self.cvSplits.bestModelPhase_2     
            prefix = 'bestModelNonEnsemble_modelInstanceNum_'
            
        for modelNum in range(len(modelList)):
            modelList[modelNum].net.export(os.path.join(self.dataConfigDict['localPaths']['modelArtifactsBaseDirectoryName'], \
                                                        prefix+str(modelNum)+'_phase_'+str(phase)))
            self.logger.write('Saving model '+ os.path.join(self.dataConfigDict['localPaths']\
                                         ['modelArtifactsBaseDirectoryName'], prefix+str(modelNum)+'_phase_'+str(phase)), 4)
    
    def getTrainAndValidMetricsFromSelectedModel(self):
        trainMetric = [self.cvSplits.cvList[split]['metricTrain'] for split in range(len(self.cvSplits.cvList))]
        validMetric = [self.cvSplits.cvList[split]['bestMetricValid'] for split in range(len(self.cvSplits.cvList))]
        return trainMetric, validMetric