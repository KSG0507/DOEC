import sys
import os
import time
import math
import mxnet
import pandas as pd
import numpy as np
import sklearn
from sklearn import metrics
import random
import itertools
import copy
import gc
import warnings
import copy
import subprocess

from modeling import cdnn

class ModelingIterator(object):
    """
    TODO: Currently this does random split of data into train and test
    repeatedly n = modelingChoicesDict[cvSetup][numSplitForGettingConfidenceIntervals] times
    to compute confidence intervals. We can implement BLB, although I don't expect too much 
    difference in std. dev. between bootstrapping and cross validation.
    """
    def __init__(self, dataConfigDict, modelingChoicesDict, bestConfigList, dfData, modelingDataObj, logger):
        # get dfData as concatenation of cvSplits.dfTrain, cvSplits.dfTest and pass to here.
        # all the scaling and onehotencoding has been done by now.
        # we need modelingDataObj created earlier, so that the variable names created in one hot encoding can be used here.
        self.logger = logger
        self.dataConfigDict = dataConfigDict
        self.modelingChoicesDict = modelingChoicesDict
        self.bestConfigList = bestConfigList
        self.dfData = dfData
        self.modelingDataObj = modelingDataObj
        self.numSplits = self.modelingChoicesDict['cvSetup']['numSplitForGettingConfidenceIntervals']
        # TODO: need to modify iterator to consider AUC or other classification error metric for classification problem type
        self.classificationProblem = True if len(self.dataConfigDict['targets']['binaryTargetNames']) > 0 else False
    
    def getRegressionMetrics(self, actual, prediction):
        RMSE = math.sqrt(metrics.mean_squared_error(actual, prediction))
        MAE = metrics.mean_absolute_error(actual, prediction)
        ME = np.mean(actual) - np.mean(prediction)
        return RMSE, MAE, ME
    
    def crossValidate(self):
        dfTreatmentEffectsMetrics = pd.DataFrame(columns = ['intervention', 'target', 'trainOrTest', \
                                        'meanEstimatedTreatmentEffect', 'RMSE', 'MAE', 'ME', 'iterationNum'])
        dfOutcomeMetrics = pd.DataFrame(columns = ['y_train_mean', 'y_test_mean', 'y_train_RMSE', 'y_train_MAE',\
                                  'y_train_ME', 'y_test_RMSE', 'y_test_MAE', 'y_test_ME', 'iterationNum'])
        for i in range(self.modelingChoicesDict['cvSetup']['numSplitForGettingConfidenceIntervals']):
            dfTreatmentEffectsMetrics_i, resultsDict = self.runEndToEndOnOneRandomSplit(i)
            print i, dfTreatmentEffectsMetrics_i
            dfTreatmentEffectsMetrics = pd.concat([dfTreatmentEffectsMetrics, dfTreatmentEffectsMetrics_i])
            dfOutcomeMetrics = dfOutcomeMetrics.append(resultsDict, ignore_index=True)

        # adding columns and aggregation logic to compute the mean and std dev for treatment effect.
        aggTreatmentEffectMetricsDict = {}                                          
        for column in ['meanEstimatedTreatmentEffect', 'RMSE', 'MAE', 'ME']:
            dfTreatmentEffectsMetrics[column] = dfTreatmentEffectsMetrics[column].astype(float)            
            dfTreatmentEffectsMetrics[column+'_mean'] = dfTreatmentEffectsMetrics[column]
            dfTreatmentEffectsMetrics[column+'_std'] = dfTreatmentEffectsMetrics[column]  
            aggTreatmentEffectMetricsDict[column+'_mean'] = np.average
            aggTreatmentEffectMetricsDict[column+'_std'] = np.std

        # adding columns and aggregation logic to compute the mean and std dev for outcome metrics.
        aggOutcomeMetricsDict = {}            
        for column in ['y_train_mean', 'y_test_mean', 'y_train_RMSE', 'y_train_MAE',\
                                            'y_train_ME', 'y_test_RMSE', 'y_test_MAE', 'y_test_ME']:
            dfOutcomeMetrics[column] = dfOutcomeMetrics[column].astype(float)
            dfOutcomeMetrics[column+'_mean'] = dfOutcomeMetrics[column]
            dfOutcomeMetrics[column+'_std'] = dfOutcomeMetrics[column]  
            aggOutcomeMetricsDict[column+'_mean'] = np.average
            aggOutcomeMetricsDict[column+'_std'] = np.std
            
            
        # saving before aggregating
        dfTreatmentEffectsMetrics.to_csv(os.path.join(self.dataConfigDict['localPaths']['resultsDirectoryName'],\
                                                'treatmentEffectsMetricsAllIterations.csv'), index=False)
        dfOutcomeMetrics.to_csv(os.path.join(self.dataConfigDict['localPaths']['resultsDirectoryName'],\
                                                'outcomeMetricsAllIterations.csv'), index=False)
        # groupby aggregate to get the mean and stddev of each of these metrics
        dfTreatmentEffectsMetricsSummary = dfTreatmentEffectsMetrics.groupby(['intervention', 'target', 'trainOrTest'],\
                                             as_index=False).agg(aggTreatmentEffectMetricsDict)
        # dummy column to groupby (so that all the rows are aggregated). Can be done by other ways also.
        dfOutcomeMetrics['outcomeMetrics'] = 'outcomeMetrics'
        dfOutcomeMetricsSummary = dfOutcomeMetrics.groupby(['outcomeMetrics'],\
                                             as_index=False).agg(aggOutcomeMetricsDict)     
        dfTreatmentEffectsMetricsSummary.to_csv(os.path.join(self.dataConfigDict['localPaths']['resultsDirectoryName'],\
                                                'treatmentEffectsMetricsSummary.csv'), index=False)
        dfOutcomeMetricsSummary.to_csv(os.path.join(self.dataConfigDict['localPaths']['resultsDirectoryName'],\
                                                'outcomeMetricsCrossValidationSummary.csv'), index=False)
        return dfTreatmentEffectsMetrics, dfOutcomeMetrics, dfTreatmentEffectsMetricsSummary, dfOutcomeMetricsSummary
    
    def runEndToEndOnOneRandomSplit(self, iterationNum):  
        resultsDirectoryForOneSplit = os.path.join(self.dataConfigDict['localPaths']['resultsDirectoryName'],\
                                                                                            str(iterationNum))
        # subprocess.check_output(['mkdir', '-p', resultsDirectoryForOneSplit])
        dfTrain, dfTest = self.modelingDataObj.doRandomSplit(self.dfData, test_size = \
                                                self.modelingChoicesDict['cvSetup']['test_fraction'])
        [dfInstanceIdsTrain, dfInstanceWeightsTrain, dfFeaturesTrain, dfInterventionsTrain, dfTargetsTrain, \
         dfActualTreatmentEffectsTrain] = self.modelingDataObj.\
                                       getInstanceIdWeightFeaturesInterventionsTargetActualTreatmentEffects(dfTrain)
        [dfInstanceIdsTest, dfInstanceWeightsTest, dfFeaturesTest, dfInterventionsTest, dfTargetsTest, \
         dfActualTreatmentEffectsTest] = self.modelingDataObj.\
                                        getInstanceIdWeightFeaturesInterventionsTargetActualTreatmentEffects(dfTest)
        y_train_actual = np.asarray(dfTargetsTrain)
        y_test_actual = np.asarray(dfTargetsTest)        
        resultsDict = {'y_train_mean' : dfTargetsTrain.mean(), 'y_test_mean' : dfTargetsTest.mean(),\
                       'y_train_RMSE' : 0, 'y_train_MAE' : 0, 'y_train_ME' : 0, 'y_test_RMSE' : 0,\
                       'y_test_MAE' : 0, 'y_test_ME' : 0}
        splitModelList = []
        # if ensemble, train multiple models and test on the test data.
        # numSplitsForHyperparameters is already set to 1 if not ensemble
        for split in range(self.modelingChoicesDict['cvSetup']['numSplitsForHyperparameters']):
            splitStartTime = time.time()
            # splitting train into train and validation tests. Since no tuning, validation set is not used.
            # nevertheless splitting since the tunig was done on splits and we don't want to change data size here.
            dfTrainSplit, dfValidSplit = self.modelingDataObj.doRandomSplit(dfTrain, \
                                        test_size = self.modelingChoicesDict['cvSetup']['valid_fraction'])
            splitData = {'dfTrain': dfTrainSplit, 'dfValid': dfValidSplit}
            self.logger.write('IterationNum:' + str(iterationNum) + 'Split: '+str(split)+' - train shape '+\
                              str(splitData['dfTrain'].shape)+ '. valid shape '+ str(splitData['dfValid'].shape), 6)  
            # split data into features, interventions, target etc.
            for trainOrValid in ['Train', 'Valid']:
                [dfInstanceIds, dfInstanceWeights, dfFeatures, dfInterventions, dfTargets, dfActualTreatmentEffects] = \
                                    self.modelingDataObj.getInstanceIdWeightFeaturesInterventionsTargetActualTreatmentEffects(\
                                                                                             splitData['df'+trainOrValid])
                # can be directly assigned in the above statement; but this is more readable
                splitData['dfInstanceIds' + trainOrValid] = dfInstanceIds
                splitData['dfInstanceWeights' + trainOrValid] = dfInstanceWeights
                splitData['dfFeatures' + trainOrValid] = dfFeatures
                splitData['dfInterventions' + trainOrValid] = dfInterventions
                splitData['dfTargets' + trainOrValid] = dfTargets
                splitData['dfActualTreatmentEffects' + trainOrValid] = dfActualTreatmentEffects                       

            # train on the train data. 
            modelingConfig = self.bestConfigList[split]
            cdnnModel_forSplit_forConfiguration = self.trainPhase_1_and_2(modelingConfig, splitData)
            if split <= 0:
                y_train_prediction = cdnnModel_forSplit_forConfiguration.getPredictions(dfFeaturesTrain,\
                                                               dfInterventionsTrain, dfInstanceWeightsTrain)
                y_test_prediction = cdnnModel_forSplit_forConfiguration.getPredictions(dfFeaturesTest,\
                                                               dfInterventionsTest, dfInstanceWeightsTest)
            else:
                y_train_prediction += cdnnModel_forSplit_forConfiguration.getPredictions(dfFeaturesTrain,\
                                                               dfInterventionsTrain, dfInstanceWeightsTrain)
                y_test_prediction += cdnnModel_forSplit_forConfiguration.getPredictions(dfFeaturesTest,\
                                                               dfInterventionsTest, dfInstanceWeightsTest)      
            splitModelList.append(cdnnModel_forSplit_forConfiguration)
                                                   
        dfTreatmentEffectsMetrics = self.getTreatmentEffectMetrics(splitModelList,\
                                              dfInstanceIdsTrain, dfFeaturesTrain, dfInstanceWeightsTrain,\
                                              dfTargetsTrain, dfInterventionsTrain, dfActualTreatmentEffectsTrain,\
                                              dfInstanceIdsTest, dfFeaturesTest, dfInstanceWeightsTest,\
                                              dfTargetsTest, dfInterventionsTest, dfActualTreatmentEffectsTest, \
                                              iterationNum, resultsDirectoryForOneSplit)
        dfTreatmentEffectsMetrics['iterationNum'] = iterationNum
            
        y_train_prediction /= self.modelingChoicesDict['cvSetup']['numSplitsForHyperparameters']
        RMSE, MAE, ME = self.getRegressionMetrics(actual = y_train_actual, prediction = y_train_prediction)
        resultsDict['y_train_RMSE'] = RMSE
        resultsDict['y_train_MAE'] = MAE
        resultsDict['y_train_ME'] = ME
        y_test_prediction = y_test_prediction/self.modelingChoicesDict['cvSetup']['numSplitsForHyperparameters'] 
        RMSE, MAE, ME = self.getRegressionMetrics(actual = y_test_actual, prediction = y_test_prediction)            
        resultsDict['y_test_RMSE'] = RMSE
        resultsDict['y_test_MAE'] = MAE
        resultsDict['y_test_ME'] = ME 
        resultsDict['iterationNum'] = iterationNum
        return dfTreatmentEffectsMetrics, resultsDict

    
    def getTreatmentEffectMetrics(self, splitModelList, dfInstanceIdsTrain, dfFeaturesTrain, \
                             dfInstanceWeightsTrain, dfTargetsTrain, dfInterventionsTrain, dfActualTreatmentEffectsTrain,\
                             dfInstanceIdsTest, dfFeaturesTest, dfInstanceWeightsTest, dfTargetsTest, \
                             dfInterventionsTest, dfActualTreatmentEffectsTest, iterationNum, resultsDirectoryForOneSplit):
        scoringStartTime = time.time()
        att = True if self.dataConfigDict['interventions']['treatmentEffectOnTreatedOnly'] > 0 else False
        dfTreatmentEffectsMetrics = pd.DataFrame(columns = ['intervention', 'target', 'trainOrTest', \
                                        'meanEstimatedTreatmentEffect', 'RMSE', 'MAE', 'ME'])
        interventionsList = list(dfInterventionsTrain)        
        totalInterventions = len(interventionsList)
        for interventionNum in range(len(interventionsList)):
            intervention = interventionsList[interventionNum]
            interventionsIncrementValue = self.modelingDataObj.interventionsIncrementValue
            scoringForOneInterventionStartTime = time.time()
            self.logger.write('========== intervention '+str(interventionNum)+ ': '+intervention + ' ==========', 7)
            if att:
                dfConcatTrain = pd.concat([dfInstanceIdsTrain, dfFeaturesTrain, dfInstanceWeightsTrain, dfTargetsTrain, \
                                    dfInterventionsTrain, dfActualTreatmentEffectsTrain], axis = 1)
                dfConcatTrain = dfConcatTrain[dfConcatTrain[intervention] > 0]
                dfConcatTest = pd.concat([dfInstanceIdsTest, dfFeaturesTest, dfInstanceWeightsTest, dfTargetsTest, \
                                     dfInterventionsTest, dfActualTreatmentEffectsTest], axis = 1)
                dfConcatTest = dfConcatTest[dfConcatTest[intervention] > 0]
                dfInstanceIdsTrain_forIntervention = self.modelingDataObj.getInstanceIds(dfConcatTrain)
                dfInstanceIdsTest_forIntervention = self.modelingDataObj.getInstanceIds(dfConcatTest)
                dfFeaturesTrain_forIntervention = self.modelingDataObj.getFeatures(dfConcatTrain)
                dfFeaturesTest_forIntervention = self.modelingDataObj.getFeatures(dfConcatTest)
                dfInstanceWeightsTrain_forIntervention = self.modelingDataObj.getInstanceWeights(dfConcatTrain)
                dfInstanceWeightsTest_forIntervention = self.modelingDataObj.getInstanceWeights(dfConcatTest)
                dfTargetsTrain_forIntervention = self.modelingDataObj.getTargets(dfConcatTrain)
                dfTargetsTest_forIntervention = self.modelingDataObj.getTargets(dfConcatTest)
                dfInterventionsTrain_forIntervention = self.modelingDataObj.getInterventions(dfConcatTrain)
                dfInterventionsTest_forIntervention = self.modelingDataObj.getInterventions(dfConcatTest)
                dfActualTreatmentEffectsTrain_forIntervention = self.modelingDataObj.getActualTreatmentEffects(dfConcatTrain)
                dfActualTreatmentEffectsTest_forIntervention = self.modelingDataObj.getActualTreatmentEffects(dfConcatTest)
            else:
                dfInstanceIdsTrain_forIntervention = dfInstanceIdsTrain.copy(deep = True)
                dfInstanceIdsTest_forIntervention = dfInstanceIdsTest.copy(deep = True)
                dfFeaturesTrain_forIntervention = dfFeaturesTrain
                dfFeaturesTest_forIntervention = dfFeaturesTest
                dfInstanceWeightsTrain_forIntervention = dfInstanceWeightsTrain
                dfInstanceWeightsTest_forIntervention = dfInstanceWeightsTest
                dfTargetsTrain_forIntervention = dfTargetsTrain
                dfTargetsTest_forIntervention = dfTargetsTest
                dfInterventionsTrain_forIntervention = dfInterventionsTrain.copy(deep = True)
                dfInterventionsTest_forIntervention = dfInterventionsTest.copy(deep = True)
                dfActualTreatmentEffectsTrain_forIntervention = dfActualTreatmentEffectsTrain
                dfActualTreatmentEffectsTest_forIntervention = dfActualTreatmentEffectsTest
                if interventionsIncrementValue == 0:
                    # assuming binary when it is not att and interventionsIncrementValue == 0
                    dfInterventionsTrain_forIntervention[intervention] = 1
                    dfInterventionsTest_forIntervention[intervention] = 1

            if interventionsIncrementValue > 0:
                dfInterventionsTrain_forIntervention[intervention] = dfInterventionsTrain_forIntervention[intervention] + \
                                                                        interventionsIncrementValue
                dfInterventionsTest_forIntervention[intervention] = dfInterventionsTest_forIntervention[intervention] + \
                                                                        interventionsIncrementValue
                interventionsIncrementValue = -1 * interventionsIncrementValue                 
                                                   
            cdnnModel_forSplit_forConfiguration = splitModelList[0]
            y_train_prediction_asTreatment = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                               dfFeaturesTrain_forIntervention, dfInterventionsTrain_forIntervention,\
                                                                                dfInstanceWeightsTrain_forIntervention)
            y_test_prediction_asTreatment = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                               dfFeaturesTest_forIntervention, dfInterventionsTest_forIntervention,\
                                                                                dfInstanceWeightsTest_forIntervention)
            for split in range(1, len(splitModelList)):
                cdnnModel_forSplit_forConfiguration = splitModelList[split]
                y_train_prediction_asTreatment += cdnnModel_forSplit_forConfiguration.getPredictions(\
                                                   dfFeaturesTrain_forIntervention, dfInterventionsTrain_forIntervention,\
                                                                                    dfInstanceWeightsTrain_forIntervention)
                y_test_prediction_asTreatment += cdnnModel_forSplit_forConfiguration.getPredictions(\
                                                   dfFeaturesTest_forIntervention, dfInterventionsTest_forIntervention,\
                                                                                    dfInstanceWeightsTest_forIntervention)
            y_train_prediction_asTreatment /= len(splitModelList)
            y_test_prediction_asTreatment /= len(splitModelList) 
            
            # decementing the intervention value to get y_0: prediction as control
            if interventionsIncrementValue < 0:
                dfInterventionsTrain_forIntervention[intervention] = dfInterventionsTrain_forIntervention[intervention] + \
                                                                        interventionsIncrementValue
                dfInterventionsTest_forIntervention[intervention] = dfInterventionsTest_forIntervention[intervention] + \
                                                                        interventionsIncrementValue

                dfInterventionsTrain_forIntervention[intervention] = dfInterventionsTrain_forIntervention[intervention].\
                                                                        apply(lambda x: 0 if x < 0 else x)
                dfInterventionsTest_forIntervention[intervention] = dfInterventionsTest_forIntervention[intervention].\
                                                                        apply(lambda x: 0 if x < 0 else x)

            else:
                dfInterventionsTrain_forIntervention[intervention] = 0
                dfInterventionsTest_forIntervention[intervention] = 0
                  
            cdnnModel_forSplit_forConfiguration = splitModelList[0]
            y_train_prediction_asControl = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                               dfFeaturesTrain_forIntervention, dfInterventionsTrain_forIntervention,\
                                                                                dfInstanceWeightsTrain_forIntervention)
            y_test_prediction_asControl = cdnnModel_forSplit_forConfiguration.getPredictions(\
                                               dfFeaturesTest_forIntervention, dfInterventionsTest_forIntervention,\
                                                                                dfInstanceWeightsTest_forIntervention)
            for split in range(1, len(splitModelList)):
                cdnnModel_forSplit_forConfiguration = splitModelList[split]
                y_train_prediction_asControl += cdnnModel_forSplit_forConfiguration.getPredictions(\
                                                   dfFeaturesTrain_forIntervention, dfInterventionsTrain_forIntervention,\
                                                                                    dfInstanceWeightsTrain_forIntervention)
                y_test_prediction_asControl += cdnnModel_forSplit_forConfiguration.getPredictions(\
                                                   dfFeaturesTest_forIntervention, dfInterventionsTest_forIntervention,\
                                                                                    dfInstanceWeightsTest_forIntervention)
            y_train_prediction_asControl /= len(splitModelList)
            y_test_prediction_asControl /= len(splitModelList)
                                       
            # computing treatment effects at individual level for.
            te_train_prediction = y_train_prediction_asTreatment - y_train_prediction_asControl    
            te_test_prediction = y_test_prediction_asTreatment - y_test_prediction_asControl
            targetsList = list(dfTargetsTrain)
            for i in range(len(targetsList)):
                target = targetsList[i]
                dfInstanceIdsTrain_forIntervention['prediction:'+intervention+'->'+target] = te_train_prediction[:,i].ravel()   
                dfInstanceIdsTest_forIntervention['prediction:'+intervention+'->'+target] = te_test_prediction[:,i].ravel()    
                meanTreatmentEffectTrain = te_train_prediction[:,i].mean()
                meanTreatmentEffectTest = te_test_prediction[:,i].mean()        
                self.logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+\
                             ' in train: '+str(meanTreatmentEffectTrain), 6)   
                self.logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+\
                             ' in test: '+str(meanTreatmentEffectTest), 6)        
                trainRMSE = -99999.9
                trainMAE = -99999.9
                trainME = -99999.9
                testRMSE = -99999.9
                testMAE = -99999.9
                testME = -99999.9
                if intervention in self.modelingDataObj.actualTreatmentEffectsDict.keys() and \
                    target in self.modelingDataObj.actualTreatmentEffectsDict[intervention]:
                    actualTreatmentEffectColumn = self.modelingDataObj.actualTreatmentEffectsDict[intervention][target] 
                    trainRMSE, trainMAE, trainME = self.getRegressionMetrics(actual = \
                                     dfActualTreatmentEffectsTrain_forIntervention[[actualTreatmentEffectColumn]].values, \
                                                                                 prediction = te_train_prediction[:,i])
                    testRMSE, testMAE, testME = self.getRegressionMetrics(actual = \
                                     dfActualTreatmentEffectsTest_forIntervention[[actualTreatmentEffectColumn]].values, \
                                                                                  prediction = te_test_prediction[:,i])
                    self.logger.write('>>> treatment effect prediction ('+intervention+','+ target +\
                                 ') vs actual in train: RMSE: '+str(trainRMSE) + ' ME: '+\
                                 str(trainME), 6)
                    self.logger.write('>>> treatment effect prediction ('+intervention+','+ target +\
                                 ') vs actual in test: RMSE: '+str(testRMSE) + ' ME: '+\
                                 str(testME), 6)     
                dfTreatmentEffectsMetrics = dfTreatmentEffectsMetrics.append({'intervention': intervention,\
                                            'target': target, 'trainOrTest': 'train', \
                                            'meanEstimatedTreatmentEffect': meanTreatmentEffectTrain,\
                                            'RMSE' : trainRMSE, 'MAE' : trainMAE, 'ME' : trainME}, ignore_index=True)
                dfTreatmentEffectsMetrics = dfTreatmentEffectsMetrics.append({'intervention': intervention,\
                                            'target': target, 'trainOrTest': 'test', \
                                            'meanEstimatedTreatmentEffect': meanTreatmentEffectTest,\
                                            'RMSE' : testRMSE, 'MAE' : testMAE, 'ME' : testME}, ignore_index=True)

            scoringForOneInterventionEndTime = time.time()
            self.logger.write('Time for scoring for one intervention: ' + \
                            str(round((scoringForOneInterventionEndTime - \
                            scoringForOneInterventionStartTime)/60,2)) + ' minutes\n', 8)  
            # dfInstanceIdsTrain_forIntervention.to_csv(os.path.join(resultsDirectoryForOneSplit,\
            #                                                'treatmentEffectTrain_' + intervention + '.csv'), index=False)
            # dfInstanceIdsTest_forIntervention.to_csv(os.path.join(resultsDirectoryForOneSplit,\
            #                                                'treatmentEffectTest_' + intervention + '.csv'), index=False)    
        scoringEndTime = time.time()    
        self.logger.write('Total time for scoring: ' + \
                str(round((scoringEndTime - scoringStartTime)/60,2)) + ' minutes\n', 8)      
        return dfTreatmentEffectsMetrics
        

    def trainPhase_1_and_2(self, oneConfigurationDict, cvFold):
        cdnnModel_forSplit_forConfiguration = cdnn.CausalDeepNeuralNetwork(\
                                                 cvFold = cvFold,\
                                                 dataConfigDict = self.dataConfigDict,\
                                                 modelingChoicesDict = self.modelingChoicesDict,\
                                                 hyperparameterConfigurationDict =  oneConfigurationDict,\
                                                 logger = self.logger, phase = 1)
        # train data iterator
        cdnnModel_forSplit_forConfiguration.create_data_iterator(\
                                            cvFold['dfFeaturesTrain'], \
                                            cvFold['dfInterventionsTrain'], \
                                            cvFold['dfTargetsTrain'],\
                                            cvFold['dfInstanceWeightsTrain'],\
                                            isTrain = True, shuffle=True, last_batch = 'pad')
        if not self.modelingChoicesDict['modelSpecs']['network'].lower().startswith('nofreeze'):
            cdnnModel_forSplit_forConfiguration.phaseOneWeightFreeze()
            
        cdnnModel_forSplit_forConfiguration.trainModel(startEpochNumber = 0)
        cdnnModel_forSplit_forConfiguration.setLearningRateEpochsAndTrainer(phase = 2)
        if not self.modelingChoicesDict['modelSpecs']['network'].lower().startswith('nofreeze'):
            cdnnModel_forSplit_forConfiguration.phaseTwoWeightFreezeAndUnfreeze(initialize = True)
            
        cdnnModel_forSplit_forConfiguration.trainModel(startEpochNumber = 0)
        return cdnnModel_forSplit_forConfiguration
                    
            
