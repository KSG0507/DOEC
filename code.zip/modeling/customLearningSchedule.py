import math
import copy
from mxnet import lr_scheduler

# From :
#    https://mxnet.incubator.apache.org/tutorials/gluon/learning_rate_schedules_advanced.html
#    https://mxnet.incubator.apache.org/tutorials/gluon/learning_rate_schedules.html


class TriangularSchedule(lr_scheduler.LRScheduler):

    def __init__(self, learningRateDict):
        """
        min_lr: lower bound for learning rate (float)
        max_lr: upper bound for learning rate (float)
        cycle_length: iterations between start and finish (int)
        inc_fraction: fraction of iterations spent in increasing stage (float)
        """
        self.min_lr = learningRateDict['min_lr']
        self.max_lr = learningRateDict['max_lr']
        self.cycle_length = learningRateDict['cycle_length']
        self.inc_fraction = learningRateDict['inc_fraction']

    def __call__(self, iteration, cycle_length = -10):
        if cycle_length > 0:
            self.cycle_length = cycle_length
        if iteration <= self.cycle_length*self.inc_fraction:
            unit_cycle = iteration * 1 / (self.cycle_length * self.inc_fraction)
        elif iteration <= self.cycle_length:
            unit_cycle = (self.cycle_length - iteration) * 1 / (self.cycle_length \
                                                          * (1 - self.inc_fraction))
        else:
            unit_cycle = 0
            
        adjusted_cycle = (unit_cycle * (self.max_lr - self.min_lr)) + self.min_lr
        return adjusted_cycle