import sys
import os
import time
import math
import mxnet
import pandas as pd
import numpy as np
import random
from mxnet import gluon
from mxnet.gluon.data import DataLoader
from mxnet.gluon.data import ArrayDataset

from modeling import keralaNet
# from modeling import evaluate
from modeling import customLearningSchedule


class CausalDeepNeuralNetwork(object):
    # hyperparameterConfigurationDict here is assumed to have singe values in lists
    def __init__(self, cvFold, dataConfigDict, modelingChoicesDict, hyperparameterConfigurationDict, logger, phase = 1):
        self.dataConfigDict = dataConfigDict
        self.modelingChoicesDict = modelingChoicesDict
        self.hyperparameterConfigurationDict = hyperparameterConfigurationDict
        self.logger = logger
        self.ctx =  self.getMxnetContext()
        self.phase = phase
        self.numFeatureOnlyLayers = self.hyperparameterConfigurationDict['numLayers']['numFeatureOnlyLayers'][0]
        self.numTreatmentOnlyLayers = self.hyperparameterConfigurationDict['numLayers']['numTreatmentOnlyLayers'][0]
        self.numConcatenationLayers = 1
        self.numRegressionLayers = self.hyperparameterConfigurationDict['numLayers']['numRegressionLayers'][0]
        self.dimFeatureOnlyLayers = self.hyperparameterConfigurationDict['dimLayers']['dimFeatureOnlyLayers'][0]
        self.dimTreatmentOnlyLayers = self.hyperparameterConfigurationDict['dimLayers']['dimTreatmentOnlyLayers'][0]
        # self.dimConcatenationLayers has not effect; it assumes the dimension from regression layer
        self.dimConcatenationLayers = self.hyperparameterConfigurationDict['dimLayers']['dimConcatenationLayers'][0]
        self.dimRegressionLayers = self.hyperparameterConfigurationDict['dimLayers']['dimRegressionLayers'][0]
        self.dropoutRateRegression = self.hyperparameterConfigurationDict['dropoutRateRegression']['value'][0]
        self.activationFunction = self.hyperparameterConfigurationDict['activationFunction']['value'][0]
        self.betaForActivation = self.hyperparameterConfigurationDict['activationFunction']['beta'][0]
        self.batchNormalization = True if self.hyperparameterConfigurationDict['batchNormalization']['apply'][0] > 0 else False
        self.momentumForBatchNormalization = self.hyperparameterConfigurationDict['batchNormalization']['momentum'][0]
        self.numberOfOutcomes = cvFold['dfTargetsTrain'].shape[1]
        self.batchSize = self.hyperparameterConfigurationDict['dataBatch']['value'][0]
        self.classificationProblem = True if len(self.dataConfigDict['targets']['binaryTargetNames']) > 0 else False
        self.logger.write('Classification problem? '+str(self.classificationProblem), 5)
        self.setLoss()       
        self.makeNetwork()
        self.initializeNetwork(self.net, self.hyperparameterConfigurationDict['weightInitializerToUse']['value'][0])  
        self.setLearningRateEpochsAndTrainer(phase = self.phase)
        self.validationData = False
        self.dfTrainingStats = pd.DataFrame()
        self.dfValidationStats = pd.DataFrame()

    def getMxnetContext(self):
        if self.modelingChoicesDict['environmentVariables']['gpu'] > 0:
            return mxnet.gpu()
        else:
            return mxnet.cpu() 
        
    def setLoss(self):
        # Setting up loss function
        if self.hyperparameterConfigurationDict['loss']['value'][0].lower() =='l2':
            self.logger.write("L2 loss selected (mean squared error between pred and label)", 5)
            self.loss = gluon.loss.L2Loss()
        elif self.hyperparameterConfigurationDict['loss']['value'][0].lower() =='l1':
            self.logger.write( "L1 loss selected (absolute error between pred and label)", 5)
            self.loss = gluon.loss.L1Loss()
        elif self.hyperparameterConfigurationDict['loss']['value'][0].lower() =='log':
            self.logger.write( "Logistic loss selected (for binary losses only)", 5)
            self.loss = gluon.loss.LogisticLoss()
        elif self.hyperparameterConfigurationDict['loss']['value'][0].lower() =='sigmoid':
            self.logger.write( "Sigmoid binary cross-entropy loss (the cross-entropy loss for binary classification)", 5)
            self.loss = gluon.loss.SigmoidBinaryCrossEntropyLoss(from_sigmoid = True)
        elif self.hyperparameterConfigurationDict['loss']['value'][0].lower() =='softmax':
            self.logger.write( "Softmax cross-entropy loss", 5)
            self.loss = gluon.loss.SoftmaxCrossEntropyLoss()
        elif self.hyperparameterConfigurationDict['loss']['value'][0].lower() =='kldiv':
            self.logger.write( "The Kullback-Leibler divergence loss", 5)
            self.loss = gluon.loss.KLDivLoss()
        elif self.hyperparameterConfigurationDict['loss']['value'][0].lower() =='huber':
            self.logger.write( "Huber  loss (Smoothed L1 loss)", 5)
            self.loss = gluon.loss.HuberLoss()
        elif self.hyperparameterConfigurationDict['loss']['value'][0].lower() =='hinge':
            self.logger.write( "Hinge  loss", 5)
            self.loss = gluon.loss.HingeLoss()
        elif self.hyperparameterConfigurationDict['loss']['value'][0].lower() =='hinge2':
            self.logger.write( "Squared hinge  loss", 5)
            self.loss = gluon.loss.SquaredHingeLoss()
        else:
            self.logger.write( 'Incorect/unspecified weight initializer specified...', 3)
            self.logger.write( " Using L2 losss (mean squared error between pred and label)", 3)
            self.loss = gluon.loss.L2Loss()       
            
    def setLearningRateEpochsAndTrainer(self, phase = 1):
        self.phase = phase
        self.epochs = self.hyperparameterConfigurationDict['epochs']['phase_'+str(phase)][0]
        learningRate = self.hyperparameterConfigurationDict['learningRate_phase_'+str(phase)]
        weightDecay = self.hyperparameterConfigurationDict['weightDecay']['phase_'+str(phase)][0]
        if learningRate['scheduleType'][0].lower() == "none":
            self.setOptimizerForFixed()
            optimizer_params = {'learning_rate': learningRate['value'][0]}
            if weightDecay != None and weightDecay > 0:
                optimizer_params['wd'] = weightDecay
            self.trainer = gluon.Trainer(params = self.net.collect_params(), \
                                         optimizer = self.optimizer, \
                                         optimizer_params = optimizer_params)
        else:
            """ Set learning rate scheduler """
            if learningRate['scheduleType'][0].lower() == 'triangular':
                print 'Using triangular learning scheduler'
                self.lrScheduler = customLearningSchedule.TriangularSchedule(min_lr = learningRate['min_lr'][0], \
                                                                             max_lr = learningRate['max_lr'][0], \
                                                                             cycle_length = learningRate['cycle_length'][0],\
                                                                             inc_fraction = learningRate['inc_fraction'][0])
            elif learningRate['scheduleType'][0].lower() == 'cosine':
                print 'Using cosine learning scheduler'
                # optimizer = mx.optimizer.Adam
                self.lrScheduler = customLearningSchedule.CosineAnnealingSchedule(min_lr = learningRate['min_lr'][0], \
                                                                             max_lr = learningRate['max_lr'][0], \
                                                                             cycle_length = learningRate['cycle_length'][0])
            elif learningRate['scheduleType'][0].lower() == 'stepwise':
                print 'Using stepwise learning scheduler'
                self.lrScheduler = mxnet.lr_scheduler.FactorScheduler(step = self.epochs*learningRate['inc_fraction'][0], \
                                                                      factor = learningRate['factor'][0],\
                                                                      stop_factor_lr = learningRate['finish_lr'][0],\
                                                                      base_lr = learningRate['value'][0], \
                                                                      warmup_steps = learningRate['warmup_length'][0], \
                                                                      warmup_begin_lr = learningRate['warmup_start'][0])
            else:
                print 'Unknown learning scheduler specified...'
                print 'Using cosine learning scheduler instead'
                self.lrScheduler = customLearningSchedule.CosineAnnealingSchedule(min_lr = learningRate['min_lr'][0], \
                                                                                  max_lr = learningRate['max_lr'][0], \
                                                                                  cycle_length = learningRate['cycle_length'][0])
            self.setOptimizerForSchedule(learning_rate = learningRate['value'][0], lr_schedule = self.lrScheduler)
            self.trainer = gluon.Trainer(params = self.net.collect_params(), optimizer = self.optimizer)            
        
    # need to have separate setOptimizers for fixed and schedule since
    # for fixed, a string can be passed as optimizer for creating trainer while
    # for schedule, an object is passed as optimizer.
    # we may be able to do this more optimally (later)
    def setOptimizerForFixed(self):
        # Setting up optimizer
        if self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='sgd':
            self.logger.write( "The SGD optimizer with momentum and weight decay.", 5)
            self.optimizer = 'sgd'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='nag':
            self.logger.write( "Nesterov accelerated SGD.", 5)
            self.optimizer = 'nag'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='rmsprop':
            self.logger.write( "RMSProp optimizer.", 5)
            self.optimizer = 'rmsprop'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='adam':
            self.logger.write( "Adam optimizer.", 5)
            self.optimizer = 'adam'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='adagrad':
            self.logger.write( "AdaGrad optimizer.", 5)
            self.optimizer = 'adagrad'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='adadelta':
            self.logger.write( "AdaDelta optimizer.", 5)
            self.optimizer = 'adadelta'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='adamax':
            self.logger.write( "Adamax optimizer.", 5)
            self.optimizer = 'adamax'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='nadam':
            self.logger.write( "Nesterov Adam optimizer.", 5)
            self.optimizer = 'nadam'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='dcasgd':
            self.logger.write( "DCASGD optimizer.", 5)
            self.optimizer = 'dcasgd'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='sgld':
            self.logger.write( "Stochastic Gradient Riemannian Langevin Dynamics.", 5)
            self.optimizer = 'sgld'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='signum':
            self.logger.write( "Signum optimizer.", 5)
            self.optimizer = 'signum'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='ftml':
            self.logger.write( "FTML optimizer.", 5)
            self.optimizer = 'ftml'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='lbsgd':
            self.logger.write( "Large Batch SGD optimizer.", 5)
            self.optimizer = 'lbsgd'
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='ftrl':
            self.logger.write( "Ftrl optimizer.", 5)
            self.optimizer = 'ftrl'
        else:
            self.logger.write( 'Incorect/unspecified optimizer...', 5)
            self.logger.write( "Using Adam optimizer.", 5)
            self.optimizer = 'adam'
            
    # need to have separate setOptimizers for fixed and schedule since
    # for fixed, a string can be passed as optimizer for creating trainer while
    # for schedule, an object is passed as optimizer.
    # we may be able to do this more optimally (later)            
    def setOptimizerForSchedule(self, learning_rate, lr_schedule):
        # Setting up optimizer
        if self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='sgd':
            self.logger.write( "The SGD optimizer with momentum and weight decay.", 5)
            self.optimizer = mxnet.optimizer.SGD(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='nag':
            self.logger.write( "Nesterov accelerated SGD.", 5)
            self.optimizer = mxnet.optimizer.NAG(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='rmsprop':
            self.logger.write( "RMSProp optimizer.", 5)
            self.optimizer = mxnet.optimizer.RMSProp(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='adam':
            self.logger.write( "Adam optimizer.", 5)
            self.optimizer = mxnet.optimizer.Adam(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='adagrad':
            self.logger.write( "AdaGrad optimizer.", 5)
            self.optimizer = mxnet.optimizer.AdaGrad(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='adadelta':
            self.logger.write( "AdaDelta optimizer.", 5)
            self.optimizer = mxnet.optimizer.AdaDelta(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='adamax':
            self.logger.write( "Adamax optimizer.", 5)
            self.optimizer = mxnet.optimizer.Adamax(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='nadam':
            self.logger.write( "Nesterov Adam optimizer.", 5)
            self.optimizer = mxnet.optimizer.Nadam(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='dcasgd':
            self.logger.write( "DCASGD optimizer.", 5)
            self.optimizer = mxnet.optimizer.DCASGD(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='sgld':
            self.logger.write( "Stochastic Gradient Riemannian Langevin Dynamics.", 5)
            self.optimizer = mxnet.optimizer.SGLD(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='signum':
            self.logger.write( "Signum optimizer.", 5)
            self.optimizer = mxnet.optimizer.Signum(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='ftml':
            self.logger.write( "FTML optimizer.", 5)
            self.optimizer = mxnet.optimizer.FTML(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='lbsgd':
            self.logger.write( "Large Batch SGD optimizer.", 5)
            self.optimizer = mxnet.optimizer.LBSGD(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        elif self.hyperparameterConfigurationDict['optimizer']['value'][0].lower() =='ftrl':
            self.logger.write( "Ftrl optimizer.", 5)
            self.optimizer = mxnet.optimizer.Ftrl(learning_rate = learning_rate, lr_scheduler = lr_schedule)
        else:
            self.logger.write( 'Incorect/unspecified optimizer...', 5)
            self.logger.write( "Using Adam optimizer.", 5)
            self.optimizer = mxnet.optimizer.Adam(learning_rate = learning_rate, lr_scheduler = lr_schedule)        
        
    def makeNetwork(self):
        self.net = keralaNet.KeralaNet(numFeatureOnlyLayers = self.numFeatureOnlyLayers, \
                                   dimFeatureOnlyLayers = self.dimFeatureOnlyLayers, \
                                   numTreatmentOnlyLayers = self.numTreatmentOnlyLayers, \
                                   dimTreatmentOnlyLayers = self.dimTreatmentOnlyLayers, \
                                   numRegressionLayers = self.numRegressionLayers, \
                                   dimRegressionLayers = self.dimRegressionLayers, \
                                   activationFunction = self.activationFunction, \
                                   betaForActivation = self.betaForActivation, \
                                   batchNormalization = self.batchNormalization, \
                                   momentumForBatchNormalization = self.momentumForBatchNormalization, \
                                   dropoutRateRegression = self.dropoutRateRegression, \
                                   numberOfOutcomes = self.numberOfOutcomes,\
                                   classificationProblem = self.classificationProblem)

        mv = mxnet.__version__
        mv = mv.split('.')

        # Hybridize network for better performanc
        if (int(mv[0]) >= 1 and int(mv[1]) >= 3):
            # This should improve performances, but is available in version 1.3+
            self.net.hybridize(static_alloc = True, static_shape = True)
        else:
            self.net.hybridize()
            
    def meanError(self, trueValuesArray, predictedValuesArray):
        meanTrue = np.mean(trueValuesArray)
        meanPrediction = np.mean(predictedValuesArray)
        return meanTrue - meanPrediction
              
    def getEvalMetrics(self):
        # We will use composit eval metric
        evalMetrics = mxnet.metric.CompositeEvalMetric()
        if self.classificationProblem:
            acc = mxnet.metric.Accuracy()
            # topAcc = mxnet.metric.TopKAccuracy()
            f1 = mxnet.metric.F1()
            # mcc = mxnet.metric.MCC()
            # perplex = mxnet.metric.Perplexity()
            ce = mxnet.metric.CrossEntropy()
            nll = mxnet.metric.NegativeLogLikelihood()
            pc = mxnet.metric.PearsonCorrelation()
            for childMetric in [acc, f1, ce, nll, pc]:
                evalMetrics.add(childMetric)
        else:
            rmse = mxnet.metric.RMSE()
            me = mxnet.metric.create(self.meanError)
            for childMetric in [rmse, me]:
                evalMetrics.add(childMetric)

        return evalMetrics
        
        
    def initializeNetwork(self, network, initializerToUse, force_reinit=False):
        # Setting up weight initialization
        if initializerToUse.lower() == 'xavier':
            self.logger.write('Weights initialized using xavier initializator', 4)
            network.initialize(mxnet.init.Xavier(magnitude = self.hyperparameterConfigurationDict['weightInitializerToUse']\
                                                                  ['magnitude'][0]), ctx=self.ctx, force_reinit=force_reinit)
        elif initializerToUse.lower() == 'uniform':
            self.logger.write('Weights initialized based on uniform distribution', 4)
            network.initialize(mxnet.init.Uniform(scale = self.hyperparameterConfigurationDict['weightInitializerToUse']\
                                                                  ['scale'][0]), ctx=self.ctx, force_reinit=force_reinit)
        elif initializerToUse.lower() == 'normal':
            self.logger.write('Weights initialized based on normal distribution', 4)
            network.initialize(mxnet.init.Normal(sigma = self.hyperparameterConfigurationDict['weightInitializerToUse']\
                                                                  ['sigma'][0]), ctx=self.ctx, force_reinit=force_reinit)
        elif initializerToUse.lower() == 'zero':
            self.logger.write('Weights initialized to zero', 4)
            network.initialize(mxnet.init.Zero(), ctx=self.ctx, force_reinit=force_reinit)
        elif initializerToUse.lower() == 'one':
            self.logger.write('Weights initialized to one', 4)
            network.initialize(mxnet.init.One(), ctx=self.ctx, force_reinit=force_reinit)
        elif initializerToUse.lower() == 'constant':
            self.logger.write('Weights initialized to a constant value', 4)
            network.initialize(mxnet.init.Constant(constant = self.hyperparameterConfigurationDict['weightInitializerToUse']\
                                                                  ['constant'][0]), ctx=self.ctx, force_reinit=force_reinit)
        else:
            self.logger.write('Incorect weight initializer specified... ', 4)
            self.logger.write('Initializing weights based on normal distribution', 4)
            network.initialize(mxnet.init.Normal(sigma = self.hyperparameterConfigurationDict['weightInitializerToUse']\
                                                                  ['sigma'][0]), ctx=self.ctx, force_reinit=force_reinit)        
        
    def create_data_iterator(self, features, interventions, targets, instanceWeight = mxnet.nd.array([]), \
                                                                     isTrain = True, shuffle=True, last_batch = 'pad'):
        """
        TODO: to scale on very big data, we need to create our own epochs.
        We need to read from one part file and treat that as one epoch.
        Beware: Need to check if any code change here is consistent with processData.py
        """
        # to make the code work for non-causal prediction problems, no interventions are passed.
        # a dummy intervention is created so that we need not write a new definition for network.
        # please note the dummy intervention values are all 0 - no influence in training or scoring.
        if min(interventions.shape)  <= 0:
            interventions = pd.DataFrame(np.zeros((len(features), 1)), columns = ['dummyIntervention'])
        
        if len(instanceWeight) == 0:
            dataForModeling = [features, interventions, targets]
            print 'inside create_data_iterator targets.mean()', targets.mean()
        else:
            dataForModeling = [features, interventions, targets, instanceWeight] 
        
        if isTrain:
            self.trainDataSize = features.shape[0]
            # Earlier versions used mxnet.gluon.data.DataLoader; but was much slower
            self.train_iter = mxnet.io.NDArrayIter(data=dataForModeling, batch_size=self.batchSize, shuffle = shuffle, \
                                                                                           last_batch_handle=last_batch)
            self.instanceWeight = instanceWeight
            
        else:
            self.validationData = True
            self.validDataSize = features.shape[0]
            self.valid_iter = mxnet.io.NDArrayIter(data=dataForModeling, batch_size=self.batchSize, shuffle = shuffle, \
                                                                                            last_batch_handle=last_batch)
        
        
    def freezeUnfreezeOrPrintParameters(self, params, action, initialized = True):
        if action == 'freeze':
            grad_req = 'null'
        elif action == 'unfreeze':
            grad_req = 'write'
        elif action != 'print':
            self.logger.write('Error: unrecognized input - only freeze, unfreeze or print allowed', 0)
            sys.exit('Error: unrecognized input')
        for param in params:
            # Newer versions aparantly allow all the params to be frozen in one line. Need to test and make change here.
            if '_weight' in param.name:
                self.logger.write(str(param.name), 4)
                # lazy initialization - data can be printed only after one forward pass.
                if initialized:
                    self.logger.write(str(param.data()), 4)
                if action != 'print':
                    param.grad_req=grad_req
                self.logger.write('grad_req '+ str(param.grad_req), 4)
            if '_bias' in param.name:
                self.logger.write(str(param.name), 4)
                if initialized:
                    self.logger.write(str(param.data()), 4)
                if action != 'print':
                    param.grad_req=grad_req
                self.logger.write('grad_req ' + str(param.grad_req), 4)


    def phaseOneWeightFreeze(self):
        self.logger.write('Resetting initialization for treatment net to zero', 4)
        # need to freeze the treatment part of concatenation layer
        self.initializeNetwork(self.net.concatLayerTreatments, 'zero', force_reinit = True)
        self.initializeNetwork(self.net.treatmentsNet, 'zero', force_reinit = True)
        self.logger.write('Following network parameters will not be leared: ', 4)
        self.freezeUnfreezeOrPrintParameters(params = self.net.concatLayerTreatments.collect_params().values(), \
                                                action = 'freeze', initialized = False) 
        self.freezeUnfreezeOrPrintParameters(params = self.net.treatmentsNet.collect_params().values(), \
                                                action = 'freeze', initialized = False)

    def phaseTwoWeightFreezeAndUnfreeze(self, initialize = False):
        self.logger.write('Resetting initialize for treatment net to ' + \
                                       self.hyperparameterConfigurationDict['weightInitializerToUse']['value'][0].lower(), 4)
        if initialize:
            self.initializeNetwork(self.net.concatLayerTreatments, self.hyperparameterConfigurationDict\
                                       ['weightInitializerToUse']['value'][0].lower(), force_reinit = True)
            self.initializeNetwork(self.net.treatmentsNet, self.hyperparameterConfigurationDict['weightInitializerToUse']\
                                                                               ['value'][0].lower(), force_reinit = True)
        self.logger.write('Following network parameters can be learned now: ', 4)
        self.freezeUnfreezeOrPrintParameters(params = self.net.concatLayerTreatments.collect_params().values(), \
                                                                          action = 'unfreeze', initialized = False)
        self.freezeUnfreezeOrPrintParameters(params = self.net.treatmentsNet.collect_params().values(),\
                                                                          action = 'unfreeze', initialized = False)
        self.logger.write('Following network parameters will not be leared: ', 4)
        self.freezeUnfreezeOrPrintParameters(params = self.net.concatLayerFeatures.collect_params().values(), \
                                                                          action = 'freeze', initialized = False)
        self.freezeUnfreezeOrPrintParameters(params = self.net.featuresNet.collect_params().values(),\
                                                                          action = 'freeze', initialized = False)
        
    def phaseTwoWeightUnfreezeOnly(self, initialize = False):
        self.logger.write('Resetting initialize for net to ' + \
                                       self.hyperparameterConfigurationDict['weightInitializerToUse']['value'][0].lower(), 4)
        if initialize:
            self.initializeNetwork(self.net, self.hyperparameterConfigurationDict\
                                       ['weightInitializerToUse']['value'][0].lower(), force_reinit = True)

        self.logger.write('Following network parameters can be learned now: ', 4)
        self.freezeUnfreezeOrPrintParameters(params = self.net.concatLayerTreatments.collect_params().values(), \
                                                                          action = 'unfreeze', initialized = False)
        self.freezeUnfreezeOrPrintParameters(params = self.net.treatmentsNet.collect_params().values(),\
                                                                          action = 'unfreeze', initialized = False)

                                      
    def forwardBackwardForEpoch(self, epochNumber, isTrain = True):
        # TODO: to scale on very big data, we need to create our own epochs.
        # We need to read from one part file and treat that as one epoch.
        # Beware: Need to check if any code change here is consistent with processData.py
        epochStartTime = time.time()
        cumulativeLoss = 0
        evalMetrics = self.getEvalMetrics()
        data_iter = self.train_iter if isTrain else self.valid_iter
        data_iter.reset()
        dataSize = self.trainDataSize  if isTrain else self.validDataSize
        trainOrValidString = 'train' if isTrain else 'valid'
        numBatch = 0
        for batch in data_iter:
            numBatch += 1
            features = batch.data[0].as_in_context(self.ctx)
            treatments = batch.data[1].as_in_context(self.ctx)
            labels = batch.data[2].as_in_context(self.ctx)
            instanceWeights = mxnet.nd.array([])
            if len(self.instanceWeight) > 0:
                instanceWeights = batch.data[3].as_in_context(self.ctx)
            if isTrain:
                with mxnet.autograd.record():
                    # Do forward pass on a batch of training data
                    # out is of type mxnet.nd.array
                    out = self.net(features, treatments)
                    loss_result = self.loss(out, labels, instanceWeights) if len(instanceWeights) > 0 else \
                                                                                      self.loss(out, labels)
                # Calculate gradients
                loss_result.backward()
                # Update parameters of the network
                self.trainer.step(self.batchSize)
            else:
                out = self.net(features, treatments)
                loss_result = self.loss(out, labels, instanceWeights) if len(instanceWeights) > 0 else \
                                                                                      self.loss(out, labels)
            # TODO: update for evalMetrics is raising exception when working with classification data. Need to look into this.
            if self.modelingChoicesDict['verboseLevel'] >= 3 and not self.classificationProblem:
                # TODO: write code to consider instance weights while scoring if needed.
                evalMetrics.update(labels = labels, preds = out)
                cumulativeLoss += mxnet.nd.sum(loss_result).asscalar()

        epochEndTime = time.time()
        self.logger.write('Total time taken for ' + trainOrValidString + 'epoch: {:.3f} minutes'.\
                                                       format((epochEndTime - epochStartTime)/60), 4)
        loss = float(cumulativeLoss) / numBatch
        self.logger.write(str('Epoch {}, '+ trainOrValidString + ' loss: {:.2f}').format(epochNumber, loss), 4)
        epochMetrics = evalMetrics.get()
        self.logger.write(str(epochMetrics), 4)
        statsDict = {'phase' : 'P'+str(self.phase), 'epoch' : int(epochNumber), 'loss' : loss,\
                                                 'timeEpoch' : float(epochEndTime - epochStartTime)/60}
        for numMetrics in range(len(epochMetrics[0])):
            statsDict[epochMetrics[0][numMetrics]] = epochMetrics[1][numMetrics]
        dfStats = pd.DataFrame.from_dict(data = statsDict, orient = 'index')
        dfStats.columns = ['Epoch ' + str(int(epochNumber))]
        self.logger.write(str(dfStats), 5)                                      
        return cumulativeLoss, dfStats

    def trainModel(self, startEpochNumber = 0):
        trainingStartTime = time.time()
        for e in range(startEpochNumber, self.epochs):
            cumulative_train_loss, dfStats = self.forwardBackwardForEpoch(e, isTrain = True)
            self.logger.write('Epoch ' + str(e) + ' Learning rate: '+ str(self.trainer.learning_rate), 4)
            if self.modelingChoicesDict['verboseLevel'] >= 4:
                self.dfTrainingStats = pd.concat([self.dfTrainingStats, dfStats],axis = 1)
                if self.validationData:
                    cumulative_valid_loss, dfStats = self.forwardBackwardForEpoch(e, isTrain = False)
                    self.dfValidationStats = pd.concat([self.dfValidationStats, dfStats],axis = 1)
                                      
        self.logger.write('parameters related to treatment after phase ' +str(self.phase)+' training', 4)
        self.freezeUnfreezeOrPrintParameters(params = self.net.concatLayerTreatments.collect_params().values(), \
                                                                                                 action = 'print')
        self.freezeUnfreezeOrPrintParameters(params = self.net.treatmentsNet.collect_params().values(), \
                                                                                                 action = 'print')
        self.logger.write('parameters related to features after phase ' +str(self.phase)+' training', 4)
        self.freezeUnfreezeOrPrintParameters(params = self.net.concatLayerFeatures.collect_params().values(), \
                                                                                                 action = 'print')
        self.freezeUnfreezeOrPrintParameters(params = self.net.featuresNet.collect_params().values(), \
                                                                                                 action = 'print')  
        trainingEndTime = time.time()
        self.logger.write('Total training time phase ' +str(self.phase) + ': ' + \
                                  str(round((trainingEndTime - trainingStartTime)/60,2)) + ' minutes', 4)    
        
    def getPredictions(self, dfFeatures, dfInterventions, instanceWeight = mxnet.nd.array([])): 
        # if we are running this for non-causal problems, intervention list in config file would be empty.
        if min(dfInterventions.shape) <= 0:
            # artificially creating a dummmy intervention to simplify code
            dfInterventions = pd.DataFrame(np.zeros((len(dfFeatures), 1)), columns = ['dummyIntervention'])
        # creating empty predictions array which will be appended with predictions from each bach
        predictions = np.empty((0, self.numberOfOutcomes), float)        
        batchSize = min(self.batchSize, len(dfFeatures))
        if batchSize > 0:
            # need to get predictions for last batch without padding it to next batch
            lastBatchSize = len(dfFeatures) % batchSize
            if len(instanceWeight) == 0:
                dataForScoring = [dfFeatures, dfInterventions]
            else:
                dataForScoring = [dfFeatures, dfInterventions, instanceWeight] 
            data_iter = mxnet.io.NDArrayIter(data=dataForScoring, batch_size=batchSize, shuffle = False, \
                                                                                               last_batch_handle='discard')
            for batch in data_iter:
                # out is of type mxnet.nd.array
                out = self.getPredictionsForBatch(batch, len(instanceWeight))
                predictions = np.concatenate((predictions, out.asnumpy()))    

            if lastBatchSize > 0:
                if len(instanceWeight) == 0:
                    lastBatchOfDataForScoring = [dfFeatures.tail(lastBatchSize), dfInterventions.tail(lastBatchSize)]
                else:
                    lastBatchOfDataForScoring = [dfFeatures.tail(lastBatchSize), dfInterventions.tail(lastBatchSize), \
                                                                                         instanceWeight.tail(lastBatchSize)] 
                lastBatch_iter = mxnet.io.NDArrayIter(data=lastBatchOfDataForScoring, batch_size=lastBatchSize,\
                                                      shuffle = False, last_batch_handle='discard')
                for batch in lastBatch_iter:
                    out = self.getPredictionsForBatch(batch, len(instanceWeight))
                    predictions = np.concatenate((predictions, out.asnumpy()))
            
        return predictions
    
    def getPredictionsForBatch(self, batch, lenInstanceWeight):
        features = batch.data[0].as_in_context(self.ctx)
        treatments = batch.data[1].as_in_context(self.ctx)
        instanceWeights = []
        if lenInstanceWeight > 0:
            instanceWeights = batch.data[2].as_in_context(self.ctx)
        # TODO: write code to get error metrics weighted by instance weights.
        # out is of type mxnet.nd.array
        out = self.net(features, treatments)
        return out

