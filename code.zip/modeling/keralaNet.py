import mxnet
import random
from mxnet import gluon
import copy

class KeralaNet(gluon.HybridBlock):

    """
    This is a hybrid between ResNet and DenseNet; not sure if there is an established name for this type of network.
    There are three types of layers - FeatureOnly layer, TreatmentOnly layer and RegressionLayer.
    The FeatureOnly network and TreatmentOnly network are concatenated to form a concat layer which 
    goes as input to regression network. Further the concatenation layer is input to all layers of regression network.
    Implemented to avoid vanishing gradient problem.
    Any of the regression layer cannot identify whether its input is from treatments or features - which
    helps to freeze training for either treatment or feature layers while guaranteeing that other layers 
    are not indirectly training these layers.
    Most of the parameters like drop out are used only in regression layer.
    """
    def __init__(self, numFeatureOnlyLayers, dimFeatureOnlyLayers, \
                 numTreatmentOnlyLayers, dimTreatmentOnlyLayers,\
                 numRegressionLayers, dimRegressionLayers, \
                 activationFunction = "Swish", betaForActivation = 0.1, \
                 batchNormalization = False, momentumForBatchNormalization = 0.9,\
                 dropoutRateRegression = 0, \
                 numberOfOutcomes = 1, classificationProblem = False, **kwargs):
        # although supportedActivations list is long here, in config we restrict Swish, sigmoid and tanh are recommended.
        self.supportedActivations = ['swish', 'relu', 'sigmoid', 'tanh', 'softrelu', 'softsign', \
                                     'leakyrelu', 'prelu', 'elu', 'selu']
        self.numFeatureOnlyLayers = numFeatureOnlyLayers
        self.numTreatmentOnlyLayers = numTreatmentOnlyLayers
        self.numRegressionLayers = numRegressionLayers   
        self.dimFeatureOnlyLayers = dimFeatureOnlyLayers
        self.dimTreatmentOnlyLayers = dimTreatmentOnlyLayers
        self.dimRegressionLayers = dimRegressionLayers
        self.dropoutRateRegression = dropoutRateRegression 
        self.numberOfOutcomes = numberOfOutcomes
        self.activationFunction = activationFunction
        self.betaForActivation = betaForActivation
        self.batchNormalization = batchNormalization
        self.momentumForBatchNormalization = momentumForBatchNormalization
        self.dropoutRateRegression = dropoutRateRegression
        self.classificationProblem = classificationProblem
        # NETWORK DEFINITION
        super(KeralaNet, self).__init__(**kwargs)
        with self.name_scope():
            # FEATURES NETWORK
            self.featuresNet = gluon.nn.HybridSequential('featuresLayer_')
            for layer in range(self.numFeatureOnlyLayers):
                # last layer to have same dimension as first regression layer (and concatenation layer) 
                # since we need to concatenate and we are implementing similar to resnet.
                if layer == self.numFeatureOnlyLayers - 1:
                    layerToAdd = gluon.nn.Dense(units = self.dimRegressionLayers)
                else:
                    layerToAdd = gluon.nn.Dense(units = self.dimFeatureOnlyLayers)
                self.featuresNet.add(layerToAdd)
                if self.batchNormalization:
                    self.featuresNet.add(gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization))  
                # recommended to use Swish
                if self.activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.featuresNet.add(gluon.nn.Activation(activation = self.activationFunction.lower()))
                if self.activationFunction.lower() == 'LeakyReLU'.lower():
                    self.featuresNet.add(gluon.nn.LeakyReLU(alpha=0.1))
                if self.activationFunction.lower() == 'PReLU'.lower():
                    self.featuresNet.add(gluon.nn.PReLU(alpha=0.1))
                if self.activationFunction.lower() == 'ELU'.lower():
                    self.featuresNet.add(gluon.nn.ELU(alpha=0.1))
                if self.activationFunction.lower() == 'SELU'.lower():
                    self.featuresNet.add(gluon.nn.SELU())
                if self.activationFunction.lower() == 'Swish'.lower():
                    self.featuresNet.add(gluon.nn.Swish(beta = self.betaForActivation))
            # TREATMENT NETWORK
            self.treatmentsNet = gluon.nn.HybridSequential(prefix = 'treatmentsLayer_')
            for layer in range(self.numTreatmentOnlyLayers):
                # last layer to have same dimension as first regression layer (and concatenation layer) 
                # since we need to concatenate and we are implementing similar to resnet.
                if layer == self.numTreatmentOnlyLayers - 1:
                    layerToAdd = gluon.nn.Dense(units = self.dimRegressionLayers)
                else:
                    layerToAdd = gluon.nn.Dense(units = self.dimTreatmentOnlyLayers)
                self.treatmentsNet.add(layerToAdd)
                if self.batchNormalization:
                    self.treatmentsNet.add(gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization))                
                # recommended to use Swish
                if self.activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.treatmentsNet.add(gluon.nn.Activation(activation = self.activationFunction.lower()))
                if self.activationFunction.lower() == 'LeakyReLU'.lower():
                    self.treatmentsNet.add(gluon.nn.LeakyReLU(alpha=0.1))
                if self.activationFunction.lower() == 'PReLU'.lower():
                    self.treatmentsNet.add(gluon.nn.PReLU(alpha=0.1))
                if self.activationFunction.lower() == 'ELU'.lower():
                    self.treatmentsNet.add(gluon.nn.ELU(alpha=0.1))
                if self.activationFunction.lower() == 'SELU'.lower():
                    self.treatmentsNet.add(gluon.nn.SELU())
                if self.activationFunction.lower() == 'Swish'.lower():
                    self.treatmentsNet.add(gluon.nn.Swish(beta = self.betaForActivation))
            # CONCATENATION NETWORK
            self.concatLayerFeatures = mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, \
                                                                                prefix = 'concatLayerFeatures_')
            self.concatLayerTreatments = mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, \
                                                                                prefix = 'concatLayerTreatments_')
            self.activationBatchConcat = gluon.nn.HybridSequential(prefix = 'concatenationLayer_activationAndBatch_')
            # activation is applied before batch here - to completely prevent any change 
            # in the influence of a frozen layer through weights or normalization.
            # Recommended to use Swish
            if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                self.activationBatchConcat.add(gluon.nn.Activation(activation = activationFunction.lower()))
            if activationFunction.lower() == 'LeakyReLU'.lower():
                self.activationBatchConcat.add(gluon.nn.LeakyReLU(alpha=0.1))
            if activationFunction.lower() == 'PReLU'.lower():
                self.activationBatchConcat.add(gluon.nn.PReLU(alpha=0.1))
            if activationFunction.lower() == 'ELU'.lower():
                self.activationBatchConcat.add(gluon.nn.ELU(alpha=0.1))
            if activationFunction.lower() == 'SELU'.lower():
                self.activationBatchConcat.add(gluon.nn.SELU())
            if activationFunction.lower() == 'Swish'.lower():
                self.activationBatchConcat.add(gluon.nn.Swish(beta = self.betaForActivation))
            if self.batchNormalization:
                self.activationBatchConcat.add(gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization))    
            # REGRESSION LAYERS
            # all layers to have same dimension as self.dimRegressionLayers
            # since we need to concatenate the concatenation layer with every regression layer.
            # adding the layers using if blocks is a work around (library was behaving weirdly when hybrid 
            # sequential block was used - need to see if there is a better way; 
            # also, keeping the layers in list or dict does not register the symbol.
            # dropouts are applied only in regression layers.
            if self.numRegressionLayers > 0:
                self.regressionNetLayer1 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_1_')
                if self.batchNormalization:
                    self.batchRegression1 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)                  
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression1 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression1 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression1 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression1 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression1 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression1 = gluon.nn.Swish(beta = self.betaForActivation)     
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression1 = gluon.nn.Dropout(self.dropoutRateRegression)
                
            if self.numRegressionLayers > 1:
                self.regressionNetLayer2 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_2_')
                if self.batchNormalization:
                    self.batchRegression2 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)   
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression2 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression2 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression2 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression2 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression2 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression2 = gluon.nn.Swish(beta = self.betaForActivation)  
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression2 = gluon.nn.Dropout(self.dropoutRateRegression)
                
            if self.numRegressionLayers > 2:
                self.regressionNetLayer3 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_3_')
                if self.batchNormalization:
                    self.batchRegression3 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression3 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression3 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression3 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression3 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression3 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression3 = gluon.nn.Swish(beta = self.betaForActivation)
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression3 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 3:
                self.regressionNetLayer4 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_4_')
                if self.batchNormalization:
                    self.batchRegression4 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression4 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression4 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression4 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression4 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression4 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression4 = gluon.nn.Swish(beta = self.betaForActivation)
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression4 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 4:
                self.regressionNetLayer5 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_5_')
                if self.batchNormalization:
                    self.batchRegression5 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression5 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression5 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression5 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression5 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression5 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression5 = gluon.nn.Swish(beta = self.betaForActivation)
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression5 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 5:
                self.regressionNetLayer6 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_6_')
                if self.batchNormalization:
                    self.batchRegression6 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression6 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression6 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression6 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression6 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression6 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression6 = gluon.nn.Swish(beta = self.betaForActivation)
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression6 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 6:
                self.regressionNetLayer7 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_7_')
                if self.batchNormalization:
                    self.batchRegression7 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression7 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression7 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression7 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression7 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression7 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression7 = gluon.nn.Swish(beta = self.betaForActivation)
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression7 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 7:
                self.regressionNetLayer8 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_8_')
                if self.batchNormalization:
                    self.batchRegression8 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)                   
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression8 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression8 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression8 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression8 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression8 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression8 = gluon.nn.Swish(beta = self.betaForActivation)   
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression8 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 8:
                self.regressionNetLayer9 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_9_')
                if self.batchNormalization:
                    self.batchRegression9 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)                   
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression9 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression9 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression9 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression9 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression9 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression9 = gluon.nn.Swish(beta = self.betaForActivation)   
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression9 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 9:
                self.regressionNetLayer10 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_10_')
                if self.batchNormalization:
                    self.batchRegression10 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)                   
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression10 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression10 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression10 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression10 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression10 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression10 = gluon.nn.Swish(beta = self.betaForActivation)
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression10 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 10:
                self.regressionNetLayer11 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_11_')
                if self.batchNormalization:
                    self.batchRegression11 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)                   
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression11 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression11 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression11 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression11 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression11 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression11 = gluon.nn.Swish(beta = self.betaForActivation)
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression11 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 11:
                self.regressionNetLayer12 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_12_')
                if self.batchNormalization:
                    self.batchRegression12 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)                   
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression12 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression12 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression12 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression12 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression12 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression12 = gluon.nn.Swish(beta = self.betaForActivation) 
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression12 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 12:
                self.regressionNetLayer13 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_13_')
                if self.batchNormalization:
                    self.batchRegression13 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)                  
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression13 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression13 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression13 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression13 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression13 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression13 = gluon.nn.Swish(beta = self.betaForActivation)
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression13 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 13:
                self.regressionNetLayer14 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_14_')
                if self.batchNormalization:
                    self.batchRegression14 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)                   
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression14 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression14 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression14 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression14 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression14 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression14 = gluon.nn.Swish(beta = self.betaForActivation)
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression14 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            if self.numRegressionLayers > 14:
                self.regressionNetLayer15 =  mxnet.gluon.nn.Dense(units = self.dimRegressionLayers, prefix = 'regression_15_')
                if self.batchNormalization:
                    self.batchRegression15 = gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization)
                if activationFunction.lower() in ['relu', 'sigmoid', 'tanh', 'softrelu', 'softsign']:
                    self.activationRegression15 = gluon.nn.Activation(activation = activationFunction.lower())
                if activationFunction.lower() == 'LeakyReLU'.lower():
                    self.activationRegression15 = gluon.nn.LeakyReLU(alpha=0.1)
                if activationFunction.lower() == 'PReLU'.lower():
                    self.activationRegression15 = gluon.nn.PReLU(alpha=0.1)
                if activationFunction.lower() == 'ELU'.lower():
                    self.activationRegression15 = gluon.nn.ELU(alpha=0.1)
                if activationFunction.lower() == 'SELU'.lower():
                    self.activationRegression15 = (gluon.nn.SELU())
                if activationFunction.lower() == 'Swish'.lower():
                    self.activationRegression15 = gluon.nn.Swish(beta = self.betaForActivation) 
                if self.dropoutRateRegression > 0:
                    self.dropoutRegression15 = gluon.nn.Dropout(self.dropoutRateRegression)
                                
            # Final LAYER - outcome
            self.estimationNet = gluon.nn.HybridSequential(prefix = 'outcome_layer_')
            if self.batchNormalization:
                self.estimationNet.add(gluon.nn.BatchNorm(momentum = self.momentumForBatchNormalization))
            if self.classificationProblem:
                self.estimationNet.add(gluon.nn.Dense(units = numberOfOutcomes, activation = "sigmoid"))
            else:
                self.estimationNet.add(gluon.nn.Dense(units = numberOfOutcomes))
             

    def hybrid_forward(self, F, x, t):
        if self.numFeatureOnlyLayers > 0:
            features = self.featuresNet(x)    
        else:
            features = x    
            
        if self.numTreatmentOnlyLayers > 0:
            treatments = self.treatmentsNet(t)
        else:
            treatments = t
             
        featuresGrouped = self.concatLayerFeatures(features)
        treatmentsGrouped = self.concatLayerTreatments(treatments)
        concatenateData = featuresGrouped + treatmentsGrouped
        concatenateDataActivationAndBatch = self.activationBatchConcat(concatenateData)
                     
        if self.numRegressionLayers > 0:
            regressionData = self.regressionNetLayer1(concatenateDataActivationAndBatch)
            if self.batchNormalization:
                regressionData = self.batchRegression1(regressionData)            
            regressionData = self.activationRegression1(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression1(regressionData)
            
        if self.numRegressionLayers > 1:
            regressionData = self.regressionNetLayer2(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression2(regressionData)
            regressionData = self.activationRegression2(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression2(regressionData)
            
        if self.numRegressionLayers > 2:
            regressionData = self.regressionNetLayer3(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression3(regressionData)            
            regressionData = self.activationRegression3(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression3(regressionData)
            
        if self.numRegressionLayers > 3:
            regressionData = self.regressionNetLayer4(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression4(regressionData)
            regressionData = self.activationRegression4(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression4(regressionData)
            
            
        if self.numRegressionLayers > 4:
            regressionData = self.regressionNetLayer5(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression5(regressionData)
            regressionData = self.activationRegression5(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression5(regressionData)
            
        if self.numRegressionLayers > 5:
            regressionData = self.regressionNetLayer6(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression6(regressionData)
            regressionData = self.activationRegression6(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression6(regressionData)
            
        if self.numRegressionLayers > 6:
            regressionData = self.regressionNetLayer7(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression7(regressionData)
            regressionData = self.activationRegression7(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression7(regressionData)
            
        if self.numRegressionLayers > 7:
            regressionData = self.regressionNetLayer8(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression8(regressionData)
            regressionData = self.activationRegression8(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression8(regressionData)
            
        if self.numRegressionLayers > 8:
            regressionData = self.regressionNetLayer9(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression9(regressionData)
            regressionData = self.activationRegression9(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression9(regressionData)
            
        if self.numRegressionLayers > 9:
            regressionData = self.regressionNetLayer10(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression10(regressionData)
            regressionData = self.activationRegression10(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression10(regressionData)
            
        if self.numRegressionLayers > 10:
            regressionData = self.regressionNetLayer11(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression11(regressionData)
            regressionData = self.activationRegression11(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression11(regressionData)
            
        if self.numRegressionLayers > 11:
            regressionData = self.regressionNetLayer12(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression12(regressionData)
            regressionData = self.activationRegression12(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression12(regressionData)
            
        if self.numRegressionLayers > 12:
            regressionData = self.regressionNetLayer13(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression13(regressionData)
            regressionData = self.activationRegression13(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression13(regressionData)
            
        if self.numRegressionLayers > 13:
            regressionData = self.regressionNetLayer14(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression14(regressionData)
            regressionData = self.activationRegression14(regressionData)
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression14(regressionData)
            
        if self.numRegressionLayers > 14:
            regressionData = self.regressionNetLayer15(regressionData)
            regressionData = concatenateDataActivationAndBatch + regressionData
            if self.batchNormalization:
                regressionData = self.batchRegression15(regressionData)
            regressionData = self.activationRegression15(regressionData) 
            if self.dropoutRateRegression > 0:
                regressionData = self.dropoutRegression15(regressionData)

        if self.numRegressionLayers > 0:
            regressionData = concatenateDataActivationAndBatch + regressionData
        else:
            regressionData = concatenateDataActivationAndBatch

        
        estimate = self.estimationNet(regressionData)
        return estimate
            

