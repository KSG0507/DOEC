import os
import sys
import pandas
import subprocess
import boto3
import botocore
from botocore.exceptions import ClientError
from botocore.client import Config

from utils import processConfig

def constructCompletePaths(dataConfigDict, toPrintList, toPrintVerboseList):
    """
    Function that creates local directory paths for saving intermediate and final files.
    """
    # a subdirectory is formed for current run using runTag. 
    # this is to have flexibility for running the model on same data without overwriting.
    dataConfigDict['localPaths']['basePath'] = os.path.join(dataConfigDict['localPaths']['basePath'], \
                                                dataConfigDict['runTag'])
    dataConfigDict['localPaths']['rawDataDirectoryName'] = \
                                            os.path.join(dataConfigDict['localPaths']['basePath'], \
                                                dataConfigDict['localPaths']['dataDirectoryName'], 'raw')
    toPrintList.append('rawDataDirectoryName '+dataConfigDict['localPaths']['rawDataDirectoryName'])
    toPrintVerboseList.append(4)
    # if s3 path for scoring data is provided, create local directory for scoring data.
    if len(dataConfigDict['s3Paths']['s3scoringDataFilePath'].strip())>0:
        dataConfigDict['localPaths']['scoringRawDataDirectoryName'] = \
                                                os.path.join(dataConfigDict['localPaths']['basePath'], \
                                                    dataConfigDict['localPaths']['dataDirectoryName'], 'scoringData')
        toPrintList.append('scoringRawDataDirectoryName '+dataConfigDict['localPaths']['scoringRawDataDirectoryName'])
        toPrintVerboseList.append(4)
    else:
        dataConfigDict['localPaths']['scoringRawDataDirectoryName'] = ""
        
    # processed data directory is to save and reuse processed data - not currently used.
    dataConfigDict['localPaths']['processedDataDirectoryName'] = \
                                            os.path.join(dataConfigDict['localPaths']['basePath'], \
                                                dataConfigDict['localPaths']['dataDirectoryName'], 'processed')
    toPrintList.append('processedDataDirectoryName '+dataConfigDict['localPaths']['processedDataDirectoryName'])
    toPrintVerboseList.append(4)
    dataConfigDict['localPaths']['resultsDirectoryName'] = \
                                            os.path.join(dataConfigDict['localPaths']['basePath'], \
                                             dataConfigDict['localPaths']['resultsDirectoryName'])
    toPrintList.append('local resultsDirectory = '+ dataConfigDict['localPaths']['resultsDirectoryName'] )
    toPrintVerboseList.append(4)
    dataConfigDict['s3Paths']['s3ResultsPath'] = os.path.join(dataConfigDict['s3Paths']['s3ResultsPath'], \
                                                                 dataConfigDict['runTag'])
    toPrintList.append('s3 resultsDirectory = '+ dataConfigDict['s3Paths']['s3ResultsPath'] )
    toPrintVerboseList.append(4)
    dataConfigDict['localPaths']['modelArtifactsBaseDirectoryName'] = \
                                            os.path.join(dataConfigDict['localPaths']['basePath'], \
                                            dataConfigDict['localPaths']['modelArtifactsBaseDirectoryName'])
    toPrintList.append('modelArtifactsBaseDirectoryName = ' + dataConfigDict['localPaths']['modelArtifactsBaseDirectoryName'] )
    toPrintVerboseList.append(4)
    dataConfigDict['localPaths']['modelArtifactsScratchDirectoryName'] = \
                                     os.path.join(dataConfigDict['localPaths']['modelArtifactsBaseDirectoryName'], 'scratch')
    toPrintList.append('modelArtifactsScratchDirectoryName = ' + \
                                            dataConfigDict['localPaths']['modelArtifactsScratchDirectoryName'])
    toPrintVerboseList.append(5)
    # if full s3 path is not given for header files, full path is constructed from the data file path and header file path
    if len(dataConfigDict['s3Paths']['s3headerFilePath'].strip())>0 and \
                                len(dataConfigDict['s3Paths']['s3headerFilePath'].split('/')) == 1:
        dataConfigDict['s3Paths']['s3headerFilePath'] = \
                       os.path.join(dataConfigDict['s3Paths']['s3dataFilePath'], \
                                  dataConfigDict['s3Paths']['s3headerFilePath'])
    # if full s3 path is not given for scoring header files, 
    # full path is constructed from the data file path and header file path
    if len(dataConfigDict['s3Paths']['s3scoringDataHeaderFilePath'].strip())>0 and \
                                len(dataConfigDict['s3Paths']['s3scoringDataHeaderFilePath'].split('/')) == 1:
        dataConfigDict['s3Paths']['s3scoringDataHeaderFilePath'] = \
                       os.path.join(dataConfigDict['s3Paths']['s3scoringDataFilePath'], \
                                  dataConfigDict['s3Paths']['s3scoringDataHeaderFilePath'])        

def downloadData(dataConfigDict, useBoto, toPrintList = [], toPrintVerboseList = []):
    """
    This function creates the local path and downloads data.
    """
    toPrintList.append('Constructing paths')
    toPrintVerboseList.append(3)
    constructCompletePaths(dataConfigDict, toPrintList, toPrintVerboseList)
    directoriesToCreate = [dataConfigDict['localPaths']['rawDataDirectoryName'],\
                                  dataConfigDict['localPaths']['processedDataDirectoryName'], \
                                  dataConfigDict['localPaths']['resultsDirectoryName'],\
                                  dataConfigDict['localPaths']['modelArtifactsBaseDirectoryName'],\
                                  dataConfigDict['localPaths']['modelArtifactsScratchDirectoryName']]
    if len(dataConfigDict['s3Paths']['s3scoringDataFilePath'].strip())>0:
        directoriesToCreate.append(dataConfigDict['localPaths']['scoringRawDataDirectoryName'])
    createLocalDirectoriesRecursively(directoriesToCreate, toPrintList, toPrintVerboseList)
    # Check if data exist in local location
    if os.path.exists(dataConfigDict['localPaths']['rawDataDirectoryName']) and \
            len(os.listdir(dataConfigDict['localPaths']['rawDataDirectoryName']))>0:
        if dataConfigDict['localPaths']['overwriteData'] <= 0:
            toPrintList.append('Data available locally; skipping download')
            toPrintVerboseList.append(3)
            return
        else:
            toPrintList.append('Overwriting local data')
            toPrintVerboseList.append(3)            
    else:
        toPrintList.append('No data available locally... Downloading')
        toPrintVerboseList.append(3)         
        
    downloadDataFromS3(s3Path = dataConfigDict['s3Paths']['s3dataFilePath'] ,\
                        localPath = dataConfigDict['localPaths']['rawDataDirectoryName'], \
                        s3Bucket = dataConfigDict['s3Paths']['s3bucket'],  \
                        accessKey = dataConfigDict['s3Paths']['accessKey'], \
                        encryptionKey = dataConfigDict['s3Paths']['encryptionKey'], \
                        useBoto = useBoto, singleFile = False,\
                        toPrintList = toPrintList, toPrintVerboseList = toPrintVerboseList)
    if len(dataConfigDict['s3Paths']['s3headerFilePath'])>0:
        downloadDataFromS3(s3Path =  dataConfigDict['s3Paths']['s3headerFilePath'], \
                            localPath = dataConfigDict['localPaths']['rawDataDirectoryName'], \
                            s3Bucket = dataConfigDict['s3Paths']['s3bucket'],  \
                            accessKey = dataConfigDict['s3Paths']['accessKey'], \
                            encryptionKey = dataConfigDict['s3Paths']['encryptionKey'],\
                            useBoto = useBoto, singleFile = True, \
                            toPrintList = toPrintList, toPrintVerboseList = toPrintVerboseList)
        
    # Check if scoring data exist in local location
    if len(dataConfigDict['s3Paths']['s3scoringDataFilePath'].strip())>0:
        if os.path.exists(dataConfigDict['localPaths']['scoringRawDataDirectoryName']) and \
                len(os.listdir(dataConfigDict['localPaths']['scoringRawDataDirectoryName']))>0:
            if dataConfigDict['localPaths']['overwriteData'] <= 0:
                toPrintList.append('Data available locally; skipping download')
                toPrintVerboseList.append(3)
                return
            else:
                toPrintList.append('Overwriting local data')
                toPrintVerboseList.append(3)            
        else:
            toPrintList.append('No data available locally... Downloading')
            toPrintVerboseList.append(3)         

        downloadDataFromS3(s3Path = dataConfigDict['s3Paths']['s3scoringDataFilePath'] ,\
                            localPath = dataConfigDict['localPaths']['scoringRawDataDirectoryName'], \
                            s3Bucket = dataConfigDict['s3Paths']['s3bucket'],  \
                            accessKey = dataConfigDict['s3Paths']['accessKey'], \
                            encryptionKey = dataConfigDict['s3Paths']['encryptionKey'], \
                            useBoto = useBoto, singleFile = False,\
                            toPrintList = toPrintList, toPrintVerboseList = toPrintVerboseList)
        if len(dataConfigDict['s3Paths']['s3headerFilePath'])>0:
            downloadDataFromS3(s3Path =  dataConfigDict['s3Paths']['s3scoringDataHeaderFilePath'], \
                                localPath = dataConfigDict['localPaths']['scoringRawDataDirectoryName'], \
                                s3Bucket = dataConfigDict['s3Paths']['s3bucket'],  \
                                accessKey = dataConfigDict['s3Paths']['accessKey'], \
                                encryptionKey = dataConfigDict['s3Paths']['encryptionKey'],\
                                useBoto = useBoto, singleFile = True, \
                                toPrintList = toPrintList, toPrintVerboseList = toPrintVerboseList)        
                    

def downloadDataBoto3(s3Path, localPath, s3Bucket, toPrintList, toPrintVerboseList):
    # TODO: to use access and encryption keys. Test the code.
    s3 = boto3.resource('s3')
    s3_client=boto3.client('s3')
    s3_contents = s3_client.list_objects_v2(Bucket = s3Bucket, Prefix = s3Path)
    if 'Contents' in s3_contents:
        for s3_key in s3_contents['Contents']:
            s3_object = s3_key['Key']
            s3.Bucket(s3Bucket).download_file(s3_object, os.path.join(localPath, str(s3_object.split('/')[-1])))
    
    else:
        toPrintList.append('no files found in s3 path s3://'+s3Bucket+'/'+s3Path)
        toPrintVerboseList.append(1)
    
def uploadDataBoto3(s3Path, localPath, s3Bucket, toPrintList, toPrintVerboseList):
    # TODO: This part of code is not tested yet.
    s3 = boto3.resource('s3')
    s3.Bucket(s3Bucket).upload_file(localPath, s3Path)
                     
    
             
def downloadDataFromS3(s3Path, localPath, s3Bucket, accessKey, encryptionKey, useBoto,\
                       singleFile, toPrintList, toPrintVerboseList):
    
    """
    Function to download data from s3 to local path.
    this downloads all files into the local path. the directory structure in s3 is ignored.
    if s3headerFilePath is given, header file is downloaded.
    if singleFile flag is set to True, a single file is downloaded (difference is in ends with /)
    """
    # forcing path to end with '/',  since s3 command was downloading all folders that has prefix with s3Path.
    # This was causing problems such as more download time (although files get overwritten in most cases) and in few cases, downloading obsolete part files.
    if (not singleFile) and (not s3Path.endswith('/')):
            s3Path = s3Path+'/'

    toPrintList.append('-------> downloading data to ' + localPath)
    toPrintVerboseList.append(5)
    # boto is useful when we run the code in sagemaker.
    if useBoto == True:
        downloadDataBoto3(s3Path, localPath, s3Bucket, toPrintList, toPrintVerboseList)
        
    else:
        # creating command in the form of a list. There could be scope for improvement here.
        command = ['/apollo/env/envImprovement/bin/s3GeneralFileDownloader', '-b', s3Bucket, '-m', accessKey, '-e', encryptionKey,'-op', 'download', '-p', s3Path, '-dir', localPath]
        toPrintList.append('command = '+ ' '.join(command))
        toPrintVerboseList.append(5)
        with open(os.devnull, 'w') as DEVNULL:
            s3DownloadProcess = subprocess.Popen(command, stdout = DEVNULL, stderr = DEVNULL)
            s3DownloadProcess.wait()
                       
    # Check if data exist in local location
    if not (os.path.exists(localPath) and len(os.listdir(localPath))>0):
        toPrintList.append('Problem with local path:' + localPath)
        toPrintVerboseList.append(1)
        sys.exit('Error')          

    toPrintList.append('<-------')
    toPrintVerboseList.append(1)
    
def deleteDirectory(directoryList, logger = None):
    """
    deletes directories in the list passed as argument
    """
    if len(directoryList) <= 0:
        if logger != None:
            logger.write('list of directories to delete is empty', 5)
    else:
        try:
            for directory in directoryList:
                if logger != None:
                    logger.write('deleting directory ' + directory, 4)
                subprocess.check_output(['rm', '-r', directory])
        except subprocess.CalledProcessError as e:
            if logger != None:
                logger.write('CalledProcessError: '+str(e), 3)
    
def uploadResultsAndArtifacts(dataConfigDict, useBoto, logger):
    """
    function to upload data from local path to s3.
    the directory structure under the local path used is preserved.
    """
    directoryList = [dataConfigDict['localPaths']['resultsDirectoryName'], dataConfigDict['localPaths']\
                                                           ['modelArtifactsBaseDirectoryName']]
    s3LeafPathList = [x.split('/')[-1] for x in directoryList]
    accessKey = dataConfigDict['s3Paths']['accessKey']
    encryptionKey = dataConfigDict['s3Paths']['encryptionKey']  
    # TODO: need to be consistent with naming using caps and small case.
    s3Bucket = dataConfigDict['s3Paths']['s3bucket']
    s3Path = dataConfigDict['s3Paths']['s3ResultsPath']
    for i in range(len(directoryList)):
        directory = directoryList[i]
        s3LeafPath = os.path.join(s3Path, s3LeafPathList[i])+'/'
        logger.write('---------------> uploading ' + directory, 4)
        if not s3Path.endswith('/'):
                s3Path = s3Path+'/'   
        # boto is useful when we run the code in sagemaker.
        if useBoto == True:
            uploadDataBoto3(s3LeafPath, directory, s3Bucket)
        else:                                                               
            # creating command in the form of a list for uploading results
            command = ['/apollo/env/envImprovement/bin/s3GeneralFileUploader', '-b', s3Bucket, '-d', '365', '-dir', \
                        directory, '-e', encryptionKey, '-m', accessKey, '-op', 'upload', '-p', s3LeafPath]
#             command = ['/apollo/env/TrafficAnalyticsScheduler/bin/s3-access', '--upload', '--local', \
#                        directory, '--bucket', s3Bucket, '--s3', s3Path, \
#                        '--aws_credentials_key', accessKey, \
#                        '--encryption_asymmetric_key', encryptionKey]
            logger.write('command = '+ ' '.join(command), 4)
            with open(os.devnull, 'w') as DEVNULL:
                s3UploadProcess = subprocess.Popen(command, stdout = DEVNULL, stderr = DEVNULL)
                s3UploadProcess.wait()
        print '<----------------'   


def createLocalDirectoriesRecursively(directoryList, toPrintList, toPrintVerboseList):
    """
    creates all local directories passed as argument
    :param directoryList:
    :return:
    """
    if len(directoryList) <= 0:
        toPrintList.append('list of directories to create is empty')
        toPrintVerboseList.append(1)
    else:
        try:
            for directory in directoryList:
                toPrintList.append('creating directory ' + directory)
                toPrintVerboseList.append(4)
                subprocess.check_output(['mkdir', '-p', directory])
        except subprocess.CalledProcessError as e:
            print 'CalledProcessError: ', e
            toPrintList.append('CalledProcessError: ' + e)
            toPrintVerboseList.append(1)
                
    