import gc
import os
import sys
import glob
import pandas as pd
import random
import numpy as np
import mxnet
import re
import time
import copy

from functools import partial
import multiprocessing
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import minmax_scale
from sklearn.preprocessing import MaxAbsScaler
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import Normalizer
from sklearn.preprocessing import QuantileTransformer
from sklearn.preprocessing import PowerTransformer

import getData
from utils import processConfig

class CrossValidationSplits(object):
    """
    Class for CV instances
    """
    def __init__(self):
        pass

class ModelingData(object):

    def __init__(self, dataConfigDict, modelingChoicesDict, logger):
        
        self.logger = logger
        self.dataConfigDict = dataConfigDict
        # getting the paths to data
        self.rawDataDirectoryName = self.dataConfigDict['localPaths']['rawDataDirectoryName']
        self.dataFileNameList = self.dataConfigDict['localPaths']['dataFileName']
        self.headerFileName = self.dataConfigDict['localPaths']['headerFileName']
        self.scoringRawDataDirectoryName = self.dataConfigDict['localPaths']['scoringRawDataDirectoryName']
        self.scoringDataFileNameList = self.dataConfigDict['localPaths']['scoringDataFileName']
        self.scoringHeaderFileName = self.dataConfigDict['localPaths']['scoringHeaderFileName']
        # only text file type is implemented.
        self.fileType = self.dataConfigDict['localPaths']['fileType'].lower()
        self.sep = self.dataConfigDict['localPaths']['sep']        
        # getting regex that has to be used to identify columns
        self.instanceIdColumnsRegex = self.dataConfigDict['dataInstance']['id']
        self.instanceWeightColumnRegex = self.dataConfigDict['dataInstance']['instanceWeight'].strip()
        self.numericFeaturesRegex = self.dataConfigDict['features']['numericFeatures']
        self.categoricalFeaturesRegex = self.dataConfigDict['features']['categoricalFeatures']
        self.excludeColumnsRegex = self.dataConfigDict['excludeColumns']['columnNames']
        self.interventionsRegex = self.dataConfigDict['interventions']['interventions']
        self.interventionConjunctionsRegex = self.dataConfigDict['interventions']['interventionConjunctions']
        self.interventionDisjunctionsRegex = self.dataConfigDict['interventions']['interventionDisjunctions']
        self.interventionsIncrementValue = self.dataConfigDict['interventions']['incrementVaue']
        self.binaryTargetNamesRegex = self.dataConfigDict['targets']['binaryTargetNames']
        self.continuousTargetNamesRegex = self.dataConfigDict['targets']['continuousTargetNames']
        self.actualTreatmentEffectsRegex = self.dataConfigDict['actualTreatmentEffects']

        self.modelingChoicesDict = modelingChoicesDict
        self.ctx = mxnet.cpu() 
        if self.modelingChoicesDict['environmentVariables']['gpu'] > 0:
            self.ctx = mxnet.gpu()
        # nJobs is not used yet
        self.nJobs = int(modelingChoicesDict['environmentVariables']['n_jobs'])
        self.sagemaker = False
        if self.modelingChoicesDict['environmentVariables']['sagemaker'] > 0:
            self.sagemaker = True    
        self.maxSampleSize = self.modelingChoicesDict['cvSetup']['maxSampleSize']
        self.testFraction = self.modelingChoicesDict['cvSetup']['test_fraction']
        self.validFraction = self.modelingChoicesDict['cvSetup']['valid_fraction']
        self.numSplitsForHyperparameters = self.modelingChoicesDict['cvSetup']['numSplitsForHyperparameters']
        self.numSplitForGettingConfidenceIntervals = self.modelingChoicesDict['cvSetup']\
                                                         ['numSplitForGettingConfidenceIntervals']
        self.maxInstancesToComputeScalingParameters = self.modelingChoicesDict['cvSetup']\
                                                        ['maxInstancesToComputeScalingParameters']
        
    def getInstanceIds(self, dfData):
        dfInstanceIds = dfData[self.instanceIdColumns] 
        dfInstanceIds.fillna(value = 'null_'+str(random.random()), inplace = True)        
        return dfInstanceIds 
    
    def getInstanceWeights(self, dfData):
        if len(self.instanceWeightColumn)<=0:
            return pd.DataFrame()
        else:
            dfInstanceWeights = dfData[[self.instanceWeightColumn]]
            # only for instance weights, missed values are considered as 1
            dfInstanceWeights.fillna(value = 1, inplace = True)
            return dfInstanceWeights
    
    def getFeatures(self, dfData):
        dfFeatures = dfData[self.featureNamesList] 
        dfFeatures.fillna(value = 0, inplace = True)        
        return dfFeatures         
        
            
    def createFeaturesNamesList(self):
        self.featureNamesList = []
        for key, value in self.categoricalDummyMappingDict.items():
            self.featureNamesList.extend(value)
        self.featureNamesList.extend(self.numericFeatures)
    
    def getInterventions(self, dfData):
        dfInterventions = dfData[self.interventions] 
        dfInterventions.fillna(value = 0, inplace = True)        
        return dfInterventions
    
    def getInterventionConjunctions(self, dfData):
        dfInterventionConjunctions = dfData[self.interventionConjunctions] 
        dfInterventionConjunctions.fillna(value = 0, inplace = True)        
        return dfInterventionConjunctions
    
    def getInterventionDisjunctions(self, dfData):
        dfInterventionDisjunctions = dfData[self.interventionDisjunctions] 
        dfInterventionDisjunctions.fillna(value = 0, inplace = True)        
        return dfInterventionDisjunctions
    
    def getTargets(self, dfData):
        targetList = [x for x in self.targets if x in list(dfData)]
        dfTargets = dfData[targetList] 
        dfTargets.fillna(value = 0, inplace = True)        
        return dfTargets           
            
    def getActualTreatmentEffects(self, dfData):
        actualTreatmentEffectColumList = [x for x in self.actualTreatmentEffectColums if x in list(dfData)]
        dfActualTreatmentEffects = dfData[actualTreatmentEffectColumList] 
        dfActualTreatmentEffects.fillna(value = 0, inplace = True)        
        return dfActualTreatmentEffects           
            
    def getInstanceIdWeightFeaturesInterventionsTargetActualTreatmentEffects(self, dfData):
        return [self.getInstanceIds(dfData), self.getInstanceWeights(dfData), \
                self.getFeatures(dfData), self.getInterventions(dfData), \
                self.getTargets(dfData), self.getActualTreatmentEffects(dfData)]      
    
    def getColumnsMetadata(self):
        self.createFeaturesNamesList()
        return {'instanceIds': self.instanceIdColumns, 'instanceWeights': self.instanceWeightColumn,\
                'features': self.featureNamesList, 'interventions': self.interventions, \
                 'targets': self.targets}

        
    def getAllRegexMatches(self, itemsList, regexList, ignoreCase = False):
        matchingList = []
        for regex in regexList:
            pattern = re.compile(regex, re.IGNORECASE) if ignoreCase else re.compile(regex)
            match = [x for x in itemsList if re.match(pattern, x)]
            matchingList.extend(match)
        
        return list(set(matchingList))
    
    def getScaler(self):
        if self.modelingChoicesDict['dataProcessing']['scalerForFeatures'].lower().startswith('stand'):
            scaler = StandardScaler()
        elif self.modelingChoicesDict['dataProcessing']['scalerForFeatures'].lower().startswith('minmax'):
            scaler = MinMaxScaler()
        elif self.modelingChoicesDict['dataProcessing']['scalerForFeatures'].lower().startswith('maxabs'):
            scaler = MaxAbsScaler()
        elif self.modelingChoicesDict['dataProcessing']['scalerForFeatures'].lower().startswith('robust'):
            scaler = RobustScaler()
        elif self.modelingChoicesDict['dataProcessing']['scalerForFeatures'].lower().startswith('norm'):
            scaler = Normalizer()
        elif self.modelingChoicesDict['dataProcessing']['scalerForFeatures'].lower().startswith('quant'):
            if 'uniform' in self.modelingChoicesDict['dataProcessing']['scalerForFeatures'].lower():
                scaler = QuantileTransformer(output_distribution='uniform')
            else:
                scaler = QuantileTransformer(output_distribution='normal')
        elif self.modelingChoicesDict['dataProcessing']['scalerForFeatures'].lower().startswith('power'):
            scaler = PowerTransformer()
        else:
            scaler = None
        return scaler
          
    
    def createScalerObj(self, dfData):
        featureScaler = self.getScaler()
        scaledFeaturesList = []
        if featureScaler != None:
            # scale only large magnitude features. If features are in [0, 1], no scaling is done.
            dfDataForGettingScalingParameters = dfData
            if len(dfData) > self.maxInstancesToComputeScalingParameters:
                dfDataForGettingScalingParameters = self.sampleData(dfData, self.maxInstancesToComputeScalingParameters)

            scaledFeaturesList = [x for x in self.numericFeatures if dfDataForGettingScalingParameters[x].max() > 1\
                                   or dfDataForGettingScalingParameters[x].min() < 0]
            if len(scaledFeaturesList) > 0 and len(dfDataForGettingScalingParameters) > 0:
                featureScaler.fit(dfDataForGettingScalingParameters[scaledFeaturesList])
        return featureScaler, scaledFeaturesList
    
    def scaleFeatures(self, dfDataList, featureScaler, scaledFeaturesList):
        if len(scaledFeaturesList) > 0:
            newDataList = []
            for dfData in dfDataList:
                if len(dfData) > 0:
                    dfData[scaledFeaturesList] = featureScaler.transform(dfData[scaledFeaturesList])
                newDataList.append(dfData)
            return newDataList
        else:
            return dfDataList
    
    
    def expandAllRegexInDict(self, itemsList, sourceDict, ignoreCase = False):
        """
        TODO: Maybe we can combine with getAllRegexMatches().
        """
        newDict = {}
        for key, value in sourceDict.items():
            expandedKeyList = self.getAllRegexMatches(itemsList, [key], ignoreCase = ignoreCase)
            for expandedKey in expandedKeyList:
                if type(value).__name__ == 'dict':
                    newDict[expandedKey] = self.expandAllRegexInDict(itemsList, value, \
                                                                        ignoreCase = ignoreCase)
                elif type(value).__name__ == 'list':
                    newDict[expandedKey] = self.getAllRegexMatches(itemsList, value, \
                                                                        ignoreCase = ignoreCase)
                else:
                    newDict[expandedKey] = self.getAllRegexMatches(itemsList, [value], \
                                                                        ignoreCase = ignoreCase)[0]
        return newDict
    
    def removeExcludeVariablesInDict(self, excludeList, sourceDict, ignoreCase = False):
        """
        Recursively removes elements in sourceDict that are also in excludeList
        """
        excludeListTmp = copy.deepcopy(excludeList)
        excludeListTmp = [x.lower for x in excludeListTmp] if ignoreCase else excludeListTmp
        newDict = {}
        leafNodeValueInDict = []
        for key, value in sourceDict.items():
            key = key.lower() if ignoreCase else key
            if key not in excludeList:
                if type(value).__name__ == 'dict':
                    newDict[key], leafNodeValueInDictTmp = self.removeExcludeVariablesInDict(excludeList, value, \
                                                                        ignoreCase = ignoreCase)
                    leafNodeValueInDict.extend(leafNodeValueInDictTmp)
                elif type(value).__name__ == 'list':
                    newDict[key] = [x for x in value if x.lower() not in excludeList] if ignoreCase else \
                                                    [x for x in value if x not in excludeList]
                    leafNodeValueInDict.extend(newDict[key])
                elif value.lower() not in excludeList:
                    newDict[key] = value
                    leafNodeValueInDict.append(newDict[key])
                elif (not ignoreCase) and value not in excludeList:
                    newDict[key] = value
                    leafNodeValueInDict.append(newDict[key])
                    
        return newDict, leafNodeValueInDict
               

    def readHeaderDataFromTextFile(self, dataDirectoryName, headerFileName = ""):
        """
        function to read header into list,
        filepath is specified as regex in self.dataConfigDict['localPaths']['headerFileName'].
        TODO: remove some redundant code in this function and that in reading data method.
        """
        headerList = []
        if len(headerFileName)<=0:
            return headerList
        try:
            # getting list of all files in the directory.            
            allFilesInPathList = []
            for (dirpath, dirnames, filenames) in os.walk(dataDirectoryName):
                allFilesInPathList.extend(filenames)
            self.logger.write('allFilesInPathList' + str(allFilesInPathList), 5)
            matchingFiles = self.getAllRegexMatches(allFilesInPathList, [self.headerFileName], ignoreCase = False)
            self.logger.write('matching files ' + str(matchingFiles) + '; numFiles '+str(len(matchingFiles)), 4)            
            self.logger.write('headerFile '+ str(matchingFiles[0]), 5)
            if not matchingFiles[0].startswith('/'):
                matchingFiles[0] = os.path.join(dataDirectoryName, matchingFiles[0])    
        except Exception as e:
            self.logger.write('ERROR: Error in reading header from ' + dataDirectoryName + \
                                                               str(e) + '; Returning with empy list', 1)
            self.dataConfigDict['criticalErrorsAndWarningsList'].append('ERROR: Error in reading header from ' + \
                                                     dataDirectoryName + '; Returning with empy list')
            return headerList
            
        self.logger.write('-----------------> reading header ', 4)
        dfHeader = pd.read_csv(matchingFiles[0], skip_blank_lines=True, header = 0, sep=self.sep)
        headerList = list(dfHeader)
        headerList = [x.lower() for x in headerList]
        del dfHeader
        gc.collect()
        self.logger.write('<----------------------', 4)
        return headerList
    
    def readDataFromOnePartFileInTextFormat(self, oneFile, headerInAllFiles, headerList, numFiles):
        """
        Reading one part file where self.fileType = "text"
        """
        # if headerlist is empty, it is assumed that header is present in all files.
        if headerInAllFiles:
            dfDataPart = pd.read_csv(oneFile, skip_blank_lines=True, header = 0, sep=self.sep)
            if len(headerList) <= 0:
                headerList = list(dfDataPart)
                headerList = [x.lower() for x in headerList]
            dfDataPart.columns = headerList
        else:
            dfDataPart = pd.read_csv(oneFile, skip_blank_lines=True, names=headerList, sep=self.sep)
        # getting exact number of total instances
        numInstances = len(dfDataPart)
        # if we roughly estimate that the file size is more than 1.1 times the required sample size, 
        # we start sampling the part files itself (to not blow up memory).
        if numFiles * len(dfDataPart) > 1.1 * self.maxSampleSize:
            sampleSize = int(1.1 * self.maxSampleSize / numFiles)
            dfDataPart = self.sampleData(dfDataPart, sampleSize)
        gc.collect()
        return numInstances, dfDataPart, headerList
            
    def readDataFromPartFiles(self, dataDirectoryName, dataFileNameList, headerList):
        """
        function to read all the data files in a directory,
        filepath is specified as regex in self.dataConfigDict['localPaths']['dataFileName'].
        It is assumed that if header file is separate from data, self.header is created by now.
        return: totalInstances, dfData
        """
        filesList = []
        try:
            # getting list of all files in the directory.            
            allFilesInPathList = []
            for (dirpath, dirnames, filenames) in os.walk(dataDirectoryName):
                allFilesInPathList.extend(filenames)
            self.logger.write('allFilesInPathList' + str(allFilesInPathList), 5)
            self.logger.write('dataFileNameList' + str(dataFileNameList), 5)
            matchingFiles = self.getAllRegexMatches(allFilesInPathList, dataFileNameList, \
                                                    ignoreCase = False)
            self.logger.write('matching files ' + str(matchingFiles) + '; numFiles '+str(len(matchingFiles)), 4)            
            for oneFile in matchingFiles:
                self.logger.write('oneFile '+ str(oneFile), 5)
                if oneFile.startswith('/'):
                    filesList.append(oneFile)
                else:
                    filesList.append(os.path.join(dataDirectoryName, oneFile))    
                if self.dataConfigDict['dryRun']:
                    break
        except Exception as e:
            self.logger.write('ERROR: Error in reading data from ' + dataDirectoryName + '\n' +\
                                                               str(e) + '; Returning with empy dataframe', 1)
            self.dataConfigDict['criticalErrorsAndWarningsList'].append('ERROR: Error in reading data from ' + \
                                                     dataDirectoryName + '; Returning with empy dataframe')
            dfData = pd.DataFrame(columns=headerList)
            return 0, dfData
            
        self.logger.write('-----------------> reading data ', 4)
        # a list that holds dataframes read from each of the files, which finally would be merged.
        dfDataPartList = list()
        totalInstances = 0
        numFiles = len(filesList)
        # creating a dataframe from each part and appending to dfDataPartList
        headerInAllFiles = True if len(headerList)<=0 else False        
        for oneFile in filesList:
            if self.fileType == 'text':
                numInstances, dfDataPart, headerList = self.readDataFromOnePartFileInTextFormat(oneFile, headerInAllFiles,\
                                                                                                headerList, numFiles)
                
            totalInstances += numInstances
            # appending to the dataframe list
            dfDataPartList.append(dfDataPart)

        # concatenating the dataframes into one and return
        dfData = pd.concat(dfDataPartList) if len(dfDataPartList) > 0 else pd.DataFrame(columns=headerList)
        dfData = dfData.reset_index(drop=True)
        dfData = self.sampleData(dfData, self.maxSampleSize)
        self.logger.write('dfData.shape = ' + str(dfData.shape), 4)
        # deleting garbage dataframes
        for dfDataPart in dfDataPartList:
            del dfDataPart

        del dfDataPartList
        gc.collect()
        self.logger.write('<----------------------', 4)
        return totalInstances, dfData
    
    def sampleData(self, dfData, sampleSize):
        if len(dfData) <= sampleSize:
            return dfData
        rindex = np.array(random.sample(xrange(len(dfData)), sampleSize))
        rindex = rindex.astype(np.int)
        return dfData.iloc[rindex]
    
    def identifyVariablesAndRemoveExtraColumns(self, dfData):  
        self.instanceIdColumns = []
        if len(self.instanceIdColumnsRegex) > 0:
            self.instanceIdColumns = self.getAllRegexMatches(self.headerList, self.instanceIdColumnsRegex, \
                                                                                        ignoreCase = True)
            for idColummn in self.instanceIdColumns:
                dfData[idColummn]= dfData[idColummn].astype(str)
        else:
            self.instanceIdColumns = ['instanceId']
            dfData[self.instanceIdColumns[0]] = dfData.reset_index().index.astype(str)
            
        self.instanceWeightColumn = []
        if len(self.instanceWeightColumnRegex) > 0:
            [self.instanceWeightColumn] = self.getAllRegexMatches(self.headerList, \
                                                  [self.instanceWeightColumnRegex], ignoreCase = True)
            self.logger.write('self.instanceWeightColumn'+str(self.instanceWeightColumn), 5)
        self.numericFeatures = self.getAllRegexMatches(self.headerList, self.numericFeaturesRegex, ignoreCase = True)
        self.categoricalFeatures = self.getAllRegexMatches(self.headerList, \
                                       self.categoricalFeaturesRegex, ignoreCase = True)  
        # all interventions are grouped into different phases. e.g. phase 3 where additional treatments are trained.
        # Since current implementation has only two phases, list in first index is used.
        self.interventions = self.getAllRegexMatches(self.headerList, self.interventionsRegex[0], ignoreCase = True)
        interventionConjunctionsTmp = []
        for conjunctions in self.interventionConjunctionsRegex:
            interventionConjunctionsTmp.append(self.getAllRegexMatches(self.headerList,\
                                                              conjunctions, ignoreCase = True))
                                                    
        interventionDisjunctionsTmp = []
        for disjunctions in self.interventionDisjunctionsRegex:
            interventionDisjunctionsTmp.append(self.getAllRegexMatches(self.headerList,\
                                                               disjunctions, ignoreCase = True))            
        self.binaryTargetNames = self.getAllRegexMatches(self.headerList, \
                                   self.binaryTargetNamesRegex, ignoreCase = True) 
        self.continuousTargetNames = self.getAllRegexMatches(self.headerList, \
                                   self.continuousTargetNamesRegex, ignoreCase = True)
        self.excludeColumns = self.getAllRegexMatches(self.headerList, self.excludeColumnsRegex, ignoreCase = True)
        self.actualTreatmentEffectsDict = self.expandAllRegexInDict(self.headerList, \
                                                    self.actualTreatmentEffectsRegex, ignoreCase = True)        
        self.numericFeatures = [x for x in self.numericFeatures if x not in self.excludeColumns]
        self.categoricalFeatures = [x for x in self.categoricalFeatures if x not in self.excludeColumns]
        self.interventions = [x for x in self.interventions if x not in self.excludeColumns]
        self.interventionConjunctions = []
        for conjunctions in interventionConjunctionsTmp:
            excludedConjunctions = set(conjunctions) - set(self.excludeColumns)
            if len(conjunctions) == len(excludedConjunctions):
                self.interventionConjunctions.append(conjunctions)
                                               
        self.interventionDisjunctions = []
        for disjunctions in interventionDisjunctionsTmp:
            excludedDisjunctions = set(disjunctions) - set(self.excludeColumns)
            if len(disjunctions) == len(excludedDisjunctions):
                self.interventionDisjunctions.append(disjunctions)            
            
        self.binaryTargetNames = [x for x in self.binaryTargetNames if x not in \
                                                                              self.excludeColumns]
        self.continuousTargetNames = [x for x in self.continuousTargetNames if x not in \
                                                                              self.excludeColumns]
        self.actualTreatmentEffectsDict, self.actualTreatmentEffectColums = \
                                            self.removeExcludeVariablesInDict(self.excludeColumns, \
                                                 self.actualTreatmentEffectsDict, ignoreCase = True)

        self.allRequiredColumns = list(set(self.instanceIdColumns + self.numericFeatures + \
                                           self.categoricalFeatures + self.interventions + \
                                           self.binaryTargetNames + self.continuousTargetNames + \
                                           self.actualTreatmentEffectColums))
        if len(self.instanceWeightColumn)>0:
            self.allRequiredColumns.append(self.instanceWeightColumn)
        
        dfData = dfData[self.allRequiredColumns]
        self.headerList = list(dfData)
        self.targets = list(set(self.continuousTargetNames + self.binaryTargetNames))
        self.features = list(set(self.numericFeatures + self.categoricalFeatures))
        return dfData
    
    def shuffleData(self, dfData):
        # rearranging index
        dfData = dfData.reset_index(drop=True)
        # shuffle data
        dfDataShuffled = dfData.reindex(np.random.permutation(dfData.index))
        dfData = dfDataShuffled
        gc.collect()
        # rearranging index
        dfData = dfData.reset_index(drop=True)
        return dfData
    
    
    def doRandomSplit(self, dfData, test_size = 0.0, randomState = -9999):
        if randomState <= 0:
            randomState = int(time.time()/1000)
        dfTrain, dfTest = train_test_split(dfData, test_size=test_size, random_state = randomState)
        return dfTrain, dfTest
    
    def doOneHotEncodingForCategoricalFeaturesTrain(self, dfData):
        dfData, self.categoricalDummyMappingDict = self.doOneHotEncodingForCategoricalFeatures(dfData)
        self.headerList = list(dfData)
        return dfData, self.categoricalDummyMappingDict
    
    def doOneHotEncodingForCategoricalFeatures(self, dfData):
        categoricalDummyMappingDict = {}
        for categoricalFeature in self.categoricalFeatures:
            dfDummy = pd.get_dummies(dfData[categoricalFeature], prefix = categoricalFeature, \
                                                                               dummy_na=True)
            dfDummy.fillna(value = 0, inplace = True)            
            categoricalDummyMappingDict[categoricalFeature] = list(dfDummy)
            dfData = pd.concat([dfData, dfDummy], axis = 1)
            dfData.drop([categoricalFeature], axis = 1, inplace = True)
        return dfData, categoricalDummyMappingDict
    
    def doOneHotEncodingForCategoricalFeaturesInTestOrValidAndAlignWithTrain(self, dfTrain, dfDataList):
        newDataList = []
        for dfData in dfDataList:
            dfData, dummyDict = self.doOneHotEncodingForCategoricalFeatures(dfData)
            dfTrain, dfData = dfTrain.align(dfData, join='left', axis=1)            
            dfData.fillna(value = 0, inplace = True)
            newDataList.append(dfData)
        return newDataList
    
    

