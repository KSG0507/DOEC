#!/usr/bin/env python
# coding: utf-8

"""
This is the driver for CDNN approach for causal analysis.
It can do with or without freezing layers.
The framework should work in CPU or GPU context.
"""

import os
import sys
import gc
import time
import locale
import random
import subprocess
import numpy as np
import pandas as pd
import mxnet
import sklearn.metrics as metrics
import math
import scipy
from scipy.stats import ttest_ind
import copy
import sklearn, math
from scipy import stats
from mxnet import gluon
from argparse import ArgumentParser

# ### Import python packages in this project

from utils import processConfig
from utils import environmentOptions
from data import getData
from data import processData
from modeling import modelTuner
from modeling import modelingIterator

# ### Function to read and process config files; format currently used is json

def readAndProcessConfigFiles(optsDict):
    '''
    Getting and formating config information
    '''
    dataConfigDict = processConfig.loadJsonConfigData(optsDict['dataConfiguration'])
    dataConfigDict = processConfig.replacePlaceholders(dataConfigDict, optsDict = optsDict)
    dataConfigDict = processConfig.overrideConfig(dataConfigDict, optsDict = optsDict)
    dataConfigDict = processConfig.addOptsDictToConfigDict(dataConfigDict, optsDict = optsDict)
    dataConfigDict = processConfig.removeDescriptionEntries(dataConfigDict)
    # the below entry is not populated yet. Idea is to populate using function call which also updates the log.
    dataConfigDict['criticalErrorsAndWarningsList'] = []
    modelingChoicesDict = processConfig.loadJsonConfigData(optsDict['modelingChoices'])
    modelingChoicesDict = processConfig.overrideConfig(modelingChoicesDict, optsDict = optsDict)
    modelingChoicesDict = processConfig.addOptsDictToConfigDict(modelingChoicesDict, optsDict = optsDict)
    modelingChoicesDict = processConfig.removeDescriptionEntries(modelingChoicesDict)
    return dataConfigDict, modelingChoicesDict

# since the directory structure has not been created yet, log file creation is deferred.
# below lists are used to save log output in memory until log file is created.
toPrintList = []
toPrintList.append(sys.argv)
toPrintVerboseList = []
toPrintVerboseList.append(5)
print 'python', ' '.join(sys.argv)

# parsing command line arguments
if __name__ == "__main__":
    argParser = ArgumentParser( description = "Causal DNN" )
    argParser.add_argument( "--dataConfiguration", type = str,   required = True,\
                            help = 'path to data config file.' )
    argParser.add_argument( "--modelingChoices", type = str,   required = True,\
                            help = 'path to modeling choices config file.' )
    argParser.add_argument( "--runTag", type = str,   required = False, default = '',\
                help = 'this creates subdirectory of each runs to avoid overwriting.'+ \
                                     'Include timestamp in the string if needed.' )
    argParser.add_argument( "--prodRun", type = str,   required = False, default = True,\
                                        help = 'whether this is a prod run or not.' )
    argParser.add_argument( "--dryRun", type = int,   required = False, default = 0,\
        help = 'if dryrun filename is provided, only that part file would be used to get faster results.' )
    argParser.add_argument( "--verboseLevel", type = int,   required = False, default = 0,\
                                help = '0 = no logging, 5 = all details logged.' )
    
    argDict = argParser.parse_known_args()
    
toPrintList.append(argDict)
toPrintVerboseList.append(5)

# combining known and unknown arguments - remember unknown arguments are for filling placeholders in data paths
optsDict  = {'dataConfiguration': argDict[0].dataConfiguration.strip(),\
             'modelingChoices': argDict[0].modelingChoices.strip(),\
             'prodRun': True if argDict[0].prodRun.lower() == 'true' else False, \
             'dryRun': int(argDict[0].dryRun), 'runTag': argDict[0].runTag.strip(), \
             'verboseLevel': int(argDict[0].verboseLevel)}

i = 0
while i < len(argDict[1]):
    optsDict[argDict[1][i].lstrip('-')] = argDict[1][i+1]
    i += 2

toPrintList.append(optsDict)
toPrintVerboseList.append(5)

# ### Getting start time, initializing randomState, read config files

modelingScriptStartTime = time.time()
locale.setlocale(locale.LC_ALL, '')
# add to config file after reading config file
randomState = int(modelingScriptStartTime*random.random()/1000000)
if (not optsDict['prodRun']) or optsDict['dryRun']:
    # fixed random variable used for testing.
    randomState = 5000
    
optsDict['randomState'] = randomState    
dataConfigDict, modelingChoicesDict = readAndProcessConfigFiles(optsDict)

# ### Create directories, download and prepare data & create logger

useBoto = False
if modelingChoicesDict['environmentVariables']['sagemaker'] > 1:
    useBoto = True
getData.downloadData(dataConfigDict=dataConfigDict, useBoto = useBoto,   toPrintList = toPrintList, \
                                                                toPrintVerboseList = toPrintVerboseList)
# log file is created here since it needed to create the directory structure before writing to file.
# First the toPrintList we already populated is written.
# Once logger.write is called with the text and verboseLevel for that text as arguments,
# logger prints only if the verboseLevel passed to write is lower than the verboseLevel passed from CLI.
# logger prints to both file and console - this can be changed later.
logger = environmentOptions.Logging(dataConfigDict, modelingScriptStartTime, toPrintList, toPrintVerboseList)

# ## Data preparation and pre-processing

# creating object for data processing
modelingDataObj = processData.ModelingData(dataConfigDict = dataConfigDict, \
                    modelingChoicesDict = modelingChoicesDict,logger = logger)

headerList = modelingDataObj.readHeaderDataFromTextFile(dataDirectoryName = dataConfigDict['localPaths']['rawDataDirectoryName'],\
                                                headerFileName = dataConfigDict['localPaths']['headerFileName'].strip())
logger.write('headerList: '+str(headerList), 4)

totalInstances, dfData = modelingDataObj.readDataFromPartFiles(dataDirectoryName = dataConfigDict['localPaths']['rawDataDirectoryName'],\
                                dataFileNameList = dataConfigDict['localPaths']['dataFileName'],headerList = headerList)
modelingDataObj.headerList = list(dfData)
logger.write('totalInstances ' + str(totalInstances), 4)
logger.write('sample data size ' + str(dfData.shape), 4)

logger.write(str(dfData.head(2)), 5)

scoringHeaderList = modelingDataObj.readHeaderDataFromTextFile(dataDirectoryName = dataConfigDict['localPaths']['scoringRawDataDirectoryName'],\
                                            headerFileName = dataConfigDict['localPaths']['scoringHeaderFileName'].strip())
logger.write('scoringHeaderList: '+str(scoringHeaderList), 4)

totalScoringInstances, dfScoringData = modelingDataObj.readDataFromPartFiles(\
                    dataDirectoryName =  dataConfigDict['localPaths']['scoringRawDataDirectoryName'],\
                    dataFileNameList = dataConfigDict['localPaths']['scoringDataFileName'],headerList = scoringHeaderList)
# if no scoring data, create empty dataframe with same columns as the raw data
if len(dfScoringData) <= 0:
    dfScoringData = dfData.head(0)
    
logger.write('totalScoringInstances ' + str(totalScoringInstances), 4)
logger.write('sample scoring data size ' + str(dfScoringData.shape), 4)

originalColumnList = list(dfData)
logger.write(','.join(list(dfData)), 5)

dfData = modelingDataObj.identifyVariablesAndRemoveExtraColumns(dfData)
identifiedColumnList = list(dfData)
logger.write('data shape after identifying columns ' + str(dfData.shape), 4)

logger.write('columns excluded are '+ str([x for x in originalColumnList if x not in identifiedColumnList]), 4)

logger.write(','.join(list(dfData)), 5)

if modelingChoicesDict['dataProcessing']['shuffleData'] > 0:
    dfData = modelingDataObj.shuffleData(dfData)
    logger.write('after shuffling, data shape: ' +str(dfData.shape), 4)

# if modelingChoicesDict['cvSetup']['numSplitForGettingConfidenceIntervals'] > 1 and
# modelingChoicesDict['cvSetup']['valid_fraction'] <= 0
# the code first makes valid_fraction = test_fraction and test_fraction = 0 and tunes the 
# network. After tuning, it resets test_fraction to previous value and sets valid_fraction = 0.
# this way, the parameters are tuned using one or a few splits. Then applied to different 
# splits to get stddev. Average of different splits is taken for treatment effect.
# This is useful when we don't have pleanty of data to create a hold out set for tuning but still want to get stddev
# if enseble is set to 1, test and valid fractions are not changed
test_fraction = modelingChoicesDict['cvSetup']['test_fraction']
if modelingChoicesDict['cvSetup']['numSplitForGettingConfidenceIntervals'] > 1  and \
                                modelingChoicesDict['cvSetup']['valid_fraction'] <= 0:
    logger.write('since doing different splits for confidence intervals, training '+ \
                                'on whole train data without valid set and testing on test data', 4)
    modelingChoicesDict['cvSetup']['valid_fraction'] = test_fraction
    modelingChoicesDict['cvSetup']['test_fraction'] = 0

logger.write('valid_fraction: '+ str(modelingChoicesDict['cvSetup']['valid_fraction'])+ '  test_fraction: '+ \
                                    str(modelingChoicesDict['cvSetup']['test_fraction']), 4)

modelingChoicesDict['cvSetup']['valid_fraction'] = modelingChoicesDict['cvSetup']['valid_fraction'] /(1 - modelingChoicesDict['cvSetup']['test_fraction'])
logger.write('adjusting valid_fraction to split train data agin. New value is '+ str(modelingChoicesDict['cvSetup']['valid_fraction']), 4)

cvSplits = processData.CrossValidationSplits()

# splitting into train and test sets.
cvSplits.dfTrain, cvSplits.dfTest = modelingDataObj.doRandomSplit(dfData, test_size = modelingChoicesDict['cvSetup']['test_fraction'],\
                                                                                 randomState = randomState)
logger.write('cvSplits.dfTrain.shape: ' + str(cvSplits.dfTrain.shape) + ' cvSplits.dfTest.shape: ' + str(cvSplits.dfTest.shape), 4)

cvSplits.dfTrain, cvSplits.categoricalDummyMappingDict =  modelingDataObj.doOneHotEncodingForCategoricalFeaturesTrain(cvSplits.dfTrain)
logger.write('cvSplits.dfTrain.shape: ' + str(cvSplits.dfTrain.shape), 4)
logger.write('oneHotEncodingMapping: \n'+str(cvSplits.categoricalDummyMappingDict), 4)
logger.write('- dfTrain.head(2)'+str(cvSplits.dfTrain.head(2)), 4)

[cvSplits.dfTest, cvSplits.dfScoringData] = modelingDataObj.doOneHotEncodingForCategoricalFeaturesInTestOrValidAndAlignWithTrain(cvSplits.dfTrain,\
                                                                             [cvSplits.dfTest, dfScoringData])
logger.write('cvSplits.dfTest.shape: ' + str(cvSplits.dfTest.shape), 4)

cvSplits.featureScaler, cvSplits.scaledFeaturesList = modelingDataObj.createScalerObj(cvSplits.dfTrain)
[cvSplits.dfTrain, cvSplits.dfTest, cvSplits.dfScoringData] = modelingDataObj.scaleFeatures([cvSplits.dfTrain, cvSplits.dfTest,\
                                             cvSplits.dfScoringData], cvSplits.featureScaler, cvSplits.scaledFeaturesList)
logger.write('train shape '+str(cvSplits.dfTrain.shape)+ '. test shape '+ str(cvSplits.dfTest.shape) + \
                                                            ' scoring data shape '+str(cvSplits.dfScoringData.shape), 4) 

columnsMetadata = modelingDataObj.getColumnsMetadata()

for key, value in columnsMetadata.items():
    logger.write(str(key)+': '+str(value)+'\n', 4)

# splitting train into train and validation tests.
if modelingChoicesDict['cvSetup']['valid_fraction'] <= 0:
    modelingChoicesDict['cvSetup']['numSplitsForHyperparameters'] = 1
cvSplits.cvList = [None] * modelingChoicesDict['cvSetup']['numSplitsForHyperparameters']
for split in range(len(cvSplits.cvList)):
    dfTrainTmp, dfValidTmp = modelingDataObj.doRandomSplit(cvSplits.dfTrain, test_size = \
                                        modelingChoicesDict['cvSetup']['valid_fraction'], randomState = randomState*(split+1))
    cvSplits.cvList[split] = {'dfTrain': dfTrainTmp, 'dfValid': dfValidTmp}
    logger.write('Split: '+str(split)+' - train shape '+str(cvSplits.cvList[split]['dfTrain'].shape)+\
                                        '. valid shape '+ str(cvSplits.cvList[split]['dfValid'].shape), 4)    

# split data into features,interventions, target etc.
for split in range(len(cvSplits.cvList)):
    cvSplits.cvList[split]['columnsMetadata'] = columnsMetadata
    for trainOrValid in ['Train', 'Valid']:
        [dfInstanceIds, dfInstanceWeights, dfFeatures, dfInterventions, dfTargets, dfActualTreatmentEffects] = \
                                    modelingDataObj.getInstanceIdWeightFeaturesInterventionsTargetActualTreatmentEffects(\
                                                                    cvSplits.cvList[split]['df'+trainOrValid])
        # can be directly assigned in the above statement; but this is more readable
        cvSplits.cvList[split]['dfInstanceIds' + trainOrValid] = dfInstanceIds
        cvSplits.cvList[split]['dfInstanceWeights' + trainOrValid] = dfInstanceWeights
        cvSplits.cvList[split]['dfFeatures' + trainOrValid] = dfFeatures
        cvSplits.cvList[split]['dfInterventions' + trainOrValid] = dfInterventions
        cvSplits.cvList[split]['dfTargets' + trainOrValid] = dfTargets
        cvSplits.cvList[split]['dfActualTreatmentEffects' + trainOrValid] = dfActualTreatmentEffects
        

# for separating test and scoring data into features, interventions, etc.
[dfInstanceIds, dfInstanceWeights, dfFeatures, dfInterventions, dfTargets, dfActualTreatmentEffects] = \
                                        modelingDataObj.getInstanceIdWeightFeaturesInterventionsTargetActualTreatmentEffects( \
                                                                                           cvSplits.dfTest)
# pointing test data from the splits itself - although all test sets for these splits are same.
# data is not duplicated here. TODO: see if moving this to the previous loop makes more sense.
for split in range(len(cvSplits.cvList)):
    cvSplits.cvList[split]['dfInstanceIdsTest'] = dfInstanceIds
    cvSplits.cvList[split]['dfInstanceWeightsTest'] = dfInstanceWeights
    cvSplits.cvList[split]['dfFeaturesTest'] = dfFeatures
    cvSplits.cvList[split]['dfInterventionsTest'] = dfInterventions
    cvSplits.cvList[split]['dfTargetsTest'] = dfTargets.copy(deep = True)
    cvSplits.cvList[split]['dfActualTreatmentEffectsTest'] = dfActualTreatmentEffects 
    
# for separating scoring data into features, interventions, etc.
[dfInstanceIds, dfInstanceWeights, dfFeatures, dfInterventions, dfTargets, dfActualTreatmentEffects] = \
                                        modelingDataObj.getInstanceIdWeightFeaturesInterventionsTargetActualTreatmentEffects( \
                                                                                           cvSplits.dfScoringData)
# pointing test data from the splits itself - although all test sets for these splits are same.
# data is not duplicated here. TODO: see if moving this to the previous loop makes more sense.
for split in range(len(cvSplits.cvList)):
    cvSplits.cvList[split]['dfInstanceIdsScoring'] = dfInstanceIds
    cvSplits.cvList[split]['dfInstanceWeightsScoring'] = dfInstanceWeights
    cvSplits.cvList[split]['dfFeaturesScoring'] = dfFeatures
    cvSplits.cvList[split]['dfInterventionsScoring'] = dfInterventions
    cvSplits.cvList[split]['dfTargetsScoring'] = dfTargets.copy(deep = True)
    cvSplits.cvList[split]['dfActualTreatmentEffectsScoring'] = dfActualTreatmentEffects     

# move this to the crossvalidation function for exploring hyperparameters, later.
# batch size can be outer most loop so that there need not be much recomputation
maxBatchSize = len(cvSplits.cvList[0]['dfTargetsTrain'])
for split in range(len(cvSplits.cvList)):
    logger.write('---------- split : '+ str(split) + ' ------------', 4)
    for trainOrTest in ['Train', 'Test', 'Valid', 'Scoring']:
        if len(cvSplits.cvList[split]['dfTargets'+trainOrTest]) > 0 and len(cvSplits.cvList[split]['dfTargets'+trainOrTest]) < maxBatchSize:
            # adjusting maxBatchSize to be lower (taking randomness into account) than the smallest data partition.
            maxBatchSize = int(len(cvSplits.cvList[split]['dfTargets'+trainOrTest]) * 0.9)
        logger.write('...'+trainOrTest+'...', 4)
        logger.write('cvSplits[split].dfInstanceIds'+trainOrTest+'.shape' + str(cvSplits.cvList[split]['dfInstanceIds'+trainOrTest].shape), 4)
        logger.write('cvSplits[split].dfInstanceWeights'+trainOrTest+'.shape' + str(cvSplits.cvList[split]['dfInstanceWeights'+trainOrTest].shape), 4)
        logger.write('cvSplits[split].dfFeatures'+trainOrTest+'.shape' + str(cvSplits.cvList[split]['dfFeatures'+trainOrTest].shape), 4)
        logger.write('cvSplits[split].dfInterventions'+trainOrTest+'.shape' + str(cvSplits.cvList[split]['dfInterventions'+trainOrTest].shape), 4)
        logger.write('cvSplits[split].dfTargets'+trainOrTest+'.shape' + str(cvSplits.cvList[split]['dfTargets'+trainOrTest].shape), 4)
        logger.write('cvSplits[split].dfActualTreatmentEffects'+trainOrTest+'.shape' + str(cvSplits.cvList[split]['dfActualTreatmentEffects'+\
                                                                                                                        trainOrTest].shape), 4)
        
        

# ## Phase 1 training

# performing grid search for phase 1
modelTunerObj = modelTuner.ModelTuner(cvSplits = cvSplits, dataConfigDict= dataConfigDict,  modelingChoicesDict = modelingChoicesDict,\
                                                                   maxBatchSize = maxBatchSize, logger = logger, phase = 1)

modelTunerObj.tuneHyperParameters()

logger.write('Phase 1: Error metrics on train valid and test sets;'+ 'list represents different train-valid splits', 2)
logger.write('mean dfTargetsTrain: ' + str(cvSplits.cvList[0]['dfTargetsTrain'].mean()), 2)
logger.write('mean dfTargetsTest: ' + str(cvSplits.cvList[0]['dfTargetsTest'].mean()), 2)
trainMetric, validMetric = modelTunerObj.getTrainAndValidMetricsFromSelectedModel()
logger.write('trainMetric: '+str(trainMetric), 2)
logger.write('validMetric: '+str(validMetric), 2)
if len(cvSplits.cvList[0]['dfFeaturesTest'])>0:
    yf_test_prediction = modelTunerObj.getPredictionsUsingSelectedModel(phase = 1, dfFeatures = cvSplits.cvList[0]['dfFeaturesTest'],\
             dfInterventions = cvSplits.cvList[0]['dfInterventionsTest'], instanceWeight = cvSplits.cvList[0]['dfInstanceWeightsTest'])
    yf_test_actual = np.asarray(cvSplits.cvList[0]['dfTargetsTest'])
    metricsDictTest = modelTunerObj.getMetricsOnPredictions(actual = yf_test_actual, prediction = yf_test_prediction)
    logger.write('testMetric: '+str(metricsDictTest), 2)

modelTunerObj.getChosenParameters(phase = 1, split = -1)
modelTunerObj.saveSelectedModel(phase = 1)

# ## Phase 2 training

modelTunerObj.phase = 2

# ###### Explicitly computing residual and adjusting the target variable

if modelingChoicesDict['modelSpecs']['computeOutcomeResidualExplicitly'] > 0:
    for split in range(len(cvSplits.cvList)):
        logger.write('---------- split : '+ str(split) + ' ------------', 4)
        dfFeaturesValid = cvSplits.cvList[split]['dfFeaturesValid']
        dfInterventionsValid = cvSplits.cvList[split]['dfInterventionsValid']
        dfInstanceWeightValid = cvSplits.cvList[split]['dfInstanceWeightsValid']
        dfTargetsValid = cvSplits.cvList[split]['dfTargetsValid']
        dfFeaturesTrain = cvSplits.cvList[split]['dfFeaturesTrain']
        dfInterventionsTrain = cvSplits.cvList[split]['dfInterventionsTrain']
        dfInstanceWeightTrain = cvSplits.cvList[split]['dfInstanceWeightsTrain']
        dfTargetsTrain = cvSplits.cvList[split]['dfTargetsTrain']
        dfFeaturesTest = cvSplits.cvList[split]['dfFeaturesTest']
        dfInterventionsTest = cvSplits.cvList[split]['dfInterventionsTest']
        dfInstanceWeightTest = cvSplits.cvList[split]['dfInstanceWeightsTest']
        dfTargetsTest = cvSplits.cvList[split]['dfTargetsTest']
        logger.write('dfTargetsTrain before residual computation \n'+ str(dfTargetsTrain.head())+ '\n'+ str(dfTargetsTrain.describe()), 4)
        logger.write('dfTargetsValid before residual computation \n'+ str(dfTargetsValid.head())+ '\n'+ str(dfTargetsValid.describe()), 4)
        logger.write('dfTargetsTest before residual computation \n'+ str(dfTargetsTest.head())+ '\n'+ str(dfTargetsTest.describe()), 4)
        y_train_prediction = modelTunerObj.getPredictionsUsingSelectedModel(phase = 1, dfFeatures = dfFeaturesTrain, \
                                                        dfInterventions = dfInterventionsTrain,instanceWeight = dfInstanceWeightTrain)
        y_valid_prediction = modelTunerObj.getPredictionsUsingSelectedModel(phase = 1, dfFeatures = dfFeaturesValid, \
                                                        dfInterventions = dfInterventionsValid,instanceWeight = dfInstanceWeightValid)
        y_test_prediction = modelTunerObj.getPredictionsUsingSelectedModel(phase = 1, dfFeatures = dfFeaturesTest, \
                                                        dfInterventions = dfInterventionsTest,instanceWeight = dfInstanceWeightTest)
        logger.write('dfTargetsTrain.mean() before residual computation '+ str(dfTargetsTrain.mean()), 4)
        logger.write('dfTargetsValid.mean() before residual computation '+ str(dfTargetsValid.mean()), 4)
        logger.write('dfTargetsTest.mean() before residual computation '+ str(dfTargetsTest.mean()), 4)
        logger.write('y_train_prediction'+ str(y_train_prediction.mean())+ str(y_train_prediction[:5]), 4)
        logger.write('y_valid_prediction'+ str(y_valid_prediction.mean())+ str(y_valid_prediction[:5]), 4)
        logger.write('y_test_prediction'+ str(y_test_prediction.mean())+ str(y_test_prediction[:5]), 4)
        targetsList = list(dfTargetsTrain)
        for i in range(len(targetsList)):
            target = targetsList[i]
            dfTargetsTrain[target] = dfTargetsTrain[target] - y_train_prediction[:,i].ravel()
            dfTargetsValid[target] = dfTargetsValid[target] - y_valid_prediction[:,i].ravel()
            dfTargetsTest[target] = dfTargetsTest[target] - y_test_prediction[:,i].ravel()

        logger.write('cvSplits.cvList[split][dfTargetsTrain] after residual computation \n'+ \
                    str(cvSplits.cvList[split]['dfTargetsTrain'].head())+ str(cvSplits.cvList[split]['dfTargetsTrain'].describe()), 4)
        logger.write('cvSplits.cvList[split][dfTargetsValid] after residual computation \n'+ \
                    str(cvSplits.cvList[split]['dfTargetsValid'].head())+ str(cvSplits.cvList[split]['dfTargetsValid'].describe()), 4)
        logger.write('cvSplits.cvList[split][dfTargetsTest] after residual computation \n'+ \
                    str(cvSplits.cvList[split]['dfTargetsTest'].head())+ str(cvSplits.cvList[split]['dfTargetsTest'].describe()), 4)

modelTunerObj.tuneHyperParameters()

logger.write('Phase 2: Error metrics on train valid and test sets;'+ 'list represents different train-valid splits', 3)
logger.write('mean dfTargetsTrain: ' + str(cvSplits.cvList[0]['dfTargetsTrain'].mean()), 2)
logger.write('mean dfTargetsTest: ' + str(cvSplits.cvList[0]['dfTargetsTest'].mean()), 2)
trainMetric, validMetric = modelTunerObj.getTrainAndValidMetricsFromSelectedModel()
logger.write('trainMetric: '+str(trainMetric), 2)
logger.write('validMetric: '+str(validMetric), 2)
if len(cvSplits.cvList[0]['dfFeaturesTest'])>0:
    yf_test_prediction = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = cvSplits.cvList[0]['dfFeaturesTest'],\
             dfInterventions = cvSplits.cvList[0]['dfInterventionsTest'], instanceWeight = cvSplits.cvList[0]['dfInstanceWeightsTest'])
    yf_test_actual = np.asarray(cvSplits.cvList[0]['dfTargetsTest'])
    metricsDictTest = modelTunerObj.getMetricsOnPredictions(actual = yf_test_actual, prediction = yf_test_prediction)
    logger.write('testMetrics: '+str(metricsDictTest), 2)

modelTunerObj.getChosenParameters(phase = 2, split = -1)
modelTunerObj.saveSelectedModel(phase = 2)

# ## Computing and saving outcome predictions

interventionsList = list(cvSplits.cvList[0]['dfInterventionsTrain'])
# if test set is empty, we need to make the valid data from first split as test, to get the treatment effect.
# please note, the scoring is still done using all models trained on different splits.
if len(cvSplits.cvList[0]['dfFeaturesTest']) <= 0:
    dfInstanceIdsTest = cvSplits.cvList[0]['dfInstanceIdsValid']
    dfFeaturesTest = cvSplits.cvList[0]['dfFeaturesValid']
    dfInterventionsTest = cvSplits.cvList[0]['dfInterventionsValid']
    dfInstanceWeightTest = cvSplits.cvList[0]['dfInstanceWeightsValid']
    dfTargetsTest = cvSplits.cvList[0]['dfTargetsValid']
    dfActualTreatmentEffectsTest = cvSplits.cvList[0]['dfActualTreatmentEffectsValid']
    dfInstanceIdsTrain = cvSplits.cvList[0]['dfInstanceIdsTrain']
    dfFeaturesTrain = cvSplits.cvList[0]['dfFeaturesTrain']
    dfInterventionsTrain = cvSplits.cvList[0]['dfInterventionsTrain']
    dfInstanceWeightTrain = cvSplits.cvList[0]['dfInstanceWeightsTrain']
    dfTargetsTrain = cvSplits.cvList[0]['dfTargetsTrain']
    dfActualTreatmentEffectsTrain = cvSplits.cvList[0]['dfActualTreatmentEffectsTrain']
else:
    # combining train and validation to get the whole train data
    dfInstanceIdsTest = cvSplits.cvList[0]['dfInstanceIdsTest']
    dfFeaturesTest = cvSplits.cvList[0]['dfFeaturesTest']
    dfInterventionsTest = cvSplits.cvList[0]['dfInterventionsTest']
    dfInstanceWeightTest = cvSplits.cvList[0]['dfInstanceWeightsTest']
    dfTargetsTest = cvSplits.cvList[0]['dfTargetsTest']
    dfActualTreatmentEffectsTest = cvSplits.cvList[0]['dfActualTreatmentEffectsTest']    
    dfInstanceIdsTrain = pd.concat([cvSplits.cvList[0]['dfInstanceIdsTrain'], cvSplits.cvList[0]['dfInstanceIdsValid']], copy = False)
    dfFeaturesTrain = pd.concat([cvSplits.cvList[0]['dfFeaturesTrain'], cvSplits.cvList[0]['dfFeaturesValid']], copy = False)
    dfInterventionsTrain = pd.concat([cvSplits.cvList[0]['dfInterventionsTrain'],cvSplits.cvList[0]['dfInterventionsValid']], copy = False)
    dfInstanceWeightTrain = pd.concat([cvSplits.cvList[0]['dfInstanceWeightsTrain'],cvSplits.cvList[0]['dfInstanceWeightsValid']], copy = False)
    dfTargetsTrain = pd.concat([cvSplits.cvList[0]['dfTargetsTrain'], cvSplits.cvList[0]['dfTargetsValid']], copy = False)
    dfActualTreatmentEffectsTrain = pd.concat([cvSplits.cvList[0]['dfActualTreatmentEffectsTrain'], \
                                                                cvSplits.cvList[0]['dfActualTreatmentEffectsValid']], copy = False)
    
dfInstanceIdsScoring = cvSplits.cvList[0]['dfInstanceIdsScoring']
dfFeaturesScoring = cvSplits.cvList[0]['dfFeaturesScoring']
dfInterventionsScoring = cvSplits.cvList[0]['dfInterventionsScoring']
dfInstanceWeightScoring = cvSplits.cvList[0]['dfInstanceWeightsScoring']
dfTargetsScoring = cvSplits.cvList[0]['dfTargetsScoring']
dfActualTreatmentEffectsScoring = cvSplits.cvList[0]['dfActualTreatmentEffectsScoring']

# Dataframe for storing the treatment effect metrics
dfMeanTreatmentEffects = pd.DataFrame(columns = ['intervention', 'target', 'trainOrTest', 'meanEstimatedTreatmentEffect', 'RMSE', 'MAE', 'ME'])

# save actual and predictions. This is useful for non-causal objectives and also post-proecessing requirements
dfInstanceIdsTrain_forPrediction = dfInstanceIdsTrain.copy(deep = True)
dfInstanceIdsTest_forPrediction = dfInstanceIdsTest.copy(deep = True)
dfInstanceIdsScoring_forPrediction = dfInstanceIdsScoring.copy(deep = True)
y_train_prediction = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesTrain, \
                                        dfInterventions = dfInterventionsTrain,instanceWeight = dfInstanceWeightTrain)
y_test_prediction = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesTest, \
                                        dfInterventions = dfInterventionsTest,instanceWeight = dfInstanceWeightTest)
y_scoring_prediction = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesScoring, \
                                        dfInterventions = dfInterventionsScoring,instanceWeight = dfInstanceWeightScoring)
targetsList = list(dfTargetsTrain)
for i in range(len(targetsList)):
    target = targetsList[i]
    dfInstanceIdsTrain_forPrediction[target+'_prediction'] = y_train_prediction[:,i].ravel()
    dfInstanceIdsTest_forPrediction[target+'_prediction'] = y_test_prediction[:,i].ravel()
    dfInstanceIdsScoring_forPrediction[target+'_prediction'] = y_scoring_prediction[:,i].ravel()

dfInstanceIdsTrain_forPrediction.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'outcomePredictionsTrain_.csv'),\
                                                                                                                             index=False)    
dfInstanceIdsTest_forPrediction.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'outcomePredictionsTest_.csv'), \
                                                                                                                             index=False)    
dfInstanceIdsScoring_forPrediction.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'outcomePredictionsScoring_.csv'), \
                                                                                                                             index=False)    

# ## Treatment effect computation

scoringStartTime = time.time()
att = True if dataConfigDict['interventions']['treatmentEffectOnTreatedOnly'] > 0 else False
totalInterventions = dfInterventionsTest.shape[1]
for interventionNum in range(len(interventionsList)):
    intervention = interventionsList[interventionNum]
    interventionsIncrementValue = modelingDataObj.interventionsIncrementValue
    scoringForOneInterventionStartTime = time.time()
    logger.write('========== intervention '+str(interventionNum)+ ': '+intervention + ' ==========', 3)
    if att:
        dfConcatTrain = pd.concat([dfInstanceIdsTrain, dfFeaturesTrain, dfInstanceWeightTrain, dfTargetsTrain, \
                                                dfInterventionsTrain, dfActualTreatmentEffectsTrain], axis = 1)
        dfConcatTrain = dfConcatTrain[dfConcatTrain[intervention] > 0]
        dfConcatTest = pd.concat([dfInstanceIdsTest, dfFeaturesTest, dfInstanceWeightTest, dfTargetsTest,  dfInterventionsTest, \
                                                                                        dfActualTreatmentEffectsTest], axis = 1)
        dfConcatTest = dfConcatTest[dfConcatTest[intervention] > 0]
        dfConcatScoring = pd.concat([dfInstanceIdsScoring, dfFeaturesScoring, dfInstanceWeightScoring, dfTargetsScoring,  \
                                                                dfInterventionsScoring, dfActualTreatmentEffectsScoring], axis = 1)
        dfConcatScoring = dfConcatScoring[dfConcatScoring[intervention] > 0]
        dfInstanceIdsTrain_forIntervention = modelingDataObj.getInstanceIds(dfConcatTrain)
        dfInstanceIdsTest_forIntervention = modelingDataObj.getInstanceIds(dfConcatTest)
        dfInstanceIdsScoring_forIntervention = modelingDataObj.getInstanceIds(dfConcatScoring)
        dfFeaturesTrain_forIntervention = modelingDataObj.getFeatures(dfConcatTrain)
        dfFeaturesTest_forIntervention = modelingDataObj.getFeatures(dfConcatTest)
        dfFeaturesScoring_forIntervention = modelingDataObj.getFeatures(dfConcatScoring)
        dfInstanceWeightTrain_forIntervention = modelingDataObj.getInstanceWeights(dfConcatTrain)
        dfInstanceWeightTest_forIntervention = modelingDataObj.getInstanceWeights(dfConcatTest)
        dfInstanceWeightScoring_forIntervention = modelingDataObj.getInstanceWeights(dfConcatScoring)
        dfTargetsTrain_forIntervention = modelingDataObj.getTargets(dfConcatTrain)
        dfTargetsTest_forIntervention = modelingDataObj.getTargets(dfConcatTest)
        dfTargetsScoring_forIntervention = modelingDataObj.getTargets(dfConcatScoring)
        dfInterventionsTrain_forIntervention = modelingDataObj.getInterventions(dfConcatTrain)
        dfInterventionsTest_forIntervention = modelingDataObj.getInterventions(dfConcatTest)
        dfInterventionsScoring_forIntervention = modelingDataObj.getInterventions(dfConcatScoring)
        dfActualTreatmentEffectsTrain_forIntervention = modelingDataObj.getActualTreatmentEffects(dfConcatTrain)
        dfActualTreatmentEffectsTest_forIntervention = modelingDataObj.getActualTreatmentEffects(dfConcatTest)
        dfActualTreatmentEffectsScoring_forIntervention = modelingDataObj.getActualTreatmentEffects(dfConcatScoring)
            
    else:
        dfInstanceIdsTrain_forIntervention = dfInstanceIdsTrain.copy(deep = True)
        dfInstanceIdsTest_forIntervention = dfInstanceIdsTest.copy(deep = True)
        dfInstanceIdsScoring_forIntervention = dfInstanceIdsScoring.copy(deep = True)
        dfFeaturesTrain_forIntervention = dfFeaturesTrain
        dfFeaturesTest_forIntervention = dfFeaturesTest
        dfFeaturesScoring_forIntervention = dfFeaturesScoring
        dfInstanceWeightTrain_forIntervention = dfInstanceWeightTrain
        dfInstanceWeightTest_forIntervention = dfInstanceWeightTest
        dfInstanceWeightScoring_forIntervention = dfInstanceWeightScoring
        dfTargetsTrain_forIntervention = dfTargetsTrain
        dfTargetsTest_forIntervention = dfTargetsTest
        dfTargetsScoring_forIntervention = dfTargetsScoring
        dfInterventionsTrain_forIntervention = dfInterventionsTrain.copy(deep = True)
        dfInterventionsTest_forIntervention = dfInterventionsTest.copy(deep = True)
        dfInterventionsScoring_forIntervention = dfInterventionsScoring.copy(deep = True)
        dfActualTreatmentEffectsTrain_forIntervention = dfActualTreatmentEffectsTrain
        dfActualTreatmentEffectsTest_forIntervention = dfActualTreatmentEffectsTest
        dfActualTreatmentEffectsScoring_forIntervention = dfActualTreatmentEffectsScoring           
        if interventionsIncrementValue == 0:
            # assuming binary when it is not att and interventionsIncrementValue == 0
            dfInterventionsTrain_forIntervention[intervention] = 1
            dfInterventionsTest_forIntervention[intervention] = 1
            dfInterventionsScoring_forIntervention[intervention] = 1        

    if interventionsIncrementValue > 0:
        dfInterventionsTrain_forIntervention[intervention] = dfInterventionsTrain_forIntervention[intervention] +                                                                 interventionsIncrementValue
        dfInterventionsTest_forIntervention[intervention] = dfInterventionsTest_forIntervention[intervention] +                                                                 interventionsIncrementValue
        dfInterventionsScoring_forIntervention[intervention] = dfInterventionsScoring_forIntervention[intervention] +                                                                 interventionsIncrementValue
        # for interventionsIncrementValue < 0, y_1 is predicted with actual value and y_0 is predicted after decreasing 
        # the intervention value. The following change of interventionsIncrementValue will help to adjust treatment value
        # in the same way for both interventionsIncrementValue > 0 or < 0
        interventionsIncrementValue = -1 * interventionsIncrementValue            
            
    y_train_prediction_asTreatment = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = \
                                        dfFeaturesTrain_forIntervention, dfInterventions = dfInterventionsTrain_forIntervention,\
                                                                        instanceWeight = dfInstanceWeightTrain_forIntervention)
    logger.write('y_train_prediction_asTreatment: '+str(y_train_prediction_asTreatment.mean()), 3)    
    y_test_prediction_asTreatment = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = \
                                        dfFeaturesTest_forIntervention, dfInterventions = dfInterventionsTest_forIntervention,\
                                                                        instanceWeight = dfInstanceWeightTest_forIntervention)
    logger.write('y_test_prediction_asTreatment: '+str(y_test_prediction_asTreatment.mean()), 3)
    y_scoring_prediction_asTreatment = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = \
                                        dfFeaturesScoring_forIntervention, dfInterventions = dfInterventionsScoring_forIntervention,\
                                                                    instanceWeight = dfInstanceWeightScoring_forIntervention)
    if len(y_scoring_prediction_asTreatment) > 0:
        logger.write('y_scoring_prediction_asTreatment: '+str(y_scoring_prediction_asTreatment.mean()), 3)    
    logger.write(' dfTargetsTrain.shape ' + str(dfTargetsTrain_forIntervention.shape)+ ' y_train_prediction_asTreatment.shape ' \
                                            + str(y_train_prediction_asTreatment.shape) + ' dfTargetsTest.shape '+ \
                                            str(dfTargetsTest_forIntervention.shape) + ' y_test_prediction_asTreatment.shape ' + \
                                            str(y_test_prediction_asTreatment.shape)+ ' dfTargetsScoring.shape '+ \
                                            str(dfTargetsScoring_forIntervention.shape) + ' y_scoring_prediction_asTreatment.shape ' +\
                                                                                 str(y_scoring_prediction_asTreatment.shape), 5)
    # decementing the intervention value to get y_0: prediction as control
    if interventionsIncrementValue < 0:
        dfInterventionsTrain_forIntervention[intervention] = dfInterventionsTrain_forIntervention[intervention] + \
                                                                                        interventionsIncrementValue
        dfInterventionsTest_forIntervention[intervention] = dfInterventionsTest_forIntervention[intervention] +  \
                                                                                       interventionsIncrementValue
        dfInterventionsScoring_forIntervention[intervention] = dfInterventionsScoring_forIntervention[intervention] + \
                                                                                        interventionsIncrementValue
        dfInterventionsTrain_forIntervention[intervention] = dfInterventionsTrain_forIntervention[intervention].\
                                                                                       apply(lambda x: 0 if x < 0 else x)
        dfInterventionsTest_forIntervention[intervention] = dfInterventionsTest_forIntervention[intervention].\
                                                                                       apply(lambda x: 0 if x < 0 else x)
        dfInterventionsScoring_forIntervention[intervention] = dfInterventionsScoring_forIntervention[intervention].\
                                                                                       apply(lambda x: 0 if x < 0 else x)
            
    else:
        dfInterventionsTrain_forIntervention[intervention] = 0
        dfInterventionsTest_forIntervention[intervention] = 0
        dfInterventionsScoring_forIntervention[intervention] = 0     
   
    y_train_prediction_asControl = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, \
                                    dfFeatures = dfFeaturesTrain_forIntervention,\
                                    dfInterventions = dfInterventionsTrain_forIntervention,\
                                    instanceWeight = dfInstanceWeightTrain_forIntervention)
    logger.write('y_train_prediction_asControl: '+str(y_train_prediction_asControl.mean()), 3)        
    y_test_prediction_asControl = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, \
                                    dfFeatures = dfFeaturesTest_forIntervention, \
                                    dfInterventions = dfInterventionsTest_forIntervention,\
                                    instanceWeight = dfInstanceWeightTest_forIntervention)
    logger.write('y_test_prediction_asControl: '+str(y_test_prediction_asControl.mean()), 3) 
    y_scoring_prediction_asControl = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, \
                                    dfFeatures = dfFeaturesScoring_forIntervention, \
                                    dfInterventions = dfInterventionsScoring_forIntervention,\
                                    instanceWeight = dfInstanceWeightScoring_forIntervention)
    if len(y_scoring_prediction_asControl) > 0:
        logger.write('y_scoring_prediction_asControl: '+str(y_scoring_prediction_asControl.mean()), 3)     
    logger.write(' dfTargetsTrain.shape ' + str(dfTargetsTrain_forIntervention.shape)+ ' y_train_prediction_asControl.shape ' +\
                    str(y_train_prediction_asControl.shape) + ' dfTargetsTest.shape '+ str(dfTargetsTest_forIntervention.shape) +\
                    ' y_test_prediction_asControl.shape ' + str(y_test_prediction_asControl.shape) + ' dfTargetsScoring.shape '+ \
                    str(dfTargetsScoring_forIntervention.shape) + ' y_scoring_prediction_asControl.shape ' + \
                                                                                    str(y_scoring_prediction_asControl.shape), 5)
    # computing treatment effects at individual level for.
    te_train_prediction = y_train_prediction_asTreatment - y_train_prediction_asControl    
    te_test_prediction = y_test_prediction_asTreatment - y_test_prediction_asControl
    te_scoring_prediction = y_scoring_prediction_asTreatment - y_scoring_prediction_asControl
    logger.write(' dfTargetsTrain.shape ' + str(dfTargetsTrain_forIntervention.shape)+ ' te_train_prediction.shape ' + \
                    str(te_train_prediction.shape) + ' dfTargetsTest.shape '+ str(dfTargetsTest_forIntervention.shape) + \
                    ' te_test_prediction.shape ' + str(te_test_prediction.shape)+ ' dfTargetsScoring.shape '+ \
                    str(dfTargetsScoring_forIntervention.shape) + ' te_scoring_prediction.shape ' + str(te_scoring_prediction.shape), 5)
    targetsList = list(dfTargetsTrain)
    for i in range(len(targetsList)):
        target = targetsList[i]
        meanTreatmentEffectTrain = te_train_prediction[:,i].mean()
        # if test data is empty, te_test_prediction will be empty numpy.ndarray and the mean will get nan.
        meanTreatmentEffectTest = te_test_prediction[:,i].mean()    
        meanTreatmentEffectScoring = te_scoring_prediction[:,i].mean() if len(te_scoring_prediction) > 0 else -99999.9
        logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+' in train: '+str(meanTreatmentEffectTrain), 2)   
        logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+' in test: '+str(meanTreatmentEffectTest), 2)      
        logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+' in scoring data: '+str(meanTreatmentEffectScoring), 2)   
        metricsDictTrain = {'negOfAUC' : 1000, 'RMSE' : -99999.9, 'MAE' : -99999.9, 'ME' : -99999.9, 'metricToMinimize' : 'RMSE'}
        metricsDictTest = {'negOfAUC' : 1000, 'RMSE' : -99999.9, 'MAE' : -99999.9, 'ME' : -99999.9, 'metricToMinimize' : 'RMSE'}
        metricsDictScoring = {'negOfAUC' : 1000, 'RMSE' : -99999.9, 'MAE' : -99999.9, 'ME' : -99999.9, 'metricToMinimize' : 'RMSE'}
        if intervention in modelingDataObj.actualTreatmentEffectsDict.keys() and \
                                                target in modelingDataObj.actualTreatmentEffectsDict[intervention]:
            actualTreatmentEffectColumn = modelingDataObj.actualTreatmentEffectsDict[intervention][target]
            metricsDictTrain = modelTunerObj.getMetricsOnPredictions(actual = \
                                    dfActualTreatmentEffectsTrain_forIntervention[[actualTreatmentEffectColumn]].values, \
                                                                                    prediction = te_train_prediction[:,i])
            logger.write('>>> treatment effect prediction ('+intervention+', '+ target +') vs actual in train: Error metrics: '+\
                                                                                                str(metricsDictTrain), 2)
            if len(te_test_prediction)>0:
                metricsDictTest = modelTunerObj.getMetricsOnPredictions(actual = \
                                    dfActualTreatmentEffectsTest_forIntervention[[actualTreatmentEffectColumn]].values,\
                                                                                    prediction = te_test_prediction[:,i])
                logger.write('>>> treatment effect prediction ('+intervention+', '+ target + \
                                                                ') vs actual in test: Error Metrics: '+str(metricsDictTest), 2)
            if len(te_scoring_prediction)>0:
                metricsDictScoring = modelTunerObj.getMetricsOnPredictions(actual = \
                                    dfActualTreatmentEffectsScoring_forIntervention[[actualTreatmentEffectColumn]].values,\
                                                                                    prediction = te_scoring_prediction[:,i])
                logger.write('>>> treatment effect prediction ('+intervention+', '+ target + ') vs actual in scoring: Error Metrics: '+\
                                                                                                    str(metricsDictScoring), 2)
                
                
        dfMeanTreatmentEffects = dfMeanTreatmentEffects.append({'intervention': intervention,'target': target, \
                                    'trainOrTest': 'train', 'meanEstimatedTreatmentEffect': meanTreatmentEffectTrain,\
                                    'RMSE' : metricsDictTrain['RMSE'], 'MAE' : metricsDictTrain['MAE'],'ME' : metricsDictTrain['ME']},\
                                                                                                                ignore_index=True)
        dfMeanTreatmentEffects = dfMeanTreatmentEffects.append({'intervention': intervention,'target': target, \
                                    'trainOrTest': 'test', 'meanEstimatedTreatmentEffect': meanTreatmentEffectTest,\
                                    'RMSE' : metricsDictTest['RMSE'], 'MAE' : metricsDictTest['MAE'],'ME' : metricsDictTest['ME']},\
                                                                                                                 ignore_index=True)
        dfMeanTreatmentEffects = dfMeanTreatmentEffects.append({'intervention': intervention,'target': target, \
                                    'trainOrTest': 'scoring', 'meanEstimatedTreatmentEffect': meanTreatmentEffectScoring,\
                                    'RMSE' : metricsDictScoring['RMSE'], 'MAE' : metricsDictScoring['MAE'],\
                                                                                'ME' : metricsDictScoring['ME']}, ignore_index=True)
        dfInstanceIdsTrain_forIntervention[target] = te_train_prediction[:,i].ravel()   
        dfInstanceIdsTest_forIntervention[target] = te_test_prediction[:,i].ravel()   
        dfInstanceIdsScoring_forIntervention[target] = te_scoring_prediction[:,i].ravel() 
    
    scoringForOneInterventionEndTime = time.time()
    logger.write('Time for scoring for one intervention: ' + str(round((scoringForOneInterventionEndTime - \
                                                                scoringForOneInterventionStartTime)/60,2)) + ' minutes\n', 2) 
    dfInstanceIdsTrain_forIntervention['intervention'] = intervention
    dfInstanceIdsTest_forIntervention['intervention'] = intervention
    dfInstanceIdsScoring_forIntervention['intervention'] = intervention
    # saving separately for each intervention - but all outcome variables
    # for non-treated when we compute treatment effect on treated only.
    dfInstanceIdsTrain_forIntervention.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'treatmentEffectTrain_' +\
                                                                                            intervention + '.csv'), index=False)
    dfInstanceIdsTest_forIntervention.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'treatmentEffectTest_' +\
                                                                                            intervention + '.csv'), index=False) 
    dfInstanceIdsScoring_forIntervention.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'treatmentEffectScoring_' +\
                                                                                            intervention + '.csv'), index=False)      
scoringEndTime = time.time()    
logger.write('Total time for scoring: ' + str(round((scoringEndTime - scoringStartTime)/60,2)) + ' minutes\n', 2)        

dfMeanTreatmentEffects.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'meanTreatmentEffects.csv'), index=False)

# ## Treatment effect computation for interactions - conjunctions

# Treatment effect computation for interactions - conjunctions of treatment variables.  
# Conjunction of A and B => instances where both A and B > 0 are treatments. 
# For interventionConjunctions y_1 is computed with all treatment values as such and y_0 with all treatment values 0
# treatmentEffectOnTreatedOnly is computed for conjunctions.
# conjunctions and disjunctions are not implemented for modelingIterator
scoringStartTime = time.time()
# Dataframe for storing the treatment effect metrics
dfMeanTreatmentEffects = pd.DataFrame(columns = ['intervention', 'target', 'trainOrTest', 'meanEstimatedTreatmentEffect'])
totalInterventionConjunctions = len(modelingDataObj.interventionConjunctions)
for interventionNum in range(totalInterventionConjunctions):
    interventionConjunction = modelingDataObj.interventionConjunctions[interventionNum]
    interventionConjunctionName = 'conjunction'+'_'+'_'.join(interventionConjunction)
    scoringForOneInterventionStartTime = time.time()
    logger.write('========== intervention '+str(interventionNum)+ ': '+interventionConjunctionName + ' ==========', 3)
    dfConcatTrain = pd.concat([dfInstanceIdsTrain, dfFeaturesTrain, dfInstanceWeightTrain, dfTargetsTrain, dfInterventionsTrain,\
                                                                                        dfActualTreatmentEffectsTrain], axis = 1)
    dfConcatTest = pd.concat([dfInstanceIdsTest, dfFeaturesTest, dfInstanceWeightTest, dfTargetsTest,  dfInterventionsTest,\
                                                                                        dfActualTreatmentEffectsTest], axis = 1)
    dfConcatScoring = pd.concat([dfInstanceIdsScoring, dfFeaturesScoring, dfInstanceWeightScoring, dfTargetsScoring,\
                                                                dfInterventionsScoring, dfActualTreatmentEffectsScoring], axis = 1)
    for intervention in interventionConjunction:
        dfConcatTrain = dfConcatTrain[dfConcatTrain[intervention] > 0]
        dfConcatTest = dfConcatTest[dfConcatTest[intervention] > 0]
        dfConcatScoring = dfConcatScoring[dfConcatScoring[intervention] > 0]
        
    dfInstanceIdsTrain_forIntervention = modelingDataObj.getInstanceIds(dfConcatTrain)
    dfInstanceIdsTest_forIntervention = modelingDataObj.getInstanceIds(dfConcatTest)
    dfInstanceIdsScoring_forIntervention = modelingDataObj.getInstanceIds(dfConcatScoring)
    dfFeaturesTrain_forIntervention = modelingDataObj.getFeatures(dfConcatTrain)
    dfFeaturesTest_forIntervention = modelingDataObj.getFeatures(dfConcatTest)
    dfFeaturesScoring_forIntervention = modelingDataObj.getFeatures(dfConcatScoring)
    dfInstanceWeightTrain_forIntervention = modelingDataObj.getInstanceWeights(dfConcatTrain)
    dfInstanceWeightTest_forIntervention = modelingDataObj.getInstanceWeights(dfConcatTest)
    dfInstanceWeightScoring_forIntervention = modelingDataObj.getInstanceWeights(dfConcatScoring)
    dfTargetsTrain_forIntervention = modelingDataObj.getTargets(dfConcatTrain)
    dfTargetsTest_forIntervention = modelingDataObj.getTargets(dfConcatTest)
    dfTargetsScoring_forIntervention = modelingDataObj.getTargets(dfConcatScoring)
    dfInterventionsTrain_forIntervention = modelingDataObj.getInterventions(dfConcatTrain)
    dfInterventionsTest_forIntervention = modelingDataObj.getInterventions(dfConcatTest)
    dfInterventionsScoring_forIntervention = modelingDataObj.getInterventions(dfConcatScoring)
    dfActualTreatmentEffectsTrain_forIntervention = modelingDataObj.getActualTreatmentEffects(dfConcatTrain)
    dfActualTreatmentEffectsTest_forIntervention = modelingDataObj.getActualTreatmentEffects(dfConcatTest)
    dfActualTreatmentEffectsScoring_forIntervention = modelingDataObj.getActualTreatmentEffects(dfConcatScoring)
    y_train_prediction_asTreatment = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = \
                                        dfFeaturesTrain_forIntervention, dfInterventions = dfInterventionsTrain_forIntervention,\
                                                                        instanceWeight = dfInstanceWeightTrain_forIntervention)
    logger.write('y_train_prediction_asTreatment: '+str(y_train_prediction_asTreatment.mean()), 3)    
    y_test_prediction_asTreatment = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = \
                                        dfFeaturesTest_forIntervention, dfInterventions = dfInterventionsTest_forIntervention,\
                                                                        instanceWeight = dfInstanceWeightTest_forIntervention)
    logger.write('y_test_prediction_asTreatment: '+str(y_test_prediction_asTreatment.mean()), 3)
    y_scoring_prediction_asTreatment = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = \
                                        dfFeaturesScoring_forIntervention, dfInterventions = dfInterventionsScoring_forIntervention,\
                                                                        instanceWeight = dfInstanceWeightScoring_forIntervention)
    if len(y_scoring_prediction_asTreatment) > 0:
        logger.write('y_scoring_prediction_asTreatment: '+str(y_scoring_prediction_asTreatment.mean()), 3)    
    logger.write(' dfTargetsTrain.shape ' + str(dfTargetsTrain_forIntervention.shape)+ ' y_train_prediction_asTreatment.shape ' +\
                                         str(y_train_prediction_asTreatment.shape) + ' dfTargetsTest.shape '+\
                                         str(dfTargetsTest_forIntervention.shape) + ' y_test_prediction_asTreatment.shape ' +\
                                         str(y_test_prediction_asTreatment.shape)+ ' dfTargetsScoring.shape '+ \
                                         str(dfTargetsScoring_forIntervention.shape) + ' y_scoring_prediction_asTreatment.shape ' +\
                                                                             str(y_scoring_prediction_asTreatment.shape), 5)

    for intervention in interventionConjunction:
        dfInterventionsTrain_forIntervention[intervention] = 0
        dfInterventionsTest_forIntervention[intervention] = 0
        dfInterventionsScoring_forIntervention[intervention] = 0     
   
    y_train_prediction_asControl = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesTrain_forIntervention,\
                             dfInterventions = dfInterventionsTrain_forIntervention,instanceWeight = dfInstanceWeightTrain_forIntervention)
    logger.write('y_train_prediction_asControl: '+str(y_train_prediction_asControl.mean()), 3)        
    y_test_prediction_asControl = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesTest_forIntervention,\
                             dfInterventions = dfInterventionsTest_forIntervention,instanceWeight = dfInstanceWeightTest_forIntervention)
    logger.write('y_test_prediction_asControl: '+str(y_test_prediction_asControl.mean()), 3) 
    y_scoring_prediction_asControl = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesScoring_forIntervention,\
                             dfInterventions = dfInterventionsScoring_forIntervention,instanceWeight = dfInstanceWeightScoring_forIntervention)
    if len(y_scoring_prediction_asControl) > 0:
        logger.write('y_scoring_prediction_asControl: '+str(y_scoring_prediction_asControl.mean()), 3)     
    logger.write(' dfTargetsTrain.shape ' + str(dfTargetsTrain_forIntervention.shape)+ ' y_train_prediction_asControl.shape ' + \
                                str(y_train_prediction_asControl.shape) + ' dfTargetsTest.shape '+ str(dfTargetsTest_forIntervention.shape) +\
                                ' y_test_prediction_asControl.shape ' + str(y_test_prediction_asControl.shape) +' dfTargetsScoring.shape '+ \
                                str(dfTargetsScoring_forIntervention.shape) + ' y_scoring_prediction_asControl.shape ' + \
                                                                            str(y_scoring_prediction_asControl.shape), 5)
    # computing treatment effects at individual level for.
    te_train_prediction = y_train_prediction_asTreatment - y_train_prediction_asControl    
    te_test_prediction = y_test_prediction_asTreatment - y_test_prediction_asControl
    te_scoring_prediction = y_scoring_prediction_asTreatment - y_scoring_prediction_asControl
    logger.write(' dfTargetsTrain.shape ' + str(dfTargetsTrain_forIntervention.shape)+ ' te_train_prediction.shape ' + \
                            str(te_train_prediction.shape) +' dfTargetsTest.shape '+ str(dfTargetsTest_forIntervention.shape) + \
                            ' te_test_prediction.shape ' + str(te_test_prediction.shape)+ ' dfTargetsScoring.shape '+ \
                            str(dfTargetsScoring_forIntervention.shape) + ' te_scoring_prediction.shape ' + \
                                                                                            str(te_scoring_prediction.shape), 5)
    targetsList = list(dfTargetsTrain)
    for i in range(len(targetsList)):
        target = targetsList[i]
        meanTreatmentEffectTrain = te_train_prediction[:,i].mean()
        # if test data is empty, te_test_prediction will be empty numpy.ndarray and the mean will get nan.
        meanTreatmentEffectTest = te_test_prediction[:,i].mean()    
        meanTreatmentEffectScoring = te_scoring_prediction[:,i].mean() if len(te_scoring_prediction) > 0 else -99999.9
        dfMeanTreatmentEffects = dfMeanTreatmentEffects.append({'intervention': interventionConjunctionName,'target': target, \
                            'trainOrTest': 'train', 'meanEstimatedTreatmentEffect': meanTreatmentEffectTrain}, ignore_index=True)
        dfMeanTreatmentEffects = dfMeanTreatmentEffects.append({'intervention': interventionConjunctionName,'target': target, \
                              'trainOrTest': 'test', 'meanEstimatedTreatmentEffect': meanTreatmentEffectTest}, ignore_index=True)
        dfMeanTreatmentEffects = dfMeanTreatmentEffects.append({'intervention': interventionConjunctionName,'target': target, \
                        'trainOrTest': 'scoring', 'meanEstimatedTreatmentEffect': meanTreatmentEffectScoring}, ignore_index=True)        
        logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+ ' in train: '+str(meanTreatmentEffectTrain), 2)   
        logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+ ' in test: '+str(meanTreatmentEffectTest), 2)      
        logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+ ' in scoring data: '+str(meanTreatmentEffectScoring), 2)   

        dfInstanceIdsTrain_forIntervention[target] = te_train_prediction[:,i].ravel()   
        dfInstanceIdsTest_forIntervention[target] = te_test_prediction[:,i].ravel()   
        dfInstanceIdsScoring_forIntervention[target] = te_scoring_prediction[:,i].ravel() 
    
    scoringForOneInterventionEndTime = time.time()
    logger.write('Time for scoring for one intervention: ' + str(round((scoringForOneInterventionEndTime - \
                                                                    scoringForOneInterventionStartTime)/60,2)) + ' minutes\n', 2) 
    dfInstanceIdsTrain_forIntervention['intervention'] = interventionConjunctionName
    dfInstanceIdsTest_forIntervention['intervention'] = interventionConjunctionName
    dfInstanceIdsScoring_forIntervention['intervention'] = interventionConjunctionName
    # saving separately for each intervention - but all outcome variables
    # for non-treated when we compute treatment effect on treated only.
    # TODO: need to revisit later to organize the results
    if len(interventionConjunction)>5:
        interventionConjunctionName = 'conjunction_'+str(len(interventionConjunction))+ 'treatments_conjunctionNum'+str(interventionNum)
    dfInstanceIdsTrain_forIntervention.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'treatmentEffectTrain_' +\
                                                                                    interventionConjunctionName + '.csv'), index=False)
    dfInstanceIdsTest_forIntervention.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'treatmentEffectTest_' + \
                                                                                    interventionConjunctionName + '.csv'), index=False) 
    dfInstanceIdsScoring_forIntervention.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'treatmentEffectScoring_' + \
                                                                                        interventionConjunctionName + '.csv'), index=False)      
scoringEndTime = time.time()    
logger.write('Total time for scoring: ' + str(round((scoringEndTime - scoringStartTime)/60,2)) + ' minutes\n', 2)        

dfMeanTreatmentEffects.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'meanTreatmentEffectsConjunctions.csv'),\
                                                                                                                             index=False)

# ## Treatment effect computation for interactions - disjunctions

# Treatment effect computation for interactions - disjunctions of treatment variables.  
# Disjunction of A and B => instances where either A or B > 0 are treatments. 
# For interventionDisjunctions y_1 is computed with all treatment values as such and y_0 with all treatment values 0
# treatmentEffectOnTreatedOnly is computed for disjunctions.
# conjunctions and disjunctions are not implemented for modelingIterator
scoringStartTime = time.time()
# Dataframe for storing the treatment effect metrics
dfMeanTreatmentEffects = pd.DataFrame(columns = ['intervention', 'target', 'trainOrTest', 'meanEstimatedTreatmentEffect'])
totalInterventionDisjunctions = len(modelingDataObj.interventionDisjunctions)
for interventionNum in range(totalInterventionDisjunctions):
    interventionDisjunction = modelingDataObj.interventionDisjunctions[interventionNum]
    interventionDisjunctionName = 'disjunction'+'_'+'_'.join(interventionDisjunction)
    scoringForOneInterventionStartTime = time.time()
    logger.write('========== intervention '+str(interventionNum)+ ': '+interventionDisjunctionName + ' ==========', 3)
    dfConcatTrain = pd.concat([dfInstanceIdsTrain, dfFeaturesTrain, dfInstanceWeightTrain, dfTargetsTrain, dfInterventionsTrain, \
                                                                                        dfActualTreatmentEffectsTrain], axis = 1)
    dfConcatTest = pd.concat([dfInstanceIdsTest, dfFeaturesTest, dfInstanceWeightTest, dfTargetsTest,  dfInterventionsTest, \
                                                                                        dfActualTreatmentEffectsTest], axis = 1)
    dfConcatScoring = pd.concat([dfInstanceIdsScoring, dfFeaturesScoring, dfInstanceWeightScoring, dfTargetsScoring,  \
                                                            dfInterventionsScoring, dfActualTreatmentEffectsScoring], axis = 1)
    
    dfConcatTrain['disjunctionSum'] = 0
    dfConcatTest['disjunctionSum'] = 0
    dfConcatScoring['disjunctionSum'] = 0
    for intervention in interventionDisjunction:
        dfConcatTrain['disjunctionSum'] = dfConcatTrain['disjunctionSum']+dfConcatTrain[intervention]
        dfConcatTest['disjunctionSum'] = dfConcatTest['disjunctionSum']+dfConcatTest[intervention]
        dfConcatScoring['disjunctionSum'] = dfConcatScoring['disjunctionSum']+dfConcatScoring[intervention]
        
    dfConcatTrain = dfConcatTrain[dfConcatTrain['disjunctionSum'] > 0]
    dfConcatTest = dfConcatTest[dfConcatTest['disjunctionSum'] > 0]
    dfConcatScoring = dfConcatScoring[dfConcatScoring['disjunctionSum'] > 0]
    dfInstanceIdsTrain_forIntervention = modelingDataObj.getInstanceIds(dfConcatTrain)
    dfInstanceIdsTest_forIntervention = modelingDataObj.getInstanceIds(dfConcatTest)
    dfInstanceIdsScoring_forIntervention = modelingDataObj.getInstanceIds(dfConcatScoring)
    dfFeaturesTrain_forIntervention = modelingDataObj.getFeatures(dfConcatTrain)
    dfFeaturesTest_forIntervention = modelingDataObj.getFeatures(dfConcatTest)
    dfFeaturesScoring_forIntervention = modelingDataObj.getFeatures(dfConcatScoring)
    dfInstanceWeightTrain_forIntervention = modelingDataObj.getInstanceWeights(dfConcatTrain)
    dfInstanceWeightTest_forIntervention = modelingDataObj.getInstanceWeights(dfConcatTest)
    dfInstanceWeightScoring_forIntervention = modelingDataObj.getInstanceWeights(dfConcatScoring)
    dfTargetsTrain_forIntervention = modelingDataObj.getTargets(dfConcatTrain)
    dfTargetsTest_forIntervention = modelingDataObj.getTargets(dfConcatTest)
    dfTargetsScoring_forIntervention = modelingDataObj.getTargets(dfConcatScoring)
    dfInterventionsTrain_forIntervention = modelingDataObj.getInterventions(dfConcatTrain)
    dfInterventionsTest_forIntervention = modelingDataObj.getInterventions(dfConcatTest)
    dfInterventionsScoring_forIntervention = modelingDataObj.getInterventions(dfConcatScoring)
    dfActualTreatmentEffectsTrain_forIntervention = modelingDataObj.getActualTreatmentEffects(dfConcatTrain)
    dfActualTreatmentEffectsTest_forIntervention = modelingDataObj.getActualTreatmentEffects(dfConcatTest)
    dfActualTreatmentEffectsScoring_forIntervention = modelingDataObj.getActualTreatmentEffects(dfConcatScoring)
    y_train_prediction_asTreatment = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesTrain_forIntervention,\
                            dfInterventions = dfInterventionsTrain_forIntervention,instanceWeight = dfInstanceWeightTrain_forIntervention)
    logger.write('y_train_prediction_asTreatment: '+str(y_train_prediction_asTreatment.mean()), 3)    
    y_test_prediction_asTreatment = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesTest_forIntervention,\
                            dfInterventions = dfInterventionsTest_forIntervention,instanceWeight = dfInstanceWeightTest_forIntervention)
    logger.write('y_test_prediction_asTreatment: '+str(y_test_prediction_asTreatment.mean()), 3)
    y_scoring_prediction_asTreatment = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesScoring_forIntervention,\
                            dfInterventions = dfInterventionsScoring_forIntervention,instanceWeight = dfInstanceWeightScoring_forIntervention)
    if len(y_scoring_prediction_asTreatment) > 0:
        logger.write('y_scoring_prediction_asTreatment: '+str(y_scoring_prediction_asTreatment.mean()), 3)    
    logger.write(' dfTargetsTrain.shape ' + str(dfTargetsTrain_forIntervention.shape)+ ' y_train_prediction_asTreatment.shape ' + \
                            str(y_train_prediction_asTreatment.shape) + ' dfTargetsTest.shape '+ str(dfTargetsTest_forIntervention.shape) + \
                            ' y_test_prediction_asTreatment.shape ' + str(y_test_prediction_asTreatment.shape)+ ' dfTargetsScoring.shape '+ \
                            str(dfTargetsScoring_forIntervention.shape) + ' y_scoring_prediction_asTreatment.shape ' + \
                                                                            str(y_scoring_prediction_asTreatment.shape), 5)

    for intervention in interventionDisjunction:
        dfInterventionsTrain_forIntervention[intervention] = 0
        dfInterventionsTest_forIntervention[intervention] = 0
        dfInterventionsScoring_forIntervention[intervention] = 0     
   
    y_train_prediction_asControl = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesTrain_forIntervention,\
                                dfInterventions = dfInterventionsTrain_forIntervention,instanceWeight = dfInstanceWeightTrain_forIntervention)
    logger.write('y_train_prediction_asControl: '+str(y_train_prediction_asControl.mean()), 3)        
    y_test_prediction_asControl = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesTest_forIntervention,\
                                dfInterventions = dfInterventionsTest_forIntervention,instanceWeight = dfInstanceWeightTest_forIntervention)
    logger.write('y_test_prediction_asControl: '+str(y_test_prediction_asControl.mean()), 3) 
    y_scoring_prediction_asControl = modelTunerObj.getPredictionsUsingSelectedModel(phase = 2, dfFeatures = dfFeaturesScoring_forIntervention,\
                                dfInterventions = dfInterventionsScoring_forIntervention,instanceWeight = dfInstanceWeightScoring_forIntervention)
    if len(y_scoring_prediction_asControl) > 0:
        logger.write('y_scoring_prediction_asControl: '+str(y_scoring_prediction_asControl.mean()), 3)     
    logger.write(' dfTargetsTrain.shape ' + str(dfTargetsTrain_forIntervention.shape)+ ' y_train_prediction_asControl.shape ' + \
                                str(y_train_prediction_asControl.shape) + ' dfTargetsTest.shape '+ str(dfTargetsTest_forIntervention.shape) + \
                                ' y_test_prediction_asControl.shape ' + str(y_test_prediction_asControl.shape) + ' dfTargetsScoring.shape '+ \
                                str(dfTargetsScoring_forIntervention.shape) + ' y_scoring_prediction_asControl.shape ' + \
                                                                            str(y_scoring_prediction_asControl.shape), 5)
    # computing treatment effects at individual level for.
    te_train_prediction = y_train_prediction_asTreatment - y_train_prediction_asControl    
    te_test_prediction = y_test_prediction_asTreatment - y_test_prediction_asControl
    te_scoring_prediction = y_scoring_prediction_asTreatment - y_scoring_prediction_asControl
    logger.write(' dfTargetsTrain.shape ' + str(dfTargetsTrain_forIntervention.shape)+ ' te_train_prediction.shape ' + \
                str(te_train_prediction.shape) + ' dfTargetsTest.shape '+ str(dfTargetsTest_forIntervention.shape) + \
                ' te_test_prediction.shape ' + str(te_test_prediction.shape)+ ' dfTargetsScoring.shape '+ \
                str(dfTargetsScoring_forIntervention.shape) + ' te_scoring_prediction.shape ' + str(te_scoring_prediction.shape), 5)
    targetsList = list(dfTargetsTrain)
    for i in range(len(targetsList)):
        target = targetsList[i]
        meanTreatmentEffectTrain = te_train_prediction[:,i].mean()
        # if test data is empty, te_test_prediction will be empty numpy.ndarray and the mean will get nan.
        meanTreatmentEffectTest = te_test_prediction[:,i].mean()    
        meanTreatmentEffectScoring = te_scoring_prediction[:,i].mean() if len(te_scoring_prediction) > 0 else -99999.9
        dfMeanTreatmentEffects = dfMeanTreatmentEffects.append({'intervention': interventionDisjunctionName,'target': target,\
                                 'trainOrTest': 'train', 'meanEstimatedTreatmentEffect': meanTreatmentEffectTrain}, ignore_index=True)
        dfMeanTreatmentEffects = dfMeanTreatmentEffects.append({'intervention': interventionDisjunctionName,'target': target, \
                                 'trainOrTest': 'test', 'meanEstimatedTreatmentEffect': meanTreatmentEffectTest}, ignore_index=True)
        dfMeanTreatmentEffects = dfMeanTreatmentEffects.append({'intervention': interventionDisjunctionName,'target': target,\
                            'trainOrTest': 'scoring', 'meanEstimatedTreatmentEffect': meanTreatmentEffectScoring}, ignore_index=True)        
        logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+ ' in train: '+str(meanTreatmentEffectTrain), 2)   
        logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+ ' in test: '+str(meanTreatmentEffectTest), 2)      
        logger.write('------ mean treatment effect of '+ intervention + ' on '+ target+ ' in scoring data: '+str(meanTreatmentEffectScoring), 2)   

        dfInstanceIdsTrain_forIntervention[target] = te_train_prediction[:,i].ravel()   
        dfInstanceIdsTest_forIntervention[target] = te_test_prediction[:,i].ravel()   
        dfInstanceIdsScoring_forIntervention[target] = te_scoring_prediction[:,i].ravel() 
    
    scoringForOneInterventionEndTime = time.time()
    logger.write('Time for scoring for one intervention: ' + str(round((scoringForOneInterventionEndTime - \
                                                                scoringForOneInterventionStartTime)/60,2)) + ' minutes\n', 2) 
    dfInstanceIdsTrain_forIntervention['intervention'] = interventionDisjunctionName
    dfInstanceIdsTest_forIntervention['intervention'] = interventionDisjunctionName
    dfInstanceIdsScoring_forIntervention['intervention'] = interventionDisjunctionName
    # saving separately for each intervention - but all outcome variables
    # for non-treated when we compute treatment effect on treated only.
    # TODO: need to revisit later to organize the results
    if len(interventionDisjunction)>5:
        interventionDisjunctionName = 'disjunction_'+str(len(interventionDisjunction))+ 'treatments_disjunctionNum'+str(interventionNum)
    dfInstanceIdsTrain_forIntervention.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'treatmentEffectTrain_' +\
                                                                                     interventionDisjunctionName + '.csv'), index=False)
    dfInstanceIdsTest_forIntervention.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'treatmentEffectTest_' + \
                                                                                        interventionDisjunctionName + '.csv'), index=False) 
    dfInstanceIdsScoring_forIntervention.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'treatmentEffectScoring_' +\
                                                                                        interventionDisjunctionName + '.csv'), index=False)      
scoringEndTime = time.time()    
logger.write('Total time for scoring: ' + str(round((scoringEndTime - scoringStartTime)/60,2)) + ' minutes\n', 2)        

dfMeanTreatmentEffects.to_csv(os.path.join(dataConfigDict['localPaths']['resultsDirectoryName'],'meanTreatmentEffectsDisjunctions.csv'),\
                                                                                                                         index=False)

# It stops here if no standard devition is to be computed.
# Currently cross validation is not implemented for non-causal classification problems.
if modelingChoicesDict['cvSetup']['numSplitForGettingConfidenceIntervals'] <= 1:
    # TODO: Add disk cleanup code in destructor later
    getData.deleteDirectory([dataConfigDict['localPaths']['modelArtifactsScratchDirectoryName']], logger)
    modelingScriptEndTime = time.time()    
    logger.write('Total time taken: ' +         str(round((modelingScriptEndTime - modelingScriptStartTime)/60,2)) + ' minutes\n', 2)
    if len(dataConfigDict['s3Paths']['s3bucket']) > 0:
        getData.uploadResultsAndArtifacts(dataConfigDict, useBoto, logger)
    logger.close()
    if dataConfigDict['localPaths']['cleanUpLocalData'] > 0:
        getData.deleteDirectory([dataConfigDict['localPaths']['basePath']], None)  
    sys.exit('Success')

# resetting modelingChoicesDict['cvSetup']['test_fraction']
if modelingChoicesDict['cvSetup']['numSplitForGettingConfidenceIntervals'] > 1 and modelingChoicesDict['cvSetup']['test_fraction'] <= 0:
    logger.write('resetting modelingChoicesDict[cvSetup][test_fraction]', 4)
    modelingChoicesDict['cvSetup']['valid_fraction'] = 0
    modelingChoicesDict['cvSetup']['test_fraction'] = test_fraction
    
if modelingChoicesDict['cvSetup']['ensemble'] <= 0:
    modelingChoicesDict['cvSetup']['numSplitsForHyperparameters'] = 1

dfData = pd.concat([cvSplits.dfTrain, cvSplits.dfTest])
logger.write('dfData.shape after concatenation '+str(dfData.shape), 4)

bestConfigList = modelTunerObj.getBestConfig(phase = 2)
logger.write('bestConfigList length '+str(len(bestConfigList)), 4)

logger.write('bestConfigList '+ str(bestConfigList), 5)

modelIterator = modelingIterator.ModelingIterator(dataConfigDict, modelingChoicesDict, bestConfigList, dfData, modelingDataObj, logger)

dfTreatmentEffectsMetrics, dfOutcomeMetrics, dfTreatmentEffectsMetricsSummary, dfOutcomeMetricsSummary =                                                                                 modelIterator.crossValidate()

logger.write('dfTreatmentEffectsMetrics '+str(dfTreatmentEffectsMetrics), 2)

logger.write('dfTreatmentEffectsMetricsSummary '+str(dfTreatmentEffectsMetricsSummary), 2)

logger.write('dfOutcomeMetrics '+str(dfOutcomeMetrics), 3)

logger.write('dfOutcomeMetricsSummary '+str(dfOutcomeMetricsSummary), 3)

modelingScriptEndTime = time.time()
totalTime = (modelingScriptEndTime - modelingScriptStartTime)/60
logger.write('Total time taken: {:.3f} minutes'.format(totalTime), 2)

# TODO: Add disk cleanup code in destructor later
getData.deleteDirectory([dataConfigDict['localPaths']['modelArtifactsScratchDirectoryName']], logger)
getData.uploadResultsAndArtifacts(dataConfigDict, useBoto, logger)
logger.close()
if dataConfigDict['localPaths']['cleanUpLocalData'] > 0:
    getData.deleteDirectory([dataConfigDict['localPaths']['basePath']], None)



