Please use install anaconda2 package and use python 2.7.
Install mxnet-gluon 

Providing one replication of ihdp data algong with code, for easy demo. Path to data is runs/ihdp_1/data/raw/

To run on the provided ihdp data replication, execute the command below.


python entrada.py --dataConfiguration config/ihdpDataConfig.json --modelingChoices config/ihdpModelingChoices.json --prodRun False --dryRun 0 --verboseLevel 6 --runTag ihdp_1 --fileNum 1

Results and the log file would be available at runs/ihdp_1/results directory.
e_PEHE is reported as RMSE in runs/ihdp_1/results/meanTreatmentEffects.csv
e_ATE is reported as ME in runs/ihdp_1/results/meanTreatmentEffects.csv
Individual treatment effects can be accessed at 
runs/ihdp_1/results/treatmentEffectTrain_treatment.csv for train data and 
runs/ihdp_1/results/treatmentEffectTest_treatment.csv for test data
The file has 3 columns: instanceId indicates the row number in original data (before shuffling and splitting into train and test), y_factual is the treatment effect value on the outcome column (y_factual) in original data and intervention is for indicating the treatment variable column in original data.
