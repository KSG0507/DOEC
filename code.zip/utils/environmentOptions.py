import os, sys
import datetime

class Logging:

    def __init__(self, configObjDict, modelingScriptStartTime, toPrintList, toPrintVerboseList):
        # TODO: use get intention function here.
        self.globalVerboseLevel = configObjDict['verboseLevel']
        if self.globalVerboseLevel > 0:
            self.logfile = file(os.path.join(configObjDict['localPaths']['resultsDirectoryName'], \
                        self.getTimeStamp(configObjDict['runTag'], modelingScriptStartTime)+'.log'), 'a')
            self.stdout = sys.stdout
            
        for i in range(len(toPrintList)):
            self.write(toPrintList[i], toPrintVerboseList[i])

    def write(self, text, verboseLevel):
        if verboseLevel <= self.globalVerboseLevel:
            self.stdout.write(str(text)+'\n')
            self.logfile.write(str(text)+'\n')

    def close(self):
        if self.globalVerboseLevel > 0:
            self.logfile.close()
        
        
    def getTimeStamp(self, prefix, modelingScriptStartTime):
        """
        formatting and appending timestamp to a prefix
        """
        currentDateTime = datetime.datetime.fromtimestamp(modelingScriptStartTime).strftime('%Y-%m-%d-%H-%M-%S')
        timeStamp = currentDateTime
        timeStamp = prefix+'_'+timeStamp
        return timeStamp        