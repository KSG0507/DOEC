import os
import json
import re

def loadJsonConfigData(configFilePath = ''):
    """
    Loads user specified configuration file (.json)
    """
    configFilePath = configFilePath.strip()
    if os.path.exists(configFilePath):
        if configFilePath.endswith(".json"):
            _configFile = open(configFilePath, "r")
            configDict = json.load(_configFile)
            _configFile.close()
            return configDict
        else:
            print "Currently, only supported config file type is .json. Please try again."
            return {}
    else:
        print "Config file %s does not exist. Please try again." %configFilePath
        return {}


def overrideConfig(configObj, optsDict = {}):
    """
    Override default network configuration with the values in optsDict.
    This function recursively searches dict. But lists are not searched further.
    """  
    if type(configObj).__name__ == 'dict':
        for key in configObj.keys():
            if type(configObj[key]).__name__ == 'dict':
                configObj[key] = overrideConfig(configObj[key], optsDict)
                
            elif key in optsDict.keys():
                if type(configObj[key]).__name__ == 'list':
                    configObj[key] = [optsDict[key]]
                    
                else:
                    configObj[key] = optsDict[key]
    
    return configObj

def removeDescriptionEntries(configObj):
    """
    removing descriptions so that iterating over dict keys is easy.
    """  
    if type(configObj).__name__ == 'dict':
        for key in configObj.keys():
            if key.startswith('desc'):
                configObj.pop(key)
            else:
                configObj[key] = removeDescriptionEntries(configObj[key])
                    
    return configObj

def addOptsDictToConfigDict(configObj, optsDict = {}):
    """
    Add entries in optsDict to configDict.
    """  
    for key in optsDict.keys():
        configObj[key] = optsDict[key]
    
    return configObj


def replacePlaceholders(configObj, optsDict = {}):
    """
    paths are specified in the config file with placeholders for a set of options. This function is to replace the placeholders with the options chosen for this run. Please note optsDict is assumed to be only one level. 
    """
    if type(configObj).__name__ == 'dict':
        for key in configObj.keys():
            if key.startswith('desc'):
                continue
            placeholdersList = list(set([x.split('}')[0] for x in key.split('${')[1:]]))
            for placeholder in placeholdersList:
                try:
                    newKey = key.replace('${'+placeholder+'}', optsDict[placeholder])
                    configObj[newKey] = configObj.pop(key)
                    key = newKey
                except:
                    print placeholder + ' not passed as argument from command line. Needed in ' + key
                    
            configObj[key] = replacePlaceholders(configObj[key], optsDict)
   
    elif type(configObj).__name__ == 'list':
        for i in range(len(configObj)):
            configObj[i] = replacePlaceholders(configObj[i], optsDict)
            
    elif type(configObj).__name__ == 'str' or type(configObj).__name__ == 'unicode':
        # identify the placeholders
        placeholdersList = list(set([x.split('}')[0] for x in configObj.split('${')[1:]]))
        for placeholder in placeholdersList:
            try:
                configObj = configObj.replace('${'+placeholder+'}', optsDict[placeholder])
                
            except:
                print placeholder + ' not passed as argument from command line. Needed in ' + configObj

    return configObj

def saveConfig(configFile, path):
 
    with open(path, 'w') as fp:
        json.dump(configFile,fp)